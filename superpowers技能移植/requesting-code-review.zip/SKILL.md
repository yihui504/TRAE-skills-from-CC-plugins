---
name: requesting-code-review
description: 当完成任务、实现主要功能或合并前验证工作是否符合需求时使用
---

# 请求代码审查

派遣代码审查子代理在问题级联之前捕获它们。审查者获得精确构建的评估上下文——而非你的会话历史。这让审查者聚焦于工作产出而非你的思考过程，也为你自己的上下文保留了继续工作的空间。

**核心原则：** 尽早审查，频繁审查。

## 使用场景

- 子代理驱动开发中每个任务完成后
- 完成主要功能后
- 合并到 main 之前

**可选但有价值：**
- 卡住时（新视角）
- 重构前（基线检查）
- 修复复杂bug后

## 不适用场景

- 只做了微小的文档修改
- 变更仅涉及配置文件且无逻辑影响
- 已有其他审查者正在审查同一变更

注意：本skill与SOLO Coder的子代理机制配合使用，通过派遣独立审查代理确保代码质量。

## 如何请求审查

**1. 获取 git SHA：**
```bash
BASE_SHA=$(git rev-parse HEAD~1)  # 或 origin/main
HEAD_SHA=$(git rev-parse HEAD)
```

**2. 派遣代码审查子代理：**

使用 Task 工具派遣代码审查子代理，填写 `code-reviewer.md` 中的模板

**占位符：**
- `{WHAT_WAS_IMPLEMENTED}` - 你刚构建的内容
- `{PLAN_OR_REQUIREMENTS}` - 它应该做什么
- `{BASE_SHA}` - 起始提交
- `{HEAD_SHA}` - 结束提交
- `{DESCRIPTION}` - 简要摘要

**3. 处理反馈：**
- 立即修复 Critical 问题
- 在继续前修复 Important 问题
- 记录 Minor 问题稍后处理
- 如果审查者错了则反驳（附理由）

## 示例

```
[刚完成任务2：添加验证功能]

你：让我在继续之前请求代码审查。

BASE_SHA=$(git log --oneline | grep "Task 1" | head -1 | awk '{print $1}')
HEAD_SHA=$(git rev-parse HEAD)

[派遣代码审查子代理]
  WHAT_WAS_IMPLEMENTED: 对话索引的验证和修复功能
  PLAN_OR_REQUIREMENTS: .trae/plans/deployment-plan.md 中的任务2
  BASE_SHA: a7981ec
  HEAD_SHA: 3df7661
  DESCRIPTION: 添加了 verifyIndex() 和 repairIndex()，包含4种问题类型

[子代理返回]：
  优点：清晰的架构，真实测试
  问题：
    Important：缺少进度指示器
    Minor：报告间隔的魔术数字（100）
  评估：可以继续

你：[修复进度指示器]
[继续任务3]
```

## 与工作流集成

**子代理驱动开发：**
- 每个任务后审查
- 在问题累积前捕获
- 在进入下一任务前修复

**执行计划：**
- 每批（3个任务）后审查
- 获取反馈，应用，继续

**临时开发：**
- 合并前审查
- 卡住时审查

## 红线

**绝不：**
- 因为"很简单"而跳过审查
- 忽略 Critical 问题
- 在 Important 问题未修复时继续
- 与有效的技术反馈争论

**如果审查者错了：**
- 用技术推理反驳
- 展示证明它有效的代码/测试
- 请求澄清

## 输出

- 审查报告（优点、问题分类、评估）
- 修复后的代码变更
- 验证结果

## 依赖

- 无强依赖，可与 subagent-driven-development、executing-plans 配合使用

参见模板：requesting-code-review/code-reviewer.md
