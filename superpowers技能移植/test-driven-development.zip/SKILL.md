---
name: test-driven-development
description: 当实现任何功能或修复bug时使用，在编写实现代码之前
---

# 测试驱动开发（TDD）

## 描述

先写测试。看它失败。写最少的代码让它通过。

**核心原则：** 如果你没有看到测试失败，你不知道它测试的是否正确。

**违反规则的字面意思就是违反规则的精神。**

## 使用场景

**始终使用：**
- 新功能
- Bug修复
- 重构
- 行为变更

**例外（需征得合作伙伴同意）：**
- 一次性原型
- 生成代码
- 配置文件

觉得"就这次跳过TDD"？停止。那是合理化。

## 不适用场景

- 纯配置文件变更（无逻辑）
- 一次性探索性脚本（用完即弃）
- 第三方库的集成测试（库已有测试）

注意：本skill与SOLO Coder的自动执行模式配合使用，确保在自动运行命令开启时测试先行。

## 铁律

```
没有失败测试就不能写生产代码
```

先写了代码再写测试？删掉它。重新开始。

**无例外：**
- 不要把它留作"参考"
- 不要在写测试时"适配"它
- 不要看它
- 删除就是删除

从测试开始全新实现。就这么简单。

## 红-绿-重构

```dot
digraph tdd_cycle {
    rankdir=LR;
    red [label="RED\n写失败测试", shape=box, style=filled, fillcolor="#ffcccc"];
    verify_red [label="验证失败\n正确", shape=diamond];
    green [label="GREEN\n最少代码", shape=box, style=filled, fillcolor="#ccffcc"];
    verify_green [label="验证通过\n全部绿色", shape=diamond];
    refactor [label="REFACTOR\n清理", shape=box, style=filled, fillcolor="#ccccff"];
    next [label="下一个", shape=ellipse];

    red -> verify_red;
    verify_red -> green [label="是"];
    verify_red -> red [label="错误\n失败"];
    green -> verify_green;
    verify_green -> refactor [label="是"];
    verify_green -> green [label="否"];
    refactor -> verify_green [label="保持\n绿色"];
    verify_green -> next;
    next -> red;
}
```

### RED - 写失败测试

写一个最小测试展示应该发生什么。

<Good>
```typescript
test('retries failed operations 3 times', async () => {
  let attempts = 0;
  const operation = () => {
    attempts++;
    if (attempts < 3) throw new Error('fail');
    return 'success';
  };

  const result = await retryOperation(operation);

  expect(result).toBe('success');
  expect(attempts).toBe(3);
});
```
清晰的名称，测试真实行为，一件事
</Good>

<Bad>
```typescript
test('retry works', async () => {
  const mock = jest.fn()
    .mockRejectedValueOnce(new Error())
    .mockRejectedValueOnce(new Error())
    .mockResolvedValueOnce('success');
  await retryOperation(mock);
  expect(mock).toHaveBeenCalledTimes(3);
});
```
模糊的名称，测试mock而非代码
</Bad>

**要求：**
- 一个行为
- 清晰的名称
- 真实代码（除非不可避免否则不用mock）

### 验证RED - 看它失败

**必须。绝不跳过。**

```bash
npm test path/to/test.test.ts
```

确认：
- 测试失败（不是报错）
- 失败消息是预期的
- 因为功能缺失而失败（不是拼写错误）

**测试通过了？** 你在测试已有行为。修复测试。

**测试报错了？** 修复错误，重新运行直到正确失败。

### GREEN - 最少代码

写最简单的代码让测试通过。

<Good>
```typescript
async function retryOperation<T>(fn: () => Promise<T>): Promise<T> {
  for (let i = 0; i < 3; i++) {
    try {
      return await fn();
    } catch (e) {
      if (i === 2) throw e;
    }
  }
  throw new Error('unreachable');
}
```
刚好够通过
</Good>

<Bad>
```typescript
async function retryOperation<T>(
  fn: () => Promise<T>,
  options?: {
    maxRetries?: number;
    backoff?: 'linear' | 'exponential';
    onRetry?: (attempt: number) => void;
  }
): Promise<T> {
  // YAGNI
}
```
过度工程
</Bad>

不要添加功能、重构其他代码或"改进"超出测试范围的内容。

### 验证GREEN - 看它通过

**必须。**

```bash
npm test path/to/test.test.ts
```

确认：
- 测试通过
- 其他测试仍然通过
- 输出干净（无错误、警告）

**测试失败了？** 修复代码，不是测试。

**其他测试失败了？** 立即修复。

### REFACTOR - 清理

只在绿色之后：
- 移除重复
- 改善命名
- 提取辅助函数

保持测试绿色。不要添加行为。

### 重复

为下一个功能写下一个失败测试。

## 好的测试

| 质量 | 好 | 差 |
|------|---|---|
| **最小化** | 一件事。名称中有"and"？拆分它。 | `test('validates email and domain and whitespace')` |
| **清晰** | 名称描述行为 | `test('test1')` |
| **展示意图** | 展示期望的API | 模糊代码应该做什么 |

## 为什么顺序重要

**"我稍后写测试来验证它有效"**

后写的测试立即通过。立即通过什么也证明不了：
- 可能测试了错误的东西
- 可能测试了实现而非行为
- 可能遗漏了你忘记的边界情况
- 你从未看到它捕获bug

测试先行迫使你看到测试失败，证明它确实测试了什么。

**"我已经手动测试了所有边界情况"**

手动测试是临时的。你以为测试了一切但：
- 没有记录你测试了什么
- 代码变更时无法重新运行
- 压力下容易忘记情况
- "我试的时候有效" != 全面

自动化测试是系统化的。它们每次以相同方式运行。

**"删除X小时的工作是浪费"**

沉没成本谬误。时间已经过去了。你现在的选择：
- 删除并用TDD重写（X更多小时，高置信度）
- 保留并后加测试（30分钟，低置信度，可能有bug）

"浪费"是保留你不能信任的代码。没有真实测试的工作代码是技术债。

**"TDD是教条的，务实意味着适应"**

TDD就是务实的：
- 在提交前发现bug（比之后调试更快）
- 防止回归（测试立即捕获破坏）
- 记录行为（测试展示如何使用代码）
- 启用重构（自由变更，测试捕获破坏）

"务实"的捷径 = 在生产中调试 = 更慢。

**"后测达到同样目标——关键是精神不是仪式"**

不。后测回答"这做了什么？"先测回答"这应该做什么？"

后测受你的实现偏见影响。你测试你构建的，而非要求的。你验证记住的边界情况，而非发现的。

先测迫使在实现前发现边界情况。后测验证你记住了一切（你没有）。

30分钟的后测 != TDD。你获得了覆盖率，失去了测试有效的证明。

## 常见合理化

| 借口 | 现实 |
|------|------|
| "太简单不需要测试" | 简单代码也会坏。测试只需30秒。 |
| "我稍后写测试" | 立即通过的测试什么也证明不了。 |
| "稍后的测试达到同样目标" | 后测 = "这做了什么？" 先测 = "这应该做什么？" |
| "已经手动测试了" | 临时 != 系统化。无记录，无法重跑。 |
| "删除X小时的工作是浪费" | 沉没成本谬误。保留不可信的代码是技术债。 |
| "留作参考，先写测试" | 你会适配它。那就是后测。删除就是删除。 |
| "需要先探索" | 可以。扔掉探索，从TDD开始。 |
| "测试难写 = 设计不清晰" | 听测试的。难测试 = 难使用。 |
| "TDD会拖慢我" | TDD比调试快。务实 = 先测试。 |
| "手动测试更快" | 手动无法证明边界情况。每次变更都要重测。 |
| "现有代码没有测试" | 你在改进它。为现有代码添加测试。 |

## 红线——停止并重新开始

- 先写代码再写测试
- 实现后写测试
- 测试立即通过
- 无法解释为什么测试失败
- "稍后"添加测试
- 合理化"就这一次"
- "我已经手动测试了"
- "后测达到同样目的"
- "关键是精神不是仪式"
- "留作参考"或"适配现有代码"
- "已经花了X小时，删除是浪费"
- "TDD是教条的，我是务实的"
- "这次不同因为..."

**所有这些意味着：删除代码。从TDD重新开始。**

## 示例：Bug修复

**Bug：** 空邮箱被接受

**RED**
```typescript
test('rejects empty email', async () => {
  const result = await submitForm({ email: '' });
  expect(result.error).toBe('Email required');
});
```

**验证RED**
```bash
$ npm test
FAIL: expected 'Email required', got undefined
```

**GREEN**
```typescript
function submitForm(data: FormData) {
  if (!data.email?.trim()) {
    return { error: 'Email required' };
  }
  // ...
}
```

**验证GREEN**
```bash
$ npm test
PASS
```

**REFACTOR**
如果需要，为多个字段提取验证。

## 验证检查清单

在标记工作完成之前：

- [ ] 每个新函数/方法都有测试
- [ ] 看到每个测试在实现前失败
- [ ] 每个测试因预期原因失败（功能缺失，不是拼写错误）
- [ ] 写了最少的代码让每个测试通过
- [ ] 所有测试通过
- [ ] 输出干净（无错误、警告）
- [ ] 测试使用真实代码（仅在不可避免时用mock）
- [ ] 边界情况和错误已覆盖

无法勾选所有框？你跳过了TDD。重新开始。

## 遇到困难时

| 问题 | 解决方案 |
|------|---------|
| 不知道怎么测试 | 写期望的API。先写断言。问合作伙伴。 |
| 测试太复杂 | 设计太复杂。简化接口。 |
| 必须mock一切 | 代码太耦合。使用依赖注入。 |
| 测试设置巨大 | 提取辅助函数。仍然复杂？简化设计。 |

## 调试集成

发现bug？写重现它的失败测试。遵循TDD循环。测试证明修复并防止回归。

绝不没有测试就修bug。

## 测试反模式

当添加mock或测试工具时，阅读 `testing-anti-patterns.md` 以避免常见陷阱：
- 测试mock行为而非真实行为
- 在生产类中添加仅测试用的方法
- 不理解依赖就mock

## 最终规则

```
生产代码 → 测试存在且先失败
否则 → 不是TDD
```

未经合作伙伴许可无例外。

## 输出

- 失败测试（RED阶段）
- 通过测试（GREEN阶段）
- 最少实现代码
- 重构后的干净代码

## 依赖

- 无强依赖，可与 systematic-debugging 配合使用
