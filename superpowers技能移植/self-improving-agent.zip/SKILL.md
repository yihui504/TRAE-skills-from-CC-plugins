---
name: self-improving-agent
description: 当技能完成或出错时自动触发，从所有技能经验中学习并持续改进代码库
allowed-tools: Read, Write, Edit, Bash, Grep, Glob, WebSearch
metadata:
  hooks:
    before_start:
      - trigger: session-logger
        mode: auto
        context: "Start {skill_name}"
    after_complete:
      - trigger: create-pr
        mode: ask_first
        condition: skills_modified
        reason: "提交改进到仓库"
      - trigger: session-logger
        mode: auto
        context: "Self-improvement cycle complete"
    on_error:
      - trigger: session-logger
        mode: auto
        context: "Error captured in {skill_name}"
---

# 自我改进代理

> "一个从每次交互中学习的AI代理，积累模式和洞察来持续改进自身能力。" — 基于2025终身学习研究

## 描述

这是一个从所有技能经验中学习的通用自我改进系统，不仅限于PRD。它实现了完整的反馈循环：

- **多记忆架构**：语义 + 情景 + 工作记忆
- **自我纠正**：检测并修复技能指导错误
- **自我验证**：定期验证技能准确性
- **钩子集成**：在技能事件上自动触发（before_start, after_complete, on_error）
- **进化标记**：可追溯的变更与来源归属

## 使用场景

- 任何技能完成后自动提取经验
- 技能指导导致错误时自动纠正
- 用户说"自我进化"、"从经验中学习"
- 用户要求改进特定技能

## 不适用场景

- 首次使用某技能（尚无经验可提取）
- 用户明确要求不做自动改进
- 技能执行被中断（未完成则无经验）

注意：本skill通过钩子机制与SOLO Coder集成，在技能完成/出错时自动触发学习和改进。

## 基于研究的设计

基于2025年研究：

| 研究 | 关键洞察 | 应用 |
|------|---------|------|
| [SimpleMem](https://arxiv.org/html/2601.02553v1) | 高效终身记忆 | 模式积累系统 |
| [Multi-Memory Survey](https://dl.acm.org/doi/10.1145/3748302) | 语义 + 情景记忆 | 世界知识 + 经验 |
| [Lifelong Learning](https://arxiv.org/html/2501.07278v1) | 持续任务流学习 | 从每次技能使用中学习 |
| [Evo-Memory](https://shothota.medium.com/evo-memory-deepminds-new-benchmark) | 测试时终身学习 | 实时适应 |

## 自我改进循环

```
技能事件 → 提取经验 → 抽象模式 → 更新
     │              │            │        │
     ▼              ▼            ▼        ▼
┌─────────────────────────────────────────────┐
│              多记忆系统                       │
├─────────────────────────────────────────────┤
│  语义记忆     │  情景记忆    │  工作记忆     │
│  (模式/规则)  │  (经验)      │  (当前)       │
│  memory/semantic/ │ memory/episodic/ │ memory/working/ │
└─────────────────────────────────────────────┘
```

## 自动触发（通过钩子）

| 事件 | 触发 | 动作 |
|------|------|------|
| **before_start** | 任何技能启动 | 记录会话开始 |
| **after_complete** | 任何技能完成 | 提取模式，更新技能 |
| **on_error** | Bash返回非零退出码 | 捕获错误上下文，触发自我纠正 |

## 手动触发

- 用户说"自我进化"、"self-improve"、"从经验中学习"
- 用户说"分析今天的经验"、"总结教训"
- 用户要求改进特定技能

## 进化优先级矩阵

当出现新的可复用知识时触发进化：

| 触发 | 目标技能 | 优先级 | 动作 |
|------|---------|--------|------|
| 发现新PRD模式 | prd-planner | 高 | 添加到质量检查清单 |
| 架构权衡明确 | architecting-solutions | 高 | 添加到决策模式 |
| API设计规则学习 | api-designer | 高 | 更新模板 |
| 调试修复发现 | debugger | 高 | 添加到反模式 |
| 审查检查清单缺口 | code-reviewer | 高 | 添加检查项 |
| 性能/安全洞察 | performance-engineer, security-auditor | 高 | 添加到模式 |
| UI/UX规格问题 | prd-planner, architecting-solutions | 高 | 添加视觉规格要求 |
| React/状态模式 | debugger, refactoring-specialist | 中 | 添加到模式 |
| 测试策略改进 | test-automator, qa-expert | 中 | 更新方法 |
| CI/部署修复 | deployment-engineer | 中 | 添加到故障排除 |

## 多记忆架构

### 1. 语义记忆（`memory/semantic-patterns.json`）

存储可跨上下文复用的抽象模式和规则：

```json
{
  "patterns": {
    "pattern_id": {
      "id": "pat-2025-01-11-001",
      "name": "模式名称",
      "source": "user_feedback|implementation_review|retrospective",
      "confidence": 0.95,
      "applications": 5,
      "created": "2025-01-11",
      "category": "prd_structure|react_patterns|async_patterns|...",
      "pattern": "一行摘要",
      "problem": "这解决什么问题？",
      "solution": { ... },
      "quality_rules": [ ... ],
      "target_skills": [ ... ]
    }
  }
}
```

### 2. 情景记忆（`memory/episodic/`）

存储具体经验和发生的事情：

```
memory/episodic/
├── 2025/
│   ├── 2025-01-11-prd-creation.json
│   ├── 2025-01-11-debug-session.json
│   └── 2025-01-12-refactoring.json
```

```json
{
  "id": "ep-2025-01-11-001",
  "timestamp": "2025-01-11T10:30:00Z",
  "skill": "debugger",
  "situation": "用户报告表单提交后数据未刷新",
  "root_cause": "onRefresh prop中的空回调",
  "solution": "在回调中实现实际刷新逻辑",
  "lesson": "始终验证回调不是空函数",
  "related_pattern": "callback_verification",
  "user_feedback": {
    "rating": 8,
    "comments": "这正是问题所在"
  }
}
```

### 3. 工作记忆（`memory/working/`）

存储当前会话上下文：

```
memory/working/
├── current_session.json
├── last_error.json
└── session_end.json
```

## 自我改进过程

### 阶段1：经验提取

任何技能完成后，提取：

```yaml
发生了什么:
  skill_used: {哪个技能}
  task: {在做什么}
  outcome: {success|partial|failure}

关键洞察:
  what_went_well: [什么有效]
  what_went_wrong: [什么无效]
  root_cause: {潜在问题（如适用）}

用户反馈:
  rating: {1-10（如提供）}
  comments: {具体反馈}
```

### 阶段2：模式抽象

将经验转换为可复用模式：

| 具体经验 | 抽象模式 | 目标技能 |
|---------|---------|---------|
| "用户忘记保存PRD笔记" | "始终将思考持久化到文件" | prd-planner |
| "代码审查遗漏SQL注入" | "添加安全检查清单项" | code-reviewer |
| "回调为空，不工作" | "验证回调实现" | debugger |
| "Net APY位置模糊" | "UI规格需要精确相对位置" | prd-planner |

**抽象规则：**

```yaml
如果 experience_repeats 3+ 次:
  pattern_level: critical
  action: 添加到技能的"关键错误"节

如果 solution_was_effective:
  pattern_level: best_practice
  action: 添加到技能的"最佳实践"节

如果 user_rating >= 7:
  pattern_level: strength
  action: 强化此方法

如果 user_rating <= 4:
  pattern_level: weakness
  action: 添加到"应避免"节
```

### 阶段3：技能更新

用进化标记更新适当的技能文件：

```markdown
<!-- Evolution: 2025-01-12 | source: ep-2025-01-12-001 | skill: debugger -->

## 添加的模式 (2025-01-12)

**模式**：始终验证回调不是空函数

**来源**：Episode ep-2025-01-12-001

**置信度**：0.95

### 更新的检查清单
- [ ] 验证所有回调都有实现
- [ ] 测试回调执行路径
```

**纠正标记**（修复错误指导时）：

```markdown
<!-- Correction: 2025-01-12 | was: "使用回调链" | reason: 导致过期刷新 -->

## 纠正的指导

使用直接状态监控替代回调链：
```typescript
const prevPendingCount = usePrevious(pendingCount);
```
```

### 阶段4：记忆整合

1. **更新语义记忆**（`memory/semantic-patterns.json`）
2. **存储情景记忆**（`memory/episodic/YYYY-MM-DD-{skill}.json`）
3. **基于应用/反馈更新模式置信度**
4. **修剪过时模式**（低置信度，无近期应用）

## 自我纠正（on_error钩子）

触发条件：
- Bash命令返回非零退出码
- 遵循技能指导后测试失败
- 用户报告指导产生了不正确结果

**过程：**

1. 检测错误——从 `working/last_error.json` 捕获错误上下文，识别遵循了哪个技能指导
2. 验证根因——技能指导不正确？被误解？不完整？
3. 应用纠正——用纠正的指导更新技能文件，添加纠正标记和原因，更新语义记忆中的相关模式
4. 验证修复——测试纠正的指导，请用户验证

**示例：**

```markdown
<!-- Correction: 2025-01-12 | was: "useMemo for claimable ids" | reason: stale data at click time -->

## 自我纠正：点击时计算

**问题**：使用useMemo计算可领取ID导致过期数据
**修复**：在点击时计算以获取始终新鲜的数据
**模式**：click_time_vs_open_time_computation
```

```typescript
// 修复前（过期数据）
const claimableIds = useMemo(() => items.filter(i => i.claimable), [items]);

// 修复后（始终新鲜）
const handleClaim = () => {
  const claimableIds = items.filter(i => i.claimable); // 点击时计算
  // ...
};
```

## 自我验证

审查更新时使用 `references/appendix.md` 中的验证模板。

## 钩子集成

### 在设置中配置钩子

添加到设置文件（`.trae/settings.json`）：

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash|Write|Edit",
        "hooks": [
          {
            "type": "command",
            "command": "bash ${SKILLS_DIR}/self-improving-agent/hooks/pre-tool.sh \"$TOOL_NAME\" \"$TOOL_INPUT\""
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "bash ${SKILLS_DIR}/self-improving-agent/hooks/post-bash.sh \"$TOOL_OUTPUT\" \"$EXIT_CODE\""
          }
        ]
      }
    ],
    "Stop": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "bash ${SKILLS_DIR}/self-improving-agent/hooks/session-end.sh"
          }
        ]
      }
    ]
  }
}
```

将 `${SKILLS_DIR}` 替换为你的实际技能路径。

## 附加参考

参见 `references/appendix.md` 了解记忆结构、工作流图、指标、反馈模板和研究链接。

## 最佳实践

### 应该

- 从每次技能交互中学习
- 在正确的抽象级别提取模式
- 更新多个相关技能
- 跟踪置信度和应用次数
- 请求用户对改进的反馈
- 使用进化/纠正标记确保可追溯性
- 在广泛应用前验证指导

### 不应该

- 从单一经验过度泛化
- 不跟踪置信度就更新技能
- 忽略负面反馈
- 做出破坏现有功能的变更
- 创建矛盾的模式
- 不理解上下文就更新技能

## 快速开始

任何技能完成后，此代理自动：

1. **分析**发生了什么
2. **提取**模式和洞察
3. **更新**相关技能文件
4. **记录**到记忆中供未来参考
5. **报告**摘要给用户

## 参考文献

- [SimpleMem: Efficient Lifelong Memory for LLM Agents](https://arxiv.org/html/2601.02553v1)
- [A Survey on the Memory Mechanism of Large Language Model Agents](https://dl.acm.org/doi/10.1145/3748302)
- [Lifelong Learning of LLM based Agents](https://arxiv.org/html/2501.07278v1)
- [Evo-Memory: DeepMind's Benchmark](https://shothota.medium.com/evo-memory-deepminds-new-benchmark)
- [Let's Build a Self-Improving AI Agent](https://medium.com/@nomannayeem/lets-build-a-self-improving-ai-agent-that-learns-from-your-feedback-722d2ce9c2d9)

## 输出

- 经验提取记录
- 模式抽象结果
- 技能文件更新（带进化/纠正标记）
- 记忆整合状态

## 依赖

- 无强依赖，与所有技能配合使用
