---
name: finishing-a-development-branch
description: 当实现完成、所有测试通过，需要决定如何集成工作时使用——通过呈现结构化选项引导完成合并、PR或清理
---

# 完成开发分支

## 描述

通过呈现清晰选项和处理选定工作流来引导完成开发工作。

**核心原则：** 验证测试 -> 呈现选项 -> 执行选择 -> 清理。

**开始时声明：** "我正在使用 finishing-a-development-branch 技能来完成这项工作。"

## 使用场景

- 功能实现完成，所有测试通过
- 需要决定如何集成工作（合并、PR或保留）
- 在 worktree 中工作，需要清理

注意：本skill在SOLO Coder中用于完成功能分支的集成工作。

## 不适用场景

- 测试尚未通过（先修复测试）
- 实现尚未完成（继续开发）
- 只是想保存当前进度（直接提交即可）

注意：本skill通常在使用 using-git-worktrees 创建的隔离工作区完成后调用，负责分支的最终处理和清理。

## 过程

### 步骤1：验证测试

**在呈现选项之前，验证测试通过：**

```bash
# 运行项目的测试套件
npm test / cargo test / pytest / go test ./...
```

**如果测试失败：**
```
测试失败（<N>个失败）。必须在完成前修复：

[显示失败项]

测试通过前无法继续合并/PR。
```

停止。不要继续到步骤2。

**如果测试通过：** 继续到步骤2。

### 步骤2：确定基础分支

```bash
# 尝试常见基础分支
git merge-base HEAD main 2>/dev/null || git merge-base HEAD master 2>/dev/null
```

或询问："这个分支从 main 分出——对吗？"

### 步骤3：呈现选项

精确呈现以下4个选项：

```
实现完成。你想怎么做？

1. 本地合并回 <base-branch>
2. 推送并创建 Pull Request
3. 保持分支原样（稍后我自己处理）
4. 丢弃这项工作

选哪个？
```

**不要添加解释** — 保持选项简洁。

### 步骤4：执行选择

#### 选项1：本地合并

```bash
# 切换到基础分支
git checkout <base-branch>

# 拉取最新
git pull

# 合并功能分支
git merge <feature-branch>

# 验证合并结果的测试
<test command>

# 如果测试通过
git branch -d <feature-branch>
```

然后：清理 worktree（步骤5）

#### 选项2：推送并创建PR

```bash
# 推送分支
git push -u origin <feature-branch>

# 创建PR
gh pr create --title "<title>" --body "$(cat <<'EOF'
## 摘要
<2-3条变更要点>

## 测试计划
- [ ] <验证步骤>
EOF
)"
```

然后：清理 worktree（步骤5）

#### 选项3：保持原样

报告："保留分支 <name>。Worktree 保留在 <path>。"

**不清理 worktree。**

#### 选项4：丢弃

**先确认：**
```
这将永久删除：
- 分支 <name>
- 所有提交：<commit-list>
- Worktree 在 <path>

输入 'discard' 确认。
```

等待精确确认。

如果确认：
```bash
git checkout <base-branch>
git branch -D <feature-branch>
```

然后：清理 worktree（步骤5）

### 步骤5：清理 Worktree

**对于选项1、2、4：**

检查是否在 worktree 中：
```bash
git worktree list | grep $(git branch --show-current)
```

如果是：
```bash
git worktree remove <worktree-path>
```

**对于选项3：** 保留 worktree。

## 快速参考

| 选项 | 合并 | 推送 | 保留Worktree | 清理分支 |
|------|------|------|-------------|---------|
| 1. 本地合并 | 是 | - | - | 是 |
| 2. 创建PR | - | 是 | 是 | - |
| 3. 保持原样 | - | - | 是 | - |
| 4. 丢弃 | - | - | - | 是（强制） |

## 常见错误

**跳过测试验证**
- **问题：** 合并损坏代码，创建失败PR
- **修复：** 始终在提供选项前验证测试

**开放式提问**
- **问题：** "接下来我该怎么做？" → 模糊
- **修复：** 精确呈现4个结构化选项

**自动清理worktree**
- **问题：** 在可能需要时移除worktree（选项2、3）
- **修复：** 只在选项1和4时清理

**丢弃无确认**
- **问题：** 意外删除工作
- **修复：** 要求输入 "discard" 确认

## 红线

**绝不：**
- 在测试失败时继续
- 未验证合并结果测试就合并
- 未经确认删除工作
- 未经明确请求强制推送

**始终：**
- 在提供选项前验证测试
- 精确呈现4个选项
- 选项4要求输入确认
- 仅在选项1和4时清理worktree

## 输出

- 测试验证结果
- 用户选择的工作流执行结果（合并/PR/保留/丢弃）
- Worktree 清理状态

## 依赖

- using-git-worktrees（清理由该技能创建的worktree）
