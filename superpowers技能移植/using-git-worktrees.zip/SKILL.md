---
name: using-git-worktrees
description: 当开始需要与当前工作区隔离的功能开发，或在执行实现计划之前使用——创建隔离的git worktree并带智能目录选择和安全验证
---

# 使用 Git Worktrees

## 描述

Git worktrees 创建共享同一仓库的隔离工作区，允许同时在多个分支上工作而无需切换。

**核心原则：** 系统化目录选择 + 安全验证 = 可靠隔离。

**开始时声明：** "我正在使用 using-git-worktrees 技能设置隔离工作区。"

## 使用场景

- 开始需要与当前工作区隔离的功能开发
- 执行实现计划之前设置隔离环境
- 需要同时在多个分支上工作

注意：本skill在SOLO Coder中用于创建隔离的git worktree工作环境。

## 不适用场景

- 只是在当前分支上做小修改（无需隔离）
- 项目不支持 git worktree（如某些单文件项目）
- 已经在隔离环境中工作

注意：本skill创建的worktree在开发完成后由 finishing-a-development-branch 技能负责清理。

## 目录选择过程

按以下优先级顺序：

### 1. 检查已有目录

```bash
# 按优先级检查
ls -d .worktrees 2>/dev/null     # 首选（隐藏）
ls -d worktrees 2>/dev/null      # 备选
```

**如果找到：** 使用该目录。如果两者都存在，`.worktrees` 优先。

### 2. 检查项目规则文件

```bash
grep -i "worktree.*director" .trae/rules/*.md 2>/dev/null
```

**如果有偏好指定：** 直接使用，不再询问。

### 3. 询问用户

如果没有目录存在且规则文件中没有偏好：

```
未找到worktree目录。应该在哪里创建worktrees？

1. .worktrees/（项目本地，隐藏）
2. ~/.config/superpowers/worktrees/<project-name>/（全局位置）

你更偏好哪个？
```

## 安全验证

### 对于项目本地目录（.worktrees 或 worktrees）

**创建worktree前必须验证目录已被忽略：**

```bash
# 检查目录是否被忽略（遵守本地、全局和系统gitignore）
git check-ignore -q .worktrees 2>/dev/null || git check-ignore -q worktrees 2>/dev/null
```

**如果未被忽略：**

按照"立即修复损坏的东西"原则：
1. 在 .gitignore 中添加适当的行
2. 提交变更
3. 继续创建worktree

**为什么关键：** 防止意外将worktree内容提交到仓库。

### 对于全局目录（~/.config/superpowers/worktrees）

无需 .gitignore 验证——完全在项目之外。

## 创建步骤

### 1. 检测项目名称

```bash
project=$(basename "$(git rev-parse --show-toplevel)")
```

### 2. 创建 Worktree

```bash
# 确定完整路径
case $LOCATION in
  .worktrees|worktrees)
    path="$LOCATION/$BRANCH_NAME"
    ;;
  ~/.config/superpowers/worktrees/*)
    path="~/.config/superpowers/worktrees/$project/$BRANCH_NAME"
    ;;
esac

# 创建worktree并新建分支
git worktree add "$path" -b "$BRANCH_NAME"
cd "$path"
```

### 3. 运行项目设置

自动检测并运行适当的设置：

```bash
# Node.js
if [ -f package.json ]; then npm install; fi

# Rust
if [ -f Cargo.toml ]; then cargo build; fi

# Python
if [ -f requirements.txt ]; then pip install -r requirements.txt; fi
if [ -f pyproject.toml ]; then poetry install; fi

# Go
if [ -f go.mod ]; then go mod download; fi
```

### 4. 验证干净基线

运行测试确保worktree从干净状态开始：

```bash
# 示例 - 使用项目适当的命令
npm test
cargo test
pytest
go test ./...
```

**如果测试失败：** 报告失败，询问是否继续或调查。

**如果测试通过：** 报告就绪。

### 5. 报告位置

```
Worktree 就绪于 <full-path>
测试通过（<N>个测试，0个失败）
准备实现 <feature-name>
```

## 快速参考

| 情况 | 动作 |
|------|------|
| `.worktrees/` 存在 | 使用它（验证已忽略） |
| `worktrees/` 存在 | 使用它（验证已忽略） |
| 两者都存在 | 使用 `.worktrees/` |
| 都不存在 | 检查规则文件 → 询问用户 |
| 目录未被忽略 | 添加到 .gitignore + 提交 |
| 基线测试失败 | 报告失败 + 询问 |
| 无 package.json/Cargo.toml | 跳过依赖安装 |

## 常见错误

### 跳过忽略验证

- **问题：** Worktree内容被跟踪，污染git status
- **修复：** 创建项目本地worktree前始终使用 `git check-ignore`

### 假设目录位置

- **问题：** 创建不一致，违反项目约定
- **修复：** 遵循优先级：已有 > 规则文件 > 询问

### 在测试失败时继续

- **问题：** 无法区分新bug和已有问题
- **修复：** 报告失败，获得明确许可才继续

### 硬编码设置命令

- **问题：** 在使用不同工具的项目上失败
- **修复：** 从项目文件自动检测（package.json等）

## 示例工作流

```
你：我正在使用 using-git-worktrees 技能设置隔离工作区。

[检查 .worktrees/ - 存在]
[验证已忽略 - git check-ignore 确认 .worktrees/ 已被忽略]
[创建worktree：git worktree add .worktrees/auth -b feature/auth]
[运行 npm install]
[运行 npm test - 47通过]

Worktree 就绪于 /Users/jesse/myproject/.worktrees/auth
测试通过（47个测试，0个失败）
准备实现 auth 功能
```

## 红线

**绝不：**
- 创建worktree时不验证它已被忽略（项目本地）
- 跳过基线测试验证
- 在测试失败时不询问就继续
- 位置模糊时假设目录位置
- 跳过规则文件检查

**始终：**
- 遵循目录优先级：已有 > 规则文件 > 询问
- 验证项目本地目录已被忽略
- 自动检测并运行项目设置
- 验证干净的测试基线

## 输出

- Worktree 路径和分支名称
- 基线测试结果
- 项目设置完成状态

## 依赖

**被以下技能调用：**
- **brainstorming**（阶段4）— 设计批准后实现跟进时必需
- **subagent-driven-development** — 执行任何任务前必需
- **executing-plans** — 执行任何任务前必需
- 任何需要隔离工作区的技能

**配对使用：**
- **finishing-a-development-branch** — 工作完成后清理必需
