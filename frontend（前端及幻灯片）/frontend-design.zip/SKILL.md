---
name: frontend-design
description: 当用户要求构建Web组件、页面或应用，且视觉方向和代码质量同等重要时使用。不适用于纯功能性的后端或脚本任务。
---

# 前端设计

当任务不仅是"让它能跑"，而是"让它看起来经过设计"时使用本skill。

本skill适用于产品页面、仪表盘、应用壳、组件或视觉系统——这些需要明确的视觉方向，而非千篇一律的AI风格UI。

## 适用场景

- 从零构建落地页、仪表盘或应用界面
- 将平淡的界面升级为有意图、有记忆点的设计
- 将产品概念转化为具体的视觉方向
- 实现排版、构图和动效都至关重要的前端

## 核心原则

选定一个方向，贯彻到底。

安全平庸的UI通常不如一个有少数大胆选择的、强烈且连贯的美学方案。

## Phase 0: 风格发现与确认（强制前置步骤）

**在开始任何实现工作之前，必须先完成风格发现和用户确认。未经用户确认风格方向，不得进入实现阶段。**

此阶段使用 [Refero Styles](https://styles.refero.design/) 作为风格参考源。Refero Styles 提供从真实产品页面提取的语义化设计参考，包含完整的颜色令牌、排版令牌、间距令牌、组件规格和实现指南。

### 0.1 分析需求，提取搜索维度

根据用户需求，提取以下搜索维度：

- **行业/领域**：fintech, healthcare, SaaS, ecommerce, developer tool, creative, etc.
- **情感基调**：premium, playful, minimal, bold, calm, energetic, dark, editorial, etc.
- **视觉偏好**：dark/light 主题、彩色/单色、密集/疏朗、圆角/直角
- **品牌参考**：用户提到的具体品牌名（如 Linear, Apple, Vercel 等）

如果用户已明确指定风格方向（如"我要 Linear 那种深色风格"），可直接跳到 0.3 获取对应风格。

### 0.2 浏览 Refero 风格库

使用 WebFetch 访问 `https://styles.refero.design/` 浏览可用风格列表。

主页展示的风格卡片包含品牌名和简短描述，例如：
- "Linear — Midnight Command Center: A dark, layered interface lit by precise accents"（深色、技术感、精确）
- "Apple — Polished lens on innovation"（浅色、精致、产品导向）
- "Caldera — Pixelated Cyber-Playground"（像素化、趣味、赛博感）
- "Sequel — Black canvas, sharp typography"（黑色画布、锐利排版）
- "Relate — Blueprint on frosted linen"（磨砂质感、蓝图风格）
- "ElevenLabs — Architect's blueprint on warm…"（温暖蓝图、技术感）
- "Uber — Crisp monochrome canvas"（单色、利落）
- "Adora — Digital Canvas with Violet Bloom"（紫罗兰、数字画布）

根据 0.1 中提取的搜索维度，选择 **2-3 个** 最匹配的风格。选择时应：
- 覆盖不同的视觉方向（如一个深色+一个浅色，或一个极简+一个丰富）
- 优先选择与用户需求最匹配的风格
- 至少包含一个"安全"选项和一个"大胆"选项

### 0.3 获取风格详细设计令牌

对每个选中的风格，使用 WebFetch 访问其详情页获取完整的设计令牌。

**URL 格式**：`https://styles.refero.design/style/{style-uuid}`

UUID 从主页的风格卡片链接中提取。常见风格 UUID 参考：

| 品牌 | UUID |
|------|------|
| Linear | `90ce5883-bb24-4466-93f7-801cd617b0d1` |
| Apple | `a4f123f2-cd4b-4d26-998f-a3d3ee158024` |
| ElevenLabs | `031056ff-7af1-46db-8daa-115f731c5d26` |
| Sequel | `1bd3b2ba-9ad9-44ed-9130-03f9d94de821` |
| Uber | `caf8d2ef-4173-4431-9d26-05be0272e9f8` |
| Relate | `337ade6a-4bae-49ba-b4aa-8994ac805a81` |

*注意：UUID 可能随网站更新变化，始终以主页实际链接为准。*

每个风格详情页包含：

| 内容 | 用途 |
|------|------|
| 视觉论题（visual thesis） | 理解风格的核心设计意图 |
| 颜色令牌 + CSS Custom Properties | 直接用于实现的颜色系统 |
| 排版令牌（字体、字号、行高、字间距） | 排版系统 |
| 间距与形状令牌 | 间距节奏和圆角规范 |
| 组件规格（按钮、卡片、输入框等） | 具体组件的实现参考 |
| Do's and Don'ts 规则 | 避免偏离风格核心 |
| Agent Prompt Guide | 示例组件提示词，可直接用于生成代码 |
| CSS Custom Properties 代码块 | 可直接复制使用的完整令牌代码 |
| Tailwind v4 代码块 | Tailwind 项目的令牌代码 |

### 0.4 生成风格小样

为每个选中的风格生成一个 **自包含的 HTML 小样文件**，让用户直观比较不同风格。

小样必须包含：
- **颜色展示**：背景色、主文字色、强调色、次要色的色块和文字
- **排版展示**：标题（display/heading）、副标题、正文、注释的字体和大小
- **组件展示**：主要按钮、次要按钮、卡片、输入框
- **氛围展示**：背景处理、整体感觉

小样要求：
- 自包含 HTML 文件，内联 CSS
- 使用该风格的 CSS Custom Properties（从详情页的 Quick Start 部分复制）
- 约 80-150 行代码，保持简洁
- 保存到项目目录下的 `.style-previews/` 文件夹
- 文件命名：`style-preview-{品牌名小写}.html`

小样模板结构：

```html
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>风格预览 - {品牌名}</title>
<style>
/* 从 Refero 详情页 Quick Start 部分复制的 CSS Custom Properties */
:root { ... }
body { background: var(--{背景色token}); color: var(--{主文字色token}); font-family: var(--{字体token}); }
/* 排版展示 */
.display { font-size: var(--{display token}); font-weight: ...; letter-spacing: var(--{tracking token}); }
.heading { font-size: var(--{heading token}); ... }
.body { font-size: var(--{body token}); ... }
/* 组件展示 */
.btn-primary { background: var(--{CTA色token}); color: var(--{CTA文字色token}); border-radius: var(--{按钮圆角token}); }
.card { background: var(--{卡片背景token}); border-radius: var(--{卡片圆角token}); box-shadow: var(--{阴影token}); }
</style>
</head>
<body>
  <h1 class="display">{品牌名} 风格</h1>
  <p class="heading">{视觉论题}</p>
  <p class="body">正文示例文本</p>
  <button class="btn-primary">主要操作</button>
  <div class="card">卡片内容</div>
</body>
</html>
```

### 0.5 展示小样，等待用户选择

1. 向用户展示每个风格的：
   - 品牌名和视觉论题
   - 关键特征（主题明暗、主色、排版风格、密度）
2. 在浏览器中打开小样文件供用户直观比较
3. 使用 AskUserQuestion 询问用户选择哪个风格，或希望混合哪些元素

**⚠️ 不得在用户做出选择之前开始任何实现工作。**

如果用户不满意任何选项：
- 询问更具体的偏好方向
- 重新浏览 Refero 寻找更匹配的风格
- 重复 0.2-0.5

### 0.6 锁定风格方向

用户选择后，创建风格锁定记录：

```text
主参考风格：[风格名称 — 视觉论题]
保留特征：
  - [例如：深色画布 #08090a]
  - [例如：Neon Lime 强调色仅用于 CTA]
  - [例如：Inter Variable 字体 + 紧凑字间距]
  - [例如：6px 圆角统一]
  - [例如：紧凑密度，8px 元素间距]
借用细节：[1-2 个从其他风格借用的具体细节，如有]
令牌承诺：[背景色、主文字色、强调色、圆角、边框/阴影、图像处理方式]
拒绝：[会削弱方向的默认值/平均值]
```

如果实现过程中偏离了风格锁定，必须停止并纠正。不要将独特特征弱化为更安全的颜色、更安全的字体、更柔和的圆角或通用的布局。

### 可选增强：Refero MCP

如果环境中配置了 Refero MCP（付费服务），可使用 MCP 工具获得更强大的搜索能力：
- `refero_search_styles`：按关键词搜索风格
- `refero_get_style`：获取风格完整详情

Refero MCP 配置方法详见：https://refero.design/mcp

### 回退方案

如果 Refero 风格库不可用（网络问题等），回退到本 skill 原有的设计工作流，使用下方的"可选方向"列表和"强力默认值"进行风格选择，但仍需生成小样供用户确认后才可开工。

## 设计工作流

### 1. 先框定界面

编码之前，确定：

- 目的
- 受众
- 情感基调
- 视觉方向
- 用户应该记住的一件事

**如果已完成 Phase 0，视觉方向和情感基调已由风格锁定确定，直接使用锁定值，跳过此步骤的方向选择。**

可选方向（仅在未使用 Refero 风格参考时使用）：

- 极简主义
- 编辑风格
- 工业风格
- 奢华风格
- 俏皮风格
- 几何风格
- 复古未来主义
- 柔和有机
- 极繁主义

不要随意混合方向。选择一个并干净地执行。

### 2. 构建视觉系统

**如果已完成 Phase 0，直接使用锁定风格的 CSS Custom Properties 作为视觉系统基础，从 Refero 详情页的 Quick Start 部分复制令牌代码。**

否则，定义：

- type hierarchy
- color variables
- spacing rhythm
- layout logic
- motion rules
- surface / border / shadow treatment

使用CSS变量或项目的token系统，确保界面在扩展时保持一致性。

### 3. 有意图地构图

优先采用：

- 当不对称能强化层级时使用不对称
- 当重叠能创造深度时使用重叠
- 当大量留白能明确焦点时使用大量留白
- 仅当产品受益于密度时使用密集布局

除非明显是最合适的方案，否则不要默认使用对称卡片网格。

### 4. 让动效有意义

使用动画来：

- 揭示层级
- 分阶段呈现信息
- 强化用户操作
- 创造一两个令人印象深刻的时刻

不要到处散布通用的微交互。一个精心设计的加载序列通常比二十个随意的hover效果更有力。

## 强力默认值

### 排版

- 选择有个性的字体
- 适当时搭配一个有辨识度的展示字体和一个易读的正文字体
- 当页面以设计为主导时，避免使用通用默认字体

### 色彩

- 坚持一个明确的调色板
- 一个主色域加上选择性强调色通常比等权重的彩虹调色板效果更好
- 除非产品确实需要，否则避免老套的紫色渐变配白色

### 背景

使用氛围感：

- gradients
- meshes
- textures
- subtle noise
- patterns
- layered transparency

对于面向产品的页面，平坦空白的背景很少是最佳选择。

### 布局

- 当构图受益时打破网格
- 有意图地使用对角线、偏移和分组
- 即使布局不常规，也要保持阅读流清晰

## 反模式

永远不要默认使用：

- 千篇一律的SaaS hero区域
- 没有层级的通用卡片堆
- 没有系统的随机强调色
- 像占位符的排版
- 仅仅因为动画容易添加就存在的动效

## 执行规则

- 在现有产品中工作时，保持已建立的设计系统
- 技术复杂度与视觉理念相匹配
- 保持可访问性和响应式完好
- 前端在桌面和移动端都应有明确的设计意图

## 质量关卡

交付前确认：

- 界面有明确的视觉观点
- 排版和间距感觉是有意图的
- 色彩和动效服务于产品，而非随机装饰
- 结果不像通用的AI UI
- 实现是生产级别的，而不仅仅是视觉上有趣
- **如果使用了 Refero 风格参考：实现是否忠实于风格锁定的令牌承诺？**
- **如果使用了 Refero 风格参考：是否有令牌被用于非原始角色（如CTA色被用作背景色）？**

## 不适用场景

- 纯后端API开发或脚本编写
- 不需要视觉设计的功能性工具
- 仅需逻辑实现而无UI需求的功能
- 已有完整设计稿仅需像素级还原（无设计决策空间）

## 输出

- 可运行的HTML/CSS/JS代码文件
- CSS变量或token定义的视觉系统
- 响应式且可访问的界面实现

注意：SOLO Builder 适用于从0到1构建Web应用，本skill提供更精细的视觉设计指导，可与SOLO Builder配合使用。

## 依赖

- frontend-patterns（组件和交互模式参考）
