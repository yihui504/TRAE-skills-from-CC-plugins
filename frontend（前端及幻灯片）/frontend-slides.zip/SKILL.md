---
name: frontend-slides
description: 当需要创建HTML演示文稿或将PPT转为Web幻灯片时使用。不适用于非演示类前端开发。
---

# 前端幻灯片

创建零依赖、动画丰富的HTML演示文稿，完全在浏览器中运行。

灵感来源于视觉探索方法。

## 适用场景

- 创建演讲、路演、工作坊或内部演示文稿
- 将 `.ppt` 或 `.pptx` 幻灯片转换为HTML演示文稿
- 改进现有HTML演示文稿的布局、动效或排版
- 与尚不确定设计偏好的用户一起探索演示风格

## 不可妥协的原则

1. **零依赖**：默认输出一个自包含的HTML文件，内联CSS和JS。
2. **视口适配是强制的**：每张幻灯片必须适配一个视口，无内部滚动。
3. **展示而非讲述**：使用视觉预览代替抽象的风格问卷。
4. **独特设计**：避免通用的紫色渐变、Inter-on-white、模板感的演示文稿。
5. **生产质量**：代码保持可访问、响应式和高性能。

生成前，阅读 `resources/STYLE_PRESETS.md` 获取视口安全的CSS基础、密度限制、预设目录和CSS注意事项。

## 依赖

- `frontend-patterns`：提供组件和交互模式参考，用于幻灯片中的复杂交互组件实现。

## 工作流

### 1. 检测模式

选择一条路径：
- **新建演示文稿**：用户有主题、笔记或完整草稿
- **PPT转换**：用户有 `.ppt` 或 `.pptx`
- **增强**：用户已有HTML幻灯片并希望改进

### 2. 发掘内容

仅询问最少必要信息：
- 目的：路演、教学、会议演讲、内部汇报
- 长度：短（5-10）、中（10-20）、长（20+）
- 内容状态：完稿、粗略笔记、仅主题

如果用户有内容，请他们在样式化之前粘贴。

### 3. 发掘风格

默认使用视觉探索。

如果用户已知想要的预设，跳过预览直接使用。

否则：
1. 询问演示文稿应营造什么感觉：印象深刻、充满活力、专注、受启发。
2. 在 `.ecc-design/slide-previews/` 中生成 **3个单页预览文件**。
3. 每个预览必须自包含，清晰展示排版/色彩/动效，幻灯片内容保持在约100行以内。
4. 询问用户保留哪个预览或混合哪些元素。

映射情绪到风格时使用 `resources/STYLE_PRESETS.md` 中的预设指南。

### 4. 构建演示文稿

输出：
- `presentation.html`
- 或 `[presentation-name].html`

仅当演示文稿包含提取或用户提供的图片时使用 `assets/` 文件夹。

必需结构：
- semantic slide sections
- 来自 `resources/STYLE_PRESETS.md` 的视口安全CSS基础
- CSS custom properties for theme values
- presentation controller class for keyboard, wheel, and touch navigation
- Intersection Observer for reveal animations
- reduced-motion support

### 5. 强制视口适配

将此视为硬性关卡。

规则：
- 每个 `.slide` 必须使用 `height: 100vh; height: 100dvh; overflow: hidden;`
- 所有排版和间距必须使用 `clamp()` 缩放
- 当内容不适配时，拆分为多张幻灯片
- 永远不要通过将文字缩小到不可读大小来解决溢出
- 永远不允许幻灯片内出现滚动条

使用 `resources/STYLE_PRESETS.md` 中的密度限制和强制CSS块。

### 6. 验证

在以下尺寸检查完成的演示文稿：
- 1920x1080
- 1280x720
- 768x1024
- 375x667
- 667x375

如果浏览器自动化可用，使用它验证无幻灯片溢出且键盘导航正常。

### 7. 交付

交接时：
- 删除临时预览文件，除非用户想保留
- 适当时使用平台对应的打开器打开演示文稿
- 总结文件路径、使用的预设、幻灯片数量和便捷的主题自定义点

使用当前OS对应的打开器：
- macOS: `open file.html`
- Linux: `xdg-open file.html`
- Windows: `start "" file.html`

## PPT / PPTX 转换

PowerPoint转换：
1. 优先使用 `python3` 配合 `python-pptx` 提取文本、图片和备注。
2. 如果 `python-pptx` 不可用，询问是否安装或回退到手动/导出工作流。
3. 保留幻灯片顺序、演讲者备注和提取的资源。
4. 提取后，运行与新建演示文稿相同的风格选择工作流。

保持转换跨平台。当Python可以完成工作时，不要依赖仅限macOS的工具。

## 实现要求

### HTML / CSS

- 使用内联CSS和JS，除非用户明确需要多文件项目。
- 字体可来自Google Fonts或Fontshare。
- 优先使用氛围感背景、强排版层级和明确的视觉方向。
- 使用抽象形状、渐变、网格、噪点和几何图形而非插图。

### JavaScript

包含：
- keyboard navigation
- touch / swipe navigation
- mouse wheel navigation
- progress indicator or slide index
- reveal-on-enter animation triggers

### 可访问性

- 使用语义结构（`main`、`section`、`nav`）
- 保持对比度可读
- 支持仅键盘导航
- 尊重 `prefers-reduced-motion`

## 内容密度限制

除非用户明确要求更密集的幻灯片且可读性仍可保证，否则使用以下最大值：

| 幻灯片类型 | 限制 |
|------------|------|
| 标题页 | 1个标题 + 1个副标题 + 可选标语 |
| 内容页 | 1个标题 + 4-6个要点或2个短段落 |
| 特性网格 | 最多6张卡片 |
| 代码页 | 最多8-10行 |
| 引用页 | 1条引用 + 出处 |
| 图片页 | 1张受视口约束的图片 |

## 反模式

- 没有视觉识别的通用创业渐变
- 除非有意为之的编辑风格，否则使用系统字体
- 长篇要点墙
- 需要滚动的代码块
- 在短屏幕上会断裂的固定高度内容框
- 无效的否定CSS函数如 `-clamp(...)`

## 交付清单

- 演示文稿可从本地文件在浏览器中运行
- 每张幻灯片适配视口，无需滚动
- 风格独特且有意为之
- 动画有意义，而非喧宾夺主
- 尊重减少动效偏好
- 交接时说明文件路径和自定义点

## 不适用场景

- 非演示类前端开发（如Web应用、仪表盘）
- 需要PowerPoint原生功能（如嵌入Excel、VBA宏）的场景
- 需要服务端渲染或后端集成的项目
- 纯文本内容输出（无视觉呈现需求）

## 输出

- 自包含的HTML演示文稿文件
- 可选的 `assets/` 图片资源目录
- 交付时的文件路径、预设、幻灯片数量和自定义点说明

## 相关技能

- `frontend-patterns`：用于幻灯片中的组件和交互模式参考

## 依赖

- frontend-patterns（组件和交互模式参考）
- frontend-design（视觉系统定义参考）

注意：本skill创建零依赖HTML演示文稿，在SOLO Coder中可直接使用。
