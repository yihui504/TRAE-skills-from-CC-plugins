---
name: frontend-slides
description: 当需要创建HTML演示文稿或将PPT转为Web幻灯片时使用。不适用于非演示类前端开发。
---

# 前端幻灯片

创建零依赖、动画丰富的HTML演示文稿，完全在浏览器中运行。

灵感来源于视觉探索方法。

## 适用场景

- 创建演讲、路演、工作坊或内部演示文稿
- 将 `.ppt` 或 `.pptx` 幻灯片转换为HTML演示文稿
- 改进现有HTML演示文稿的布局、动效或排版
- 与尚不确定设计偏好的用户一起探索演示风格

## 不可妥协的原则

1. **零依赖**：默认输出一个自包含的HTML文件，内联CSS和JS。
2. **视口适配是强制的**：每张幻灯片必须适配一个视口，无内部滚动。
3. **展示而非讲述**：使用视觉预览代替抽象的风格问卷。
4. **独特设计**：避免通用的紫色渐变、Inter-on-white、模板感的演示文稿。
5. **生产质量**：代码保持可访问、响应式和高性能。
6. **风格先行**：开工前必须先发现并确认风格方向。

生成前，阅读 `resources/STYLE_PRESETS.md` 获取视口安全的CSS基础、密度限制、预设目录和CSS注意事项。

## 依赖

- `frontend-patterns`：提供组件和交互模式参考，用于幻灯片中的复杂交互组件实现。
- `frontend-design`：提供视觉系统定义参考。

## 工作流

### 1. 检测模式

选择一条路径：
- **新建演示文稿**：用户有主题、笔记或完整草稿
- **PPT转换**：用户有 `.ppt` 或 `.pptx`
- **增强**：用户已有HTML幻灯片并希望改进

### 2. 发掘内容

仅询问最少必要信息：
- 目的：路演、教学、会议演讲、内部汇报
- 长度：短（5-10）、中（10-20）、长（20+）
- 内容状态：完稿、粗略笔记、仅主题

如果用户有内容，请他们在样式化之前粘贴。

### 3. 发掘风格（强制：Refero 优先 + 内置预设回退）

**此步骤是强制的。不得跳过风格确认直接开始构建演示文稿。**

风格发现采用双源策略：优先使用 Refero Styles 获取真实产品的设计令牌，内置预设作为回退和补充。

#### 3a. Refero 风格发现（优先）

**步骤：**

1. **分析演示需求**，提取搜索维度：
   - 演示目的和受众
   - 期望的情感基调（impressed, excited, calm, inspired）
   - 视觉偏好（dark/light, colorful/monochrome, dense/spacious）

2. **浏览 Refero 风格库**：使用 WebFetch 访问 `https://styles.refero.design/`

   主页展示的风格卡片包含品牌名和简短描述，例如：
   - "Linear — Midnight Command Center"（深色、技术感、精确）→ 适合技术演讲、开发者工具路演
   - "Apple — Polished lens on innovation"（浅色、精致、产品导向）→ 适合产品发布、高端路演
   - "Sequel — Black canvas, sharp typography"（黑色画布、锐利排版）→ 适合时尚、编辑风格演示
   - "ElevenLabs — Architect's blueprint on warm…"（温暖蓝图）→ 适合 AI/技术主题
   - "Uber — Crisp monochrome canvas"（单色、利落）→ 适合商务、数据驱动演示

3. **选择 2-3 个匹配风格**，使用 WebFetch 获取详情页的设计令牌：
   - URL 格式：`https://styles.refero.design/style/{style-uuid}`
   - 从详情页提取：颜色令牌、排版令牌、间距令牌、组件规格、CSS Custom Properties 代码块

4. **为每个风格生成单页预览**：
   - 自包含 HTML 文件，内联 CSS
   - 使用该风格的 CSS Custom Properties
   - 展示一张代表性幻灯片（标题 + 副标题 + 1-2 个组件）
   - 保存到 `.style-previews/` 目录
   - 文件命名：`slide-preview-{品牌名小写}.html`

5. **展示预览，等待用户选择**

#### 3b. 内置预设（回退/补充）

如果 Refero 不可用，或用户希望看到更多选项，使用 `resources/STYLE_PRESETS.md` 中的内置预设。

映射情绪到预设时使用 `resources/STYLE_PRESETS.md` 中的 Mood to Preset Mapping：

| Mood | Good Presets |
|------|--------------|
| Impressed / Confident | Bold Signal, Electric Studio, Dark Botanical |
| Excited / Energized | Creative Voltage, Neon Cyber, Split Pastel |
| Calm / Focused | Notebook Tabs, Paper & Ink, Swiss Modern |
| Inspired / Moved | Dark Botanical, Vintage Editorial, Pastel Geometry |

同样为 2-3 个预设生成单页预览文件。

#### 3c. 混合策略

也可以混合使用 Refero 风格和内置预设：
- 用 Refero 风格提供颜色/排版/间距令牌
- 用内置预设提供幻灯片特有的布局和动效模式
- 例如：使用 Linear 的颜色和排版令牌 + Neon Cyber 的动效模式

#### 3d. 用户确认

**⚠️ 不得在用户做出风格选择之前开始构建演示文稿。**

如果用户已知想要的预设或 Refero 风格，跳过预览直接使用。

否则：
1. 在浏览器中打开预览文件供用户比较
2. 使用 AskUserQuestion 询问用户保留哪个预览或混合哪些元素
3. 锁定风格方向

#### 3e. 风格锁定

用户选择后，记录：

```text
风格来源：[Refero 风格名 / 内置预设名 / 混合]
主参考：[名称 — 描述]
保留特征：[3-5 个必须保留的视觉特质]
借用细节：[从其他来源借用的元素，如有]
令牌承诺：[背景、字体、强调色、圆角、动效风格]
拒绝：[会削弱方向的默认值]
```

### 4. 构建演示文稿

输出：
- `presentation.html`
- 或 `[presentation-name].html`

仅当演示文稿包含提取或用户提供的图片时使用 `assets/` 文件夹。

必需结构：
- semantic slide sections
- 来自 `resources/STYLE_PRESETS.md` 的视口安全CSS基础
- **如果锁定了 Refero 风格：使用其 CSS Custom Properties 作为主题令牌**
- CSS custom properties for theme values
- presentation controller class for keyboard, wheel, and touch navigation
- Intersection Observer for reveal animations
- reduced-motion support

### 5. 强制视口适配

将此视为硬性关卡。

规则：
- 每个 `.slide` 必须使用 `height: 100vh; height: 100dvh; overflow: hidden;`
- 所有排版和间距必须使用 `clamp()` 缩放
- 当内容不适配时，拆分为多张幻灯片
- 永远不要通过将文字缩小到不可读大小来解决溢出
- 永远不允许幻灯片内出现滚动条

使用 `resources/STYLE_PRESETS.md` 中的密度限制和强制CSS块。

### 6. 验证

在以下尺寸检查完成的演示文稿：
- 1920x1080
- 1280x720
- 768x1024
- 375x667
- 667x375

如果浏览器自动化可用，使用它验证无幻灯片溢出且键盘导航正常。

### 7. 交付

交接时：
- 删除临时预览文件，除非用户想保留
- 适当时使用平台对应的打开器打开演示文稿
- 总结文件路径、使用的预设/Refero风格、幻灯片数量和便捷的主题自定义点

使用当前OS对应的打开器：
- macOS: `open file.html`
- Linux: `xdg-open file.html`
- Windows: `start "" file.html`

## PPT / PPTX 转换

PowerPoint转换：
1. 优先使用 `python3` 配合 `python-pptx` 提取文本、图片和备注。
2. 如果 `python-pptx` 不可用，询问是否安装或回退到手动/导出工作流。
3. 保留幻灯片顺序、演讲者备注和提取的资源。
4. 提取后，运行与新建演示文稿相同的风格选择工作流（步骤3）。

保持转换跨平台。当Python可以完成工作时，不要依赖仅限macOS的工具。

## 实现要求

### HTML / CSS

- 使用内联CSS和JS，除非用户明确需要多文件项目。
- 字体可来自Google Fonts或Fontshare。
- 优先使用氛围感背景、强排版层级和明确的视觉方向。
- 使用抽象形状、渐变、网格、噪点和几何图形而非插图。
- **如果锁定了 Refero 风格，使用其颜色令牌和排版令牌作为 CSS Custom Properties。**

### JavaScript

包含：
- keyboard navigation
- touch / swipe navigation
- mouse wheel navigation
- progress indicator or slide index
- reveal-on-enter animation triggers

### 可访问性

- 使用语义结构（`main`、`section`、`nav`）
- 保持对比度可读
- 支持仅键盘导航
- 尊重 `prefers-reduced-motion`

## 内容密度限制

除非用户明确要求更密集的幻灯片且可读性仍可保证，否则使用以下最大值：

| 幻灯片类型 | 限制 |
|------------|------|
| 标题页 | 1个标题 + 1个副标题 + 可选标语 |
| 内容页 | 1个标题 + 4-6个要点或2个短段落 |
| 特性网格 | 最多6张卡片 |
| 代码页 | 最多8-10行 |
| 引用页 | 1条引用 + 出处 |
| 图片页 | 1张受视口约束的图片 |

## 反模式

- 没有视觉识别的通用创业渐变
- 除非有意为之的编辑风格，否则使用系统字体
- 长篇要点墙
- 需要滚动的代码块
- 在短屏幕上会断裂的固定高度内容框
- 无效的否定CSS函数如 `-clamp(...)`
- **未确认风格方向就直接开始构建**

## 交付清单

- 演示文稿可从本地文件在浏览器中运行
- 每张幻灯片适配视口，无需滚动
- 风格独特且有意为之
- 动画有意义，而非喧宾夺主
- 尊重减少动效偏好
- 交接时说明文件路径和自定义点
- **风格方向已经用户确认**

## 不适用场景

- 非演示类前端开发（如Web应用、仪表盘）
- 需要PowerPoint原生功能（如嵌入Excel、VBA宏）的场景
- 需要服务端渲染或后端集成的项目
- 纯文本内容输出（无视觉呈现需求）

## 输出

- 自包含的HTML演示文稿文件
- 可选的 `assets/` 图片资源目录
- 交付时的文件路径、预设/Refero风格、幻灯片数量和自定义点说明

## 相关技能

- `frontend-patterns`：用于幻灯片中的组件和交互模式参考

## 依赖

- frontend-patterns（组件和交互模式参考）
- frontend-design（视觉系统定义参考）

注意：本skill创建零依赖HTML演示文稿，在SOLO Coder中可直接使用。
