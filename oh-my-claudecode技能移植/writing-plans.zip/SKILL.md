---
name: writing-plans
description: "当有多步骤任务的规格或需求需要在编写代码前规划时使用"
---

# Writing Plans

## 描述

编写全面的实现计划，假设工程师对代码库零上下文且品味存疑。文档化他们需要知道的一切：每个任务要触及哪些文件、代码、测试、可能需要查阅的文档、如何测试。以小口任务的形式给出整个计划。DRY。YAGNI。TDD。频繁提交。

假设他们是熟练的开发者，但对我们的工具集或问题领域几乎一无所知。假设他们不太了解好的测试设计。

**开始时宣布：** "我正在使用 writing-plans 技能创建实现计划。"

**保存计划到：** `.trae/plans/YYYY-MM-DD-<feature-name>.md`
- （用户对计划位置的首选项覆盖此默认值）

## 使用场景

- 有规格或需求需要多步骤实现
- 需要为其他工程师（或代理）编写详细实现计划
- 任务复杂，需要分解为小步骤
- 想要确保 TDD 方法和频繁提交

注意：SOLO Coder 内置 Plan 模式（/Plan），本skill提供更详细的计划编写指导，可与Plan模式配合使用。

## 不适用场景

- 任务简单，可以直接实现 → 直接做
- 只需要高层规划 → 使用 omc-plan
- 已有详细计划 → 直接执行

## 指令

### 范围检查

如果规格覆盖多个独立子系统，它应该在头脑风暴期间被分解为子项目规格。如果没有，建议分解为单独的计划——每个子系统一个。每个计划应独立产出可工作的、可测试的软件。

### 文件结构

在定义任务之前，先映射出哪些文件将被创建或修改以及每个文件负责什么。这是分解决策被锁定的地方。

- 设计具有清晰边界和定义良好接口的单元。每个文件应有一个清晰的职责。
- 你对一次能保持在上下文中的代码推理最好，当文件聚焦时你的编辑更可靠。优先选择较小的、聚焦的文件而非做太多事情的大文件。
- 一起变更的文件应该放在一起。按职责分割，而非按技术层。
- 在现有代码库中，遵循既定模式。如果代码库使用大文件，不要单方面重构——但如果你正在修改的文件已经变得笨拙，在计划中包含分割是合理的。

此结构指导任务分解。每个任务应产出独立有意义的自包含变更。

### 小口任务粒度

**每个步骤是一个动作（2-5 分钟）：**
- "写失败的测试" - 步骤
- "运行它以确保它失败" - 步骤
- "实现使测试通过的最小代码" - 步骤
- "运行测试并确保它们通过" - 步骤
- "提交" - 步骤

### 计划文档头部

**每个计划必须以此头部开始：**

```markdown
# [Feature Name] Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** [一句话描述这构建什么]

**Architecture:** [2-3 句关于方法]

**Tech Stack:** [关键技术/库]

---
```

### 任务结构

````markdown
### Task N: [Component Name]

**Files:**
- Create: `exact/path/to/file.py`
- Modify: `exact/path/to/existing.py:123-145`
- Test: `tests/exact/path/to/test.py`

- [ ] **Step 1: Write the failing test**

```python
def test_specific_behavior():
    result = function(input)
    assert result == expected
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/path/test.py::test_name -v`
Expected: FAIL with "function not defined"

- [ ] **Step 3: Write minimal implementation**

```python
def function(input):
    return expected
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/path/test.py::test_name -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add tests/path/test.py src/path/file.py
git commit -m "feat: add specific feature"
```
````

### 记住
- 始终使用精确文件路径
- 计划中包含完整代码（而非"添加验证"）
- 包含预期输出的精确命令
- 使用 @ 语法引用相关技能
- DRY, YAGNI, TDD, 频繁提交

### 计划审查循环

编写完整计划后：

1. 派遣一个 backend-architect 子代理（带审查指令）进行计划审查——绝不使用你的会话历史。这保持审查者专注于计划，而非你的思考过程。
   - 提供：计划文档路径、规格文档路径
2. 如果发现问题：修复问题，重新派遣审查者审查整个计划
3. 如果批准：继续执行交接

**审查循环指导：**
- 写计划的同一代理修复它（保留上下文）
- 如果循环超过 3 次迭代，提交给人类指导
- 审查者是顾问性的——如果你认为反馈不正确，解释分歧

### 执行交接

保存计划后，提供执行选择：

**"计划完成并保存到 `.trae/plans/<filename>.md`。两种执行选项：**

**1. Subagent-Driven（推荐）** - 每个任务派遣一个新子代理，任务间审查，快速迭代

**2. Inline Execution** - 在此会话中使用 executing-plans 执行，带检查点的批量执行

**选择哪种方式？"**

## 输出

保存到 `.trae/plans/` 的详细实现计划，包含任务分解、代码片段和验证步骤。

## 依赖

无
