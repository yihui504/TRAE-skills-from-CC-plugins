---
name: ask
description: "当需要通过本地 CLI 路由提示到 Claude/Codex/Gemini 并持久化结果时使用"
---

# Ask

使用 OMC 的规范顾问技能，将提示路由通过本地 Claude、Codex 或 Gemini CLI，并将结果持久化为 ask 制品。

## 使用场景

- 需要通过本地 CLI 向不同 AI 提供商发送提示并保存结果
- 想要利用特定提供商的能力（安全审查、UX 建议、实现规划等）
- 需要跨提供商比较回答

注意：本skill在SOLO Coder中通过对话方式使用，无需特殊配置。

## 不适用场景

- 只需要简单对话式回答，无需持久化 → 直接对话
- 不需要多提供商路由 → 直接使用对应 CLI
- 任务完全可以在当前会话中完成 → 无需外部路由

## 指令

### 路由

**必须使用的执行路径：**

```bash
omc ask <claude|codex|gemini> <question or task>
```

**不要手动构建原始提供商 CLI 命令。** 绝不直接运行 `codex`、`claude` 或 `gemini` 来完成此技能。`omc ask` 包装器自动处理正确的标志选择、制品持久化和提供商版本兼容性。

### 要求

- 所选本地 CLI 必须已安装并认证
- 用对应命令验证可用性：

```bash
claude --version
codex --version
gemini --version
```

### 制品

`omc ask` 将制品写入：

```text
.trae/artifacts/ask/<provider>--<slug>.md
```

## 输出

持久化的 ask 制品文件，包含提供商回答和元数据。

## 依赖

无
