---
name: deepinit
description: "当需要为代码库创建层级式 AI 可读文档时使用"
---

# Deep Init

## 描述

创建全面的、层级式的 AGENTS.md 文档，覆盖整个代码库。

## 使用场景

- 新项目需要 AI 可读的代码库文档
- 现有代码库缺少结构化文档，AI 代理难以理解
- 需要为每个目录生成包含目的、关键文件、子目录和 AI 工作说明的文档
- 代码库结构发生变化，需要更新 AGENTS.md

注意：本skill生成的AGENTS.md文档可帮助SOLO Coder更好地理解项目结构。

## 不适用场景

- 只需要单个文件的文档 → 直接添加注释
- 项目非常小（1-2个文件）→ 不需要层级文档
- 只需要更新现有 AGENTS.md 的一小部分 → 手动编辑

## 指令

### 核心概念

AGENTS.md 文件作为**AI 可读文档**，帮助代理理解：
- 每个目录包含什么
- 组件之间如何关联
- 在该区域工作的特殊说明
- 依赖和关系

### 层级标签系统

每个 AGENTS.md（根目录除外）包含父引用标签：

```markdown
<!-- Parent: ../AGENTS.md -->
```

这创建可导航的层级：
```
/AGENTS.md                          ← 根（无父标签）
├── src/AGENTS.md                   ← <!-- Parent: ../AGENTS.md -->
│   ├── src/components/AGENTS.md    ← <!-- Parent: ../AGENTS.md -->
│   └── src/utils/AGENTS.md         ← <!-- Parent: ../AGENTS.md -->
└── docs/AGENTS.md                  ← <!-- Parent: ../AGENTS.md -->
```

### AGENTS.md 模板

```markdown
<!-- Parent: {relative_path_to_parent}/AGENTS.md -->
<!-- Generated: {timestamp} | Updated: {timestamp} -->

# {Directory Name}

## Purpose
{一段描述此目录包含什么及其角色}

## Key Files
{列出每个重要文件及一行描述}

| File | Description |
|------|-------------|
| `file.ts` | 简要描述用途 |

## Subdirectories
{列出每个子目录及简要目的}

| Directory | Purpose |
|-----------|---------|
| `subdir/` | 包含什么（见 `subdir/AGENTS.md`） |

## For AI Agents

### Working In This Directory
{AI 代理在此目录修改文件的特殊说明}

### Testing Requirements
{如何测试此目录中的变更}

### Common Patterns
{此处使用的代码模式或约定}

## Dependencies

### Internal
{引用此依赖的代码库其他部分}

### External
{使用的关键外部包/库}

<!-- MANUAL: 此行以下手动添加的笔记在重新生成时保留 -->
```

### 执行工作流

#### Step 1: 映射目录结构

```
Task(subagent_type="explore",
  prompt="List all directories recursively. Exclude: node_modules, .git, dist, build, __pycache__, .venv, coverage, .next, .nuxt")
```

#### Step 2: 创建工作计划

为每个目录生成待办事项，按深度级别组织：

```
Level 0: / (root)
Level 1: /src, /docs, /tests
Level 2: /src/components, /src/utils, /docs/api
...
```

#### Step 3: 按级别生成

**重要**：先生成父级别再生成子级别，以确保父引用有效。

对每个目录：
1. 读取目录中的所有文件
2. 分析目的和关系
3. 生成 AGENTS.md 内容
4. 写入文件并包含正确的父引用

#### Step 4: 比较和更新（如果存在）

当 AGENTS.md 已存在时：

1. **读取现有内容**
2. **识别部分**：
   - 自动生成部分（可更新）
   - 手动部分（`<!-- MANUAL -->` 保留）
3. **比较**：
   - 新增文件？
   - 删除文件？
   - 结构变更？
4. **合并**：
   - 更新自动生成内容
   - 保留手动注释
   - 更新时间戳

#### Step 5: 验证层级

生成后运行验证检查：

| 检查 | 如何验证 | 纠正措施 |
|-------|--------------|-------------------|
| 父引用可解析 | 读取每个 AGENTS.md，检查 `<!-- Parent: -->` 路径存在 | 修复路径或移除孤立文件 |
| 无孤立 AGENTS.md | 比较 AGENTS.md 位置与目录结构 | 删除孤立文件 |
| 完整性 | 列出所有目录，检查 AGENTS.md | 生成缺失文件 |
| 时间戳当前 | 检查 `<!-- Generated: -->` 日期 | 重新生成过时文件 |

验证脚本模式：
```bash
find . -name "AGENTS.md" -type f
grep -r "<!-- Parent:" --include="AGENTS.md" .
```

### 智能委派

| 任务 | 代理 |
|------|-------|
| 目录映射 | `explore` |
| 文件分析 | `backend-architect` |
| 内容生成 | `backend-architect` |
| AGENTS.md 写入 | `backend-architect` |

### 空目录处理

| 条件 | 动作 |
|-----------|--------|
| 无文件，无子目录 | **跳过** - 不创建 AGENTS.md |
| 无文件，有子目录 | 创建仅含子目录列表的最小 AGENTS.md |
| 仅有生成文件 (*.min.js, *.map) | 跳过或最小 AGENTS.md |
| 仅有配置文件 | 创建描述配置目的的 AGENTS.md |

### 并行化规则

1. **同级别目录**：并行处理
2. **不同级别**：顺序处理（父级优先）
3. **大型目录**：每个目录生成专用代理
4. **小型目录**：将多个批量到一个代理

### 质量标准

必须包含：
- 准确的文件描述
- 正确的父引用
- 子目录链接
- AI 代理说明

必须避免：
- 通用样板文本
- 不正确的文件名
- 损坏的父引用
- 遗漏重要文件

### 示例输出

#### 根 AGENTS.md
```markdown
<!-- Generated: 2024-01-15 | Updated: 2024-01-15 -->

# my-project

## Purpose
A web application for managing user tasks with real-time collaboration features.

## Key Files
| File | Description |
|------|-------------|
| `package.json` | Project dependencies and scripts |
| `tsconfig.json` | TypeScript configuration |
| `.env.example` | Environment variable template |

## Subdirectories
| Directory | Purpose |
|-----------|---------|
| `src/` | Application source code (see `src/AGENTS.md`) |
| `docs/` | Documentation (see `docs/AGENTS.md`) |
| `tests/` | Test suites (see `tests/AGENTS.md`) |

## For AI Agents

### Working In This Directory
- Always install dependencies after modifying the project manifest
- Use TypeScript strict mode
- Follow ESLint rules

### Testing Requirements
- Run tests before committing
- Ensure >80% coverage

### Common Patterns
- Use barrel exports (index.ts)
- Prefer functional components

## Dependencies

### External
- React 18.x - UI framework
- TypeScript 5.x - Type safety
- Vite - Build tool

<!-- MANUAL: Custom project notes can be added below -->
```

#### 嵌套 AGENTS.md
```markdown
<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2024-01-15 | Updated: 2024-01-15 -->

# components

## Purpose
Reusable React components organized by feature and complexity.

## Key Files
| File | Description |
|------|-------------|
| `index.ts` | Barrel export for all components |
| `Button.tsx` | Primary button component |
| `Modal.tsx` | Modal dialog component |

## Subdirectories
| Directory | Purpose |
|-----------|---------|
| `forms/` | Form-related components (see `forms/AGENTS.md`) |
| `layout/` | Layout components (see `layout/AGENTS.md`) |

## For AI Agents

### Working In This Directory
- Each component has its own file
- Use CSS modules for styling
- Export via index.ts

### Testing Requirements
- Unit tests in `__tests__/` subdirectory
- Use React Testing Library

### Common Patterns
- Props interfaces defined above component
- Use forwardRef for DOM-exposing components

## Dependencies

### Internal
- `src/hooks/` - Custom hooks used by components
- `src/utils/` - Utility functions

### External
- `clsx` - Conditional class names
- `lucide-react` - Icons

<!-- MANUAL: -->
```

### 性能考虑

- **缓存目录列表** - 不要重复扫描相同目录
- **批量处理小目录** - 一次处理多个
- **跳过未变更** - 如果目录未变更，跳过重新生成
- **并行写入** - 多个代理同时写入不同文件

## 输出

覆盖整个代码库的层级式 AGENTS.md 文件集。

## 依赖

无
