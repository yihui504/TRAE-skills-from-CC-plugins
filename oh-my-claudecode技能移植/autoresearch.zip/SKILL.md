---
name: autoresearch
description: "当需要带评估器驱动的单任务迭代改进循环时使用"
---

# autoresearch

## 描述

Autoresearch 是有状态的单任务迭代改进技能。它一次只处理一个任务，持续迭代直到通过评估，将每次评估和决策记录为持久制品，仅在达到最大运行时间或其他明确终止条件时停止。

## 使用场景

- 已有来自 deep-interview --autoresearch 的任务和评估器
- 需要带严格评估的持久化单任务改进
- 需要在 `.trae/autoresearch/` 下保存持久的实验日志
- 想要通过定时任务定期重新运行改进循环

注意：本skill在SOLO Coder中通过子代理调度执行，确保为SOLO Coder配置了相应的自定义智能体。

## 不适用场景

- 需要在运行时生成评估器 → 先使用 deep-interview --autoresearch
- 需要多任务协调 → v1 不支持
- 只需要一次性分析 → 直接使用 sciomc 或 search

## 指令

v1 约束：
- 仅支持单任务
- 任务设置/评估器生成留在 `deep-interview --autoresearch`
- 评估器输出必须是结构化 JSON，包含必需的布尔值 `pass` 和可选的数值 `score`
- 未通过的迭代**不**停止运行
- 停止条件是明确且有界的，max-runtime 是主要的严格停止条件

规范持久存储位于 `.trae/autoresearch/<slug>/` 和/或 `.trae/logs/autoresearch/<slug>/`。

最低必需制品：
- 任务规格
- 评估器脚本或命令引用
- 每次迭代的评估 JSON
- markdown 决策日志

推荐目录结构：
```text
.trae/autoresearch/<slug>/
  mission.md
  evaluator.json
  runs/
    evaluations/
      iteration-0001.json
      iteration-0002.json
    decision-log.md
```

有可用运行时制品时复用，而非不必要地重复。

### 执行步骤

1. 确认存在单个任务且评估器设置已可用
2. 确保 autoresearch 的模式/状态处于活跃，记录：
   - 任务 slug/目录
   - 评估器引用
   - 迭代次数
   - 开始/更新时间戳
   - 明确的 max-runtime 或截止时间
3. 每次迭代：
   - 运行恰好一个实验/变更周期
   - 运行评估器
   - 持久化机器可读的评估 JSON
   - 追加人类可读的 markdown 决策日志条目
   - 即使评估未通过也继续
4. 停止条件：
   - 达到 max-runtime 上限
   - 用户明确取消
   - 运行时记录的其他明确终止条件

### 定时任务集成

定时任务是定期任务增强的支持集成点。在 v1 中，优先文档化/配置定时输入，而非构建大型调度器 UI。

如果使用定时任务：
- 每个调度作业保持一个任务
- 保持相同的任务/评估器契约
- 追加新的运行制品而非覆盖先前的实验

## 执行策略

- 不要将执行交回 `omc autoresearch`
- 不要创建多任务编排
- 优先复用 `src/autoresearch/*` 中已匹配更严格契约的运行时/模式辅助工具
- 保持日志对人类有用，而非仅对机器

## 输出

每次迭代的评估 JSON 和决策日志，最终产出改进后的代码/配置。

## 依赖

- deep-interview（用于任务设置和评估器生成）
