---
name: writing-skills
description: "当创建新技能、编辑现有技能或部署前验证技能时使用"
---

# Writing Skills

## 描述

**编写技能就是将测试驱动开发应用于过程文档。**

**个人技能存放在代理特定目录（SOLO Coder 使用 `.trae/skills/`）**

你编写测试用例（压力场景与子代理），观察它们失败（基线行为），编写技能（文档），观察测试通过（代理遵守），然后重构（关闭漏洞）。

**核心原则：** 如果你没有观察代理在没有技能时失败，你就不知道技能是否教授了正确的东西。

## 使用场景

- 需要创建新的可复用技能
- 需要编辑现有技能
- 需要在部署前验证技能工作
- 发现了代理反复犯的错误，需要文档化纠正

### 防止合理化借口的技能防护

强制纪律的技能（如 TDD）需要抵御合理化。代理很聪明，在压力下会找到漏洞。

**心理学注记：** 理解说服技术为何有效有助于你系统地应用它们。参见 persuasion-principles.md 获取研究基础（Cialdini, 2021; Meincke et al., 2025）关于权威、承诺、稀缺、社会认同和统一性原则。

#### 显式关闭每个漏洞

不要只陈述规则——禁止特定的变通方法：

<Bad>
```markdown
Write code before test? Delete it.
```
</Bad>

<Good>
```markdown
Write code before test? Delete it. Start over.

**No exceptions:**
- Don't keep it as "reference"
- Don't "adapt" it while writing tests
- Don't look at it
- Delete means delete
```
</Good>

#### 处理"精神 vs 字面"争论

早期添加基础原则：

```markdown
**违反规则的字面意义就是违反规则的精神。**
```

这切断了一整类"我在遵循精神"的合理化借口。

#### 构建合理化借口表

从基线测试中捕获合理化借口（见下方测试部分）。代理做出的每个借口都放入表中：

```markdown
| 借口 | 现实 |
|--------|---------|
| "太简单不需要测试" | 简单代码也会出错。测试只需30秒。 |
| "我之后再测试" | 立即通过的测试什么也证明不了。 |
| "事后测试达到相同目标" | 事后测试 = "这做了什么？" 事前测试 = "这应该做什么？" |
```

#### 创建红旗列表

让代理在合理化时容易自检：

```markdown
## 红旗 - 停止并从头开始

- 先写代码再写测试
- "我已经手动测试过了"
- "事后测试达到相同目的"
- "这是精神而非仪式"
- "这不同因为..."

**所有这些都意味着：删除代码。用 TDD 从头开始。**
```

#### 为违规症状更新 CSO

添加到 description：你即将违反规则时的症状：

```yaml
description: 当实现任何功能或修复时，在编写实现代码之前使用
```

### 反模式

#### 叙事示例
"In session 2025-10-03, we found empty projectDir caused..."
**为何不好：** 太具体，不可复用

#### 多语言稀释
example-js.js, example-py.py, example-go.go
**为何不好：** 质量平庸，维护负担

#### 流程图中的代码
```dot
step1 [label="import fs"];
step2 [label="read file"];
```
**为何不好：** 无法复制粘贴，难以阅读

#### 通用标签
helper1, helper2, step3, pattern4
**为何不好：** 标签应有语义含义

### 停止：在移到下一个技能之前

**编写任何技能后，你必须停止并完成部署流程。**

**不要：**
- 不测试每个技能就批量创建多个
- 在当前技能验证前移到下一个
- 因为"批处理更高效"而跳过测试

**下面的部署检查清单对每个技能是强制性的。**

部署未测试的技能 = 部署未测试的代码。这是质量标准的违规。

### 文件组织

#### 自包含技能
```
defense-in-depth/
  SKILL.md    # 所有内容内联
```
适用：所有内容都适合，无需重型参考

#### 带可复用工具的技能
```
condition-based-waiting/
  SKILL.md    # 概述 + 模式
  example.ts  # 可适配的工作辅助工具
```
适用：工具是可复用代码，不仅是叙述

#### 带重型参考的技能
```
pptx/
  SKILL.md       # 概述 + 工作流
  pptxgenjs.md   # 600 行 API 参考
  ooxml.md       # 500 行 XML 结构
  scripts/       # 可执行工具
```
适用：参考材料太大无法内联

### 交叉引用其他技能

**编写引用其他技能的文档时：**

仅使用技能名称，带显式要求标记：
- 好：`**必需子技能：** 使用 test-driven-development`
- 好：`**必需背景：** 你必须理解 systematic-debugging`
- 差：`参见 skills/testing/test-driven-development`（不清楚是否必需）
- 差：`@skills/testing/test-driven-development/SKILL.md`（强制加载，消耗上下文）

**为什么不用 @ 链接：** `@` 语法会立即强制加载文件，在你需要它们之前消耗 200k+ 上下文。

### 发现工作流

未来的 Claude 如何找到你的技能：

1. **遇到问题**（"测试不稳定"）
2. **找到技能**（description 匹配）
3. **扫描概述**（这相关吗？）
4. **阅读模式**（快速参考表）
5. **加载示例**（仅在实现时）

**为此流程优化** - 尽早并频繁放置可搜索术语。

## 不适用场景

- 只需要一次性操作 → 不需要技能化
- 通用编程知识 → 使用现有文档
- 简单的配置变更 → 直接修改配置

## 指令

### 什么是技能？

**技能**是已验证技术、模式或工具的参考指南。技能帮助未来的实例找到并应用有效的方法。

**技能是：** 可复用的技术、模式、工具、参考指南

**技能不是：** 关于你如何一次解决某个问题的叙述

### TDD 映射到技能

| TDD 概念 | 技能创建 |
|-------------|----------------|
| **测试用例** | 带子代理的压力场景 |
| **生产代码** | 技能文档（SKILL.md） |
| **测试失败（RED）** | 没有技能时代理违反规则（基线） |
| **测试通过（GREEN）** | 有技能时代理遵守 |
| **重构** | 关闭漏洞同时保持合规 |
| **先写测试** | 在编写技能前运行基线场景 |
| **观察失败** | 文档化代理使用的确切合理化借口 |
| **最小代码** | 编写解决那些特定违规的技能 |
| **观察通过** | 验证代理现在遵守 |
| **重构循环** | 找到新的合理化借口 → 堵住 → 重新验证 |

### 何时创建技能

**创建当：**
- 技术对你来说不是直觉上显而易见的
- 你会跨项目再次引用这个
- 模式广泛适用（非项目特定）
- 其他人会受益

**不创建当：**
- 一次性解决方案
- 其他地方有良好文档的标准实践
- 项目特定约定（放在项目文档中）
- 机械约束（如果可以用正则/验证强制执行，自动化它——将文档留给判断调用）

### 技能类型

#### Technique
有步骤可遵循的具体方法（condition-based-waiting、root-cause-tracing）

#### Pattern
思考问题的方式（flatten-with-flags、test-invariants）

#### Reference
API 文档、语法指南、工具文档（office docs）

### 目录结构

```
skills/
  skill-name/
    SKILL.md              # 主参考（必需）
    supporting-file.*     # 仅在需要时
```

**扁平命名空间** - 所有技能在一个可搜索的命名空间中

**为以下内容使用单独文件：**
1. **重型参考**（100+ 行）- API 文档、综合语法
2. **可复用工具** - 脚本、实用程序、模板

**保持内联：**
- 原则和概念
- 代码模式（< 50 行）
- 其他一切

### SKILL.md 结构

**Frontmatter（YAML）：**
- 仅支持两个字段：`name` 和 `description`
- 总共最多 1024 个字符
- `name`：仅使用字母、数字和连字符（无括号、特殊字符）
- `description`：第三人称，仅描述何时使用（而非它做什么）
  - 以"当...时使用"开头以聚焦触发条件
  - 包含特定症状、情况和上下文
  - **绝不总结技能的过程或工作流**
  - 尽可能保持在 500 个字符以内

```markdown
---
name: Skill-Name-With-Hyphens
description: 当[特定触发条件和症状]时使用
---

# Skill Name

## 概述
这是什么？1-2 句核心原则。

## 何时使用
[如果决策不显而易见，使用小型内联流程图]

带症状和用例的要点列表
何时不使用

## 核心模式（用于技术/模式）
之前/之后代码比较

## 快速参考
用于扫描常见操作的表格或要点

## 实现
简单模式的内联代码
重型参考或可复用工具的文件链接

## 常见错误
出了什么问题 + 修复

## 真实世界影响（可选）
具体结果
```

### Claude 搜索优化（CSO）

**对发现至关重要：** 未来的 Claude 需要找到你的技能

#### 1. 丰富的 description 字段

**目的：** Claude 读取 description 来决定为给定任务加载哪些技能。让它回答："我现在应该读这个技能吗？"

**格式：** 以"当...时使用"开头以聚焦触发条件

**关键：Description = 何时使用，而非技能做什么**

description 应该只描述触发条件。不要在 description 中总结技能的过程或工作流。

**为什么这很重要：** 测试揭示，当 description 总结了技能的工作流时，Claude 可能会遵循 description 而非阅读完整的技能内容。一个说"任务间代码审查"的 description 导致 Claude 只做了一次审查，尽管技能的流程图清楚地显示了两次审查（规格合规然后代码质量）。

当 description 被改为仅"当在当前会话中执行具有独立任务的实现计划时使用"（无工作流总结）时，Claude 正确阅读了流程图并遵循了两阶段审查过程。

**陷阱：** 总结工作流的 description 创建了 Claude 会走的捷径。技能正文变成 Claude 跳过的文档。

```yaml
# 差：总结工作流 - Claude 可能遵循这个而非阅读技能
description: 当执行计划时使用 - 每个任务派遣子代理并在任务间进行代码审查

# 差：太多过程细节
description: 用于 TDD - 先写测试，观察失败，写最小代码，重构

# 好：仅触发条件，无工作流总结
description: 当在当前会话中执行具有独立任务的实现计划时使用

# 好：仅触发条件
description: 当实现任何功能或修复时，在编写实现代码之前使用
```

#### 2. 关键词覆盖

使用 Claude 会搜索的词：
- 错误消息："Hook timed out"、"ENOTEMPTY"、"race condition"
- 症状："flaky"、"hanging"、"zombie"、"pollution"
- 同义词："timeout/hang/freeze"、"cleanup/teardown/afterEach"
- 工具：实际命令、库名、文件类型

#### 3. 描述性命名

**使用主动语态，动词优先：**
- `creating-skills` 而非 `skill-creation`
- `condition-based-waiting` 而非 `async-test-helpers`

#### 4. Token 效率（关键）

**问题：** 入门和频繁引用的技能加载到每个对话中。每个 token 都很重要。

**目标字数：**
- 入门工作流：每个 <150 词
- 频繁加载的技能：总共 <200 词
- 其他技能：<500 词（仍要简洁）

**技术：**

**将细节移到工具帮助中：**
```bash
# 差：在 SKILL.md 中文档化所有标志
search-conversations supports --text, --both, --after DATE, --before DATE, --limit N

# 好：引用 --help
search-conversations supports multiple modes and filters. Run --help for details.
```

**使用交叉引用：**
```markdown
# 差：重复工作流细节
When searching, dispatch subagent with template...
[20 lines of repeated instructions]

# 好：引用其他技能
Always use subagents (50-100x context savings). REQUIRED: Use [other-skill-name] for workflow.
```

**压缩示例：**
```markdown
# 差：冗长示例（42词）
your human partner: "How did we handle authentication errors in React Router before?"
You: I'll search past conversations for React Router authentication patterns.
[Dispatch subagent with search query: "React Router authentication error handling 401"]

# 好：最小示例（20词）
Partner: "How did we handle auth errors in React Router?"
You: Searching...
[Dispatch subagent → synthesis]
```

**消除冗余：**
- 不要重复交叉引用技能中的内容
- 不要解释命令中显而易见的内容
- 不要包含相同模式的多个示例

**验证：**
```bash
wc -w skills/path/SKILL.md
# getting-started workflows: aim for <150 each
# Other frequently-loaded: aim for <200 total
```

**按你做什么或核心洞察命名：**
- `condition-based-waiting` > `async-test-helpers`
- `using-skills` not `skill-usage`
- `flatten-with-flags` > `data-structure-refactoring`
- `root-cause-tracing` > `debugging-techniques`

**动名词（-ing）适合流程：**
- `creating-skills`、`testing-skills`、`debugging-with-logs`
- 主动的，描述你正在采取的行动

### 流程图使用

```dot
digraph when_flowchart {
    "Need to show information?" [shape=diamond];
    "Decision where I might go wrong?" [shape=diamond];
    "Use markdown" [shape=box];
    "Small inline flowchart" [shape=box];

    "Need to show information?" -> "Decision where I might go wrong?" [label="yes"];
    "Decision where I might go wrong?" -> "Small inline flowchart" [label="yes"];
    "Decision where I might go wrong?" -> "Use markdown" [label="no"];
}
```

**仅在以下情况使用流程图：**
- 不显而易见的决策点
- 你可能过早停止的过程循环
- "何时使用 A vs B"的决策

**绝不使用流程图于：**
- 参考材料 → 表格、列表
- 代码示例 → Markdown 块
- 线性指令 → 编号列表
- 没有语义含义的标签（step1、helper2）

### 代码示例

**一个优秀的例子胜过许多平庸的**

选择最相关的语言：
- 测试技术 → TypeScript/JavaScript
- 系统调试 → Shell/Python
- 数据处理 → Python

**好的示例：**
- 完整且可运行
- 注释良好，解释为什么
- 来自真实场景
- 清晰展示模式
- 可直接适配（非通用模板）

**不要：**
- 用 5+ 种语言实现
- 创建填空模板
- 编造牵强的示例

你擅长移植——一个优秀的例子就够了。

### 铁律（与 TDD 相同）

```
没有先失败的测试，就没有技能
```

这适用于新技能和对现有技能的编辑。

先写技能再测试？删除它。从头开始。
不测试就编辑技能？同样的违规。

**无例外：**
- 不适用于"简单添加"
- 不适用于"只是添加一个部分"
- 不适用于"文档更新"
- 不要保留未测试的变更作为"参考"
- 不要在运行测试时"适应"
- 删除意味着删除

### 测试所有技能类型

#### 纪律强制技能（规则/要求）

**测试用：**
- 学术问题：他们理解规则吗？
- 压力场景：他们在压力下遵守吗？
- 多重压力组合：时间 + 沉没成本 + 疲惫
- 识别合理化借口并添加显式反驳

**成功标准：** 代理在最大压力下遵循规则

#### 技术技能（操作指南）

**测试用：**
- 应用场景：他们能正确应用技术吗？
- 变体场景：他们处理边缘情况吗？
- 缺失信息测试：指令有缺口吗？

**成功标准：** 代理成功将技术应用于新场景

#### 模式技能（心智模型）

**测试用：**
- 识别场景：他们能识别模式何时适用吗？
- 应用场景：他们能使用心智模型吗？
- 反例：他们知道何时不应用吗？

**成功标准：** 代理正确识别何时/如何应用模式

#### 参考技能（文档/API）

**测试用：**
- 检索场景：他们能找到正确的信息吗？
- 应用场景：他们能正确使用找到的内容吗？
- 缺口测试：常见用例是否覆盖？

**成功标准：** 代理找到并正确应用参考信息

### 常见跳过测试的合理化借口

| 借口 | 现实 |
|--------|---------|
| "技能显然很清晰" | 对你清晰 != 对其他代理清晰。测试它。 |
| "只是参考" | 参考可能有缺口、不清楚的部分。测试检索。 |
| "测试过度" | 未测试的技能有问题。总是如此。15 分钟测试节省数小时。 |
| "如果出现问题我再测试" | 问题 = 代理无法使用技能。在部署前测试。 |
| "测试太繁琐" | 测试比在生产中调试坏技能更不繁琐。 |
| "我确信它很好" | 过度自信保证问题。仍然测试。 |
| "学术审查就够了" | 阅读 != 使用。测试应用场景。 |
| "没时间测试" | 部署未测试的技能浪费更多时间修复它。 |

**所有这些都意味着：部署前测试。无例外。**

### RED-GREEN-REFACTOR 用于技能

遵循 TDD 循环：

#### RED：编写失败测试（基线）

在没有技能的情况下用子代理运行压力场景。文档化确切行为：
- 他们做了什么选择？
- 他们使用了什么合理化借口（逐字）？
- 哪些压力触发了违规？

这是"观察测试失败"——你必须在编写技能前看到代理自然做什么。

#### GREEN：编写最小技能

编写解决那些特定合理化借口的技能。不要为假设情况添加额外内容。

用相同场景与技能一起运行。代理现在应该遵守。

#### REFACTOR：关闭漏洞

代理找到了新的合理化借口？添加显式反驳。重新测试直到无懈可击。

### 技能创建检查清单（TDD 适配）

**RED 阶段 - 编写失败测试：**
- [ ] 创建压力场景（纪律技能需要 3+ 组合压力）
- [ ] 在没有技能的情况下运行场景 - 逐字文档化基线行为
- [ ] 识别合理化借口/失败中的模式

**GREEN 阶段 - 编写最小技能：**
- [ ] 名称仅使用字母、数字、连字符（无括号/特殊字符）
- [ ] YAML frontmatter 仅包含 name 和 description（最多 1024 字符）
- [ ] Description 以"当...时使用"开头并包含特定触发器/症状
- [ ] Description 以第三人称编写
- [ ] 全文包含搜索关键词（错误、症状、工具）
- [ ] 清晰的概述和核心原则
- [ ] 解决 RED 中识别的特定基线失败
- [ ] 代码内联或链接到单独文件
- [ ] 一个优秀的例子（非多语言）
- [ ] 与技能一起运行场景 - 验证代理现在遵守

**REFACTOR 阶段 - 关闭漏洞：**
- [ ] 识别测试中的新合理化借口
- [ ] 添加显式反驳（如果是纪律技能）
- [ ] 从所有测试迭代构建合理化借口表
- [ ] 创建红旗列表
- [ ] 重新测试直到无懈可击

**质量检查：**
- [ ] 仅当决策不显而易见时使用小型流程图
- [ ] 快速参考表
- [ ] 常见错误部分
- [ ] 无叙述性讲故事
- [ ] 支持文件仅用于工具或重型参考

**部署：**
- [ ] 将技能提交到 git 并推送到你的 fork（如果已配置）
- [ ] 考虑通过 PR 回馈（如果广泛有用）

## 输出

经过 TDD 验证的 SKILL.md 文件，包含 YAML frontmatter、触发条件、核心模式和测试证据。

## 依赖

无
