---
name: release
description: "当需要执行项目发布流程时使用——自动分析仓库发布规则并引导发布"
---

# Release

## 描述

轻量级、仓库感知的发布助手。首次运行时检查项目和 CI 以推导发布规则，存储在 `.trae/RELEASE_RULE.md` 中供后续使用，然后使用这些规则引导发布。

## 使用场景

- 需要执行项目版本发布
- 首次发布需要分析仓库发布规则
- 需要引导完成版本号、测试、变更日志和推送流程

注意：本skill在SOLO Coder中用于引导项目发布流程。

## 不适用场景

- 不涉及发布的常规开发工作 → 不适用
- 只需要查看版本号 → 直接读取 package.json
- 需要自定义发布脚本 → 本skill不替代自定义脚本

## 指令

### 用法

```
release [version]
```

- `version` 可选。如果省略，skill 会询问。接受 `patch`、`minor`、`major` 或明确的 semver 如 `2.4.0`。
- 添加 `--refresh` 强制重新分析仓库，即使存在缓存的规则文件。

### 执行流程

#### Step 0 — 加载或构建发布规则

检查 `.trae/RELEASE_RULE.md` 是否存在。

**如果不存在（或传入了 `--refresh`）：** 运行以下完整的仓库分析并写入文件。

**如果存在：** 读取文件。然后做快速增量检查——扫描 `.github/workflows/`（或等效 CI 目录）中是否有比规则文件中 `last-analyzed` 时间戳更新的修改。如果相关工作流文件变更了，重新运行这些部分的分析并更新文件。报告变更内容。

---

#### Step 1 — 仓库分析（首次运行或 --refresh）

检查仓库并回答以下问题。将答案写入 `.trae/RELEASE_RULE.md`。

##### 1a. 版本来源

- 定位所有包含与 `package.json` / `pyproject.toml` / `Cargo.toml` / `build.gradle` / `VERSION` 文件等当前版本匹配的版本字符串的文件。
- 列出每个文件和用于查找版本的字段或正则模式。
- 检测是否存在发布自动化脚本（如 `scripts/release.*`、`Makefile release` 目标、`bump2version`、`release-it`、`semantic-release`、`changesets`、`goreleaser`）。

##### 1b. 注册表 / 分发

- npm（`package.json` 带 `publishConfig` 或 CI 中的 `npm publish`）、PyPI（`pyproject.toml` + `twine`/`flit`）、Cargo（`Cargo.toml`）、Docker（`Dockerfile` + push 步骤）、GitHub Packages、其他。
- 是否有 CI 步骤在 tag push 时自动发布？哪个工作流文件和 job？

##### 1c. 发布触发器

- 识别什么启动发布：tag push（`v*`）、手动 dispatch（`workflow_dispatch`）、合并到 main/master、发布分支合并、commit 消息模式。

##### 1d. 测试门控

- 识别测试命令及其在 CI 中的运行位置。
- 发布前是否需要测试通过？记录任何绕过标志。

##### 1e. 发布说明 / 变更日志

- 是否存在 `CHANGELOG.md` 或 `CHANGELOG.rst`？
- 使用什么约定：Keep a Changelog、Conventional Commits、GitHub 自动生成、无？
- 是否有发布正文文件（如 `.github/release-body.md`）在 tag 前提交？

##### 1f. 首次用户检查

- `.github/workflows/`（或等效）中是否存在发布工作流？如果不存在，标记并提供脚手架。
- `.gitignore` 是否阻止构建产物提交？如果不是，标记。
- 是否使用了 git tags？运行 `git tag --list` 检查。如果没有 tags 存在，标记并解释最佳实践。

---

#### Step 2 — 写入 `.trae/RELEASE_RULE.md`

创建或覆盖文件，结构如下：

```markdown
# Release Rules
<!-- last-analyzed: YYYY-MM-DDTHH:MM:SSZ -->

## Version Sources
<!-- 文件列表 + 模式 -->

## Release Trigger
<!-- 什么启动发布 -->

## Test Gate
<!-- 命令 + CI job 名称 -->

## Registry / Distribution
<!-- npm, PyPI, Docker 等 + 发布的 CI job -->

## Release Notes Strategy
<!-- 约定 + 文件 -->

## CI Workflow Files
<!-- 相关工作流文件路径 -->

## First-Time Setup Gaps
<!-- 分析期间发现的缺失部分，或 "none" -->
```

---

#### Step 3 — 确定版本

如果用户提供了版本参数，使用它。否则：

1. 显示当前版本（来自主版本文件）。
2. 显示 `patch`、`minor` 和 `major` 会产生什么。
3. 询问用户使用哪个。

验证选择的版本是有效的 semver 字符串。

---

#### Step 4 — 发布前检查清单

呈现从发布规则派生的检查清单。至少：

- [ ] 此发布打算包含的所有变更已提交并推送
- [ ] 目标分支上 CI 为绿色
- [ ] 测试在本地通过（运行测试门控命令）
- [ ] 版本号已应用到所有版本源文件
- [ ] 发布说明 / 变更日志已准备（见 Step 5）

请用户确认后再继续，或如果他们说 "go ahead" 则运行每个步骤。

---

#### Step 5 — 发布说明指导

帮助用户编写好的发布说明。应用仓库使用的任何约定。未检测到约定时的默认指导：

**好的发布说明要素：**
- 以**对用户有什么变更**开头，而非内部实现细节。
- 按类型分组：`New Features`、`Bug Fixes`、`Breaking Changes`、`Deprecations`、`Internal / Chores`。
- 每项：一句话，链接到 PR 或 issue，如果是外部贡献者则致谢。
- **Breaking changes** 放在最前面，必须包含迁移路径。
- 省略用户永远不会看到的变更（重构、CI 调整、仅测试变更），除非影响构建可复现性。

**示例条目格式：**
```
### Bug Fixes
- Fix session drop on token expiry (#123) — @contributor
```

如果仓库使用 Conventional Commits，从 `git log ..HEAD --no-merges --format="%s"` 按 commit 类型分组生成草稿变更日志。展示给用户并让他们编辑。

---

#### Step 6 — 执行发布

使用发现的规则，逐步执行：

1. **Bump version** — 应用到每个版本源文件。
2. **Run tests** — 执行测试门控命令。
3. **Commit** — `git add <version files> CHANGELOG.md` 并提交 `chore(release): bump version to vX.Y.Z`。
4. **Tag** — `git tag -a vX.Y.Z -m "vX.Y.Z"`（annotated tags 优于 lightweight tags）。
5. **Push** — `git push origin <branch> && git push origin vX.Y.Z`。
6. **CI 接管** — 如果发布触发器是 tag push，提醒用户 CI 会处理其余工作（发布、GitHub Release 创建）。展示预期的 CI 工作流文件。
7. **Manual publish** — 如果没有 CI 自动化，列出手动发布命令（如 `npm publish --access public`、`twine upload dist/*`）。

---

#### Step 7 — 首次设置建议

如果在 Step 1f 中发现缺口，提供具体帮助：

**无发布工作流：**
> 你的仓库没有发布 CI 工作流。由 `v*` tag push 触发的 GitHub Actions 工作流是最常见的最佳实践。它可以：
> - 运行测试
> - 发布到 npm/PyPI 等
> - 用你的发布说明创建 GitHub Release
>
> 需要我为你为你的技术栈脚手架一个 `.github/workflows/release.yml` 吗？

**无 git tags：**
> 这似乎是首次发布。Git tags 让 GitHub、npm 和其他工具理解你的版本历史。我们将在 Step 6 中创建你的第一个 tag。

**构建产物未 gitignore：**
> 构建产物存在于 git 历史中或未被 gitignore。这会膨胀仓库大小并产生合并冲突。需要我将它们添加到 `.gitignore` 吗？

---

#### Step 8 — 验证

Push 后：
- 检查 CI 状态：`gh run list --workflow=<release workflow> --limit=3`（如果 `gh` 可用）。
- 几分钟后检查注册表（npm、PyPI）是否有新版本。
- 确认 GitHub Release 已创建：`gh release view vX.Y.Z`。

报告成功或标记任何失败。

---

## 注意事项

- 此技能**不**硬编码任何项目特定的版本文件或命令。一切都从仓库检查中推导。
- `.trae/RELEASE_RULE.md` 是本地缓存。如果想与团队共享推导的规则，将其提交到仓库；如果想保持本地，添加到 `.gitignore`。
- 对于复杂的 monorepo 或多包工作区，skill 会检测工作区模式（npm workspaces、pnpm workspaces、Cargo workspace）并相应调整。

## 输出

成功发布的版本，附带 CI 状态和注册表验证结果。

## 依赖

无
