---
name: external-context
description: "当需要并行获取外部文档、参考和上下文信息时使用"
---

# External Context

## 描述

获取查询的外部文档、参考和上下文。将查询分解为 2-5 个方面，生成并行的文档专家代理。

## 使用场景

- 需要查找外部文档或最佳实践
- 需要比较不同技术方案
- 需要获取最新的框架/库模式和约定
- 研究问题可以分解为多个独立搜索方面

注意：本skill在SOLO Coder中通过子代理并行搜索外部资源。

### 使用示例

```
external-context "What are the best practices for JWT token rotation in Node.js?"
external-context "Compare Prisma vs Drizzle ORM for PostgreSQL"
external-context "Latest React Server Components patterns and conventions"
```

## 不适用场景

- 只需要简单代码查找 → 使用搜索工具
- 信息已在本地代码库中 → 直接搜索代码库
- 只需要单一简单搜索 → 直接使用 WebSearch

## 指令

### Step 1: 方面分解

给定查询，分解为 2-5 个独立搜索方面：

```markdown
## 搜索分解

**查询：** <原始查询>

### 方面 1:
- **搜索焦点：** 搜索什么
- **来源：** 官方文档、GitHub、博客等

### 方面 2:
...
```

### Step 2: 并行代理调用

通过 Task 工具并行发射独立方面：

```
Task(subagent_type="backend-architect", prompt="Search for: <facet 1 description>. Use WebSearch and WebFetch to find official documentation and examples. Cite all sources with URLs.")

Task(subagent_type="backend-architect", prompt="Search for: <facet 2 description>. Use WebSearch and WebFetch to find official documentation and examples. Cite all sources with URLs.")
```

最多 5 个并行文档专家代理。

### Step 3: 综合输出格式

以以下格式呈现综合结果：

```markdown
## External Context: <topic>

### 关键发现
1. **<finding>** - 来源: [title](url)
2. **<finding>** - 来源: [title](url)

### 详细结果

#### 方面 1: <name>
<带引用的聚合发现>

#### 方面 2: <name>
<带引用的聚合发现>

### 来源
- [Source 1](url)
- [Source 2](url)
```

## 配置

- 最多 5 个并行文档专家代理
- 无魔法关键词触发 - 仅显式调用

## 输出

带引用的结构化综合报告，包含关键发现、详细结果和来源链接。

## 依赖

无
