---
name: ultraqa
description: "当需要自动 QA 循环直到质量目标达成时使用"
---

# UltraQA

## 描述

自主 QA 循环工作流，运行直到质量目标达成。

**循环**：qa-tester → architect 诊断 → 修复 → 重复

## 使用场景

- 需要自动循环测试/构建/lint直到通过
- 用户说 "ultraqa"、"qa cycle"、"test until green"
- 修复后需要验证所有测试通过
- 需要自动诊断和修复失败

注意：本skill在SOLO Coder中通过子代理调度执行，确保为SOLO Coder配置了相应的自定义智能体。

## 不适用场景

- 只需要运行一次测试 → 直接运行测试命令
- 问题已明确，不需要循环诊断 → 直接修复
- 需要完整自主执行管道 → 使用 autopilot

## 指令

### 目标解析

从参数解析目标。支持的格式：

| 调用 | 目标类型 | 检查什么 |
|------------|-----------|---------------|
| `ultraqa --tests` | tests | 所有测试套件通过 |
| `ultraqa --build` | build | 构建成功退出码为 0 |
| `ultraqa --lint` | lint | 无 lint 错误 |
| `ultraqa --typecheck` | typecheck | 无 TypeScript 错误 |
| `ultraqa --custom "pattern"` | custom | 输出中的自定义成功模式 |
| `ultraqa --interactive` | interactive | 交互式 CLI/服务测试：使用 qa-tester 进行交互式测试，指定目标、服务启动方式和测试场景 |

如果未提供结构化目标，将参数解释为自定义目标。

### 循环工作流

#### 循环 N（最多 5 次）

1. **运行 QA**：基于目标类型执行验证
   - `--tests`：运行项目的测试命令
   - `--build`：运行项目的构建命令
   - `--lint`：运行项目的 lint 命令
   - `--typecheck`：运行项目的类型检查命令
   - `--custom`：运行适当命令并检查模式
   - `--interactive`：使用 qa-tester 进行交互式 CLI/服务测试：
     ```
     Task(subagent_type="backend-architect", prompt="TEST:
     Goal: [描述要验证什么]
     Service: [如何启动]
     Test cases: [要验证的具体场景]")
     ```

2. **检查结果**：目标是否通过？
   - **是** → 退出并显示成功消息
   - **否** → 继续到步骤 3

3. **Architect 诊断**：生成 architect 分析失败
   ```
   Task(subagent_type="backend-architect", prompt="DIAGNOSE FAILURE:
   Goal: [goal type]
   Output: [test/build output]
   Provide root cause and specific fix recommendations.")
   ```

4. **修复问题**：应用 architect 的建议
   ```
   Task(subagent_type="backend-architect", prompt="FIX:
   Issue: [architect diagnosis]
   Files: [affected files]
   Apply the fix precisely as recommended.")
   ```

5. **重复**：回到步骤 1

### 退出条件

| 条件 | 动作 |
|-----------|--------|
| **目标达成** | 退出并显示成功："ULTRAQA COMPLETE: Goal met after N cycles" |
| **达到循环 5** | 退出并显示诊断："ULTRAQA STOPPED: Max cycles. Diagnosis: ..." |
| **相同失败 3 次** | 提前退出："ULTRAQA STOPPED: Same failure detected 3 times. Root cause: ..." |
| **环境错误** | 退出："ULTRAQA ERROR: [tmux/port/dependency issue]" |

### 可观测性

每个循环输出进度：
```
[ULTRAQA Cycle 1/5] Running tests...
[ULTRAQA Cycle 1/5] FAILED - 3 tests failing
[ULTRAQA Cycle 1/5] Architect diagnosing...
[ULTRAQA Cycle 1/5] Fixing: auth.test.ts - missing mock
[ULTRAQA Cycle 2/5] Running tests...
[ULTRAQA Cycle 2/5] PASSED - All 47 tests pass
[ULTRAQA COMPLETE] Goal met after 2 cycles
```

### 状态跟踪

在 `.trae/state/ultraqa-state.json` 中跟踪状态：
```json
{
  "active": true,
  "goal_type": "tests",
  "goal_pattern": null,
  "cycle": 1,
  "max_cycles": 5,
  "failures": ["3 tests failing: auth.test.ts"],
  "started_at": "2024-01-18T12:00:00Z",
  "session_id": "uuid"
}
```

### 取消

用户可以通过 `ultraqa --cancel` 取消，这会清除状态文件。

### 重要规则

1. **尽可能并行** - 在准备潜在修复时运行诊断
2. **跟踪失败** - 记录每次失败以检测模式
3. **模式提前退出** - 相同失败 3 次 = 停止并呈现
4. **清晰输出** - 用户应始终知道当前循环和状态
5. **清理** - 完成或取消时清除状态文件

### 完成时状态清理

**重要：完成时删除状态文件 - 不要只设置 `active: false`**

当目标达成或达到最大循环或提前退出时：

```bash
rm -f .trae/state/ultraqa-state.json
```

这确保未来会话的干净状态。不应留下 `active: false` 的过时状态文件。

## 输出

QA 循环结果报告，包含通过的检查项或失败诊断。

## 依赖

无
