---
name: wiki
description: "当需要持久化的跨会话 markdown 知识库时使用"
---

# Wiki

## 描述

持久的、自维护的 markdown 知识库，用于项目和会话知识。受 Karpathy 的 LLM Wiki 概念启发。

## 使用场景

- 需要跨会话持久化项目知识
- 想要创建可搜索的知识页面
- 需要组织决策记录、架构文档、调试模式等
- 想要自动捕获会话发现

注意：本skill在SOLO Coder中用于维护跨会话的知识库。

## 不适用场景

- 只需要临时笔记 → 使用对话上下文
- 知识只需要在当前会话中 → 不需要持久化
- 需要向量搜索而非关键词搜索 → 本skill不支持

## 指令

### 操作

#### Ingest
将知识处理到 wiki 页面。单次 ingest 可以触及多个页面。

```
wiki_ingest({ title: "Auth Architecture", content: "...", tags: ["auth", "architecture"], category: "architecture" })
```

#### Query
跨所有 wiki 页面按关键词和标签搜索。返回带摘录的匹配页面——你（LLM）从结果中综合答案并附带引用。

```
wiki_query({ query: "authentication", tags: ["auth"], category: "architecture" })
```

#### Lint
运行 wiki 健康检查。检测孤立页面、过时内容、损坏的交叉引用、过大页面和结构性矛盾。

```
wiki_lint()
```

#### Quick Add
快速添加单个页面（比 ingest 更简单）。

```
wiki_add({ title: "Page Title", content: "...", tags: ["tag1"], category: "decision" })
```

#### List / Read / Delete
```
wiki_list()           # 显示所有页面（读取 index.md）
wiki_read({ page: "auth-architecture" })  # 读取特定页面
wiki_delete({ page: "outdated-page" })    # 删除页面
```

#### Log
通过读取 `.trae/wiki/log.md` 查看 wiki 操作历史。

### 分类
页面按类别组织：`architecture`、`decision`、`pattern`、`debugging`、`environment`、`session-log`

### 存储
- 页面：`.trae/wiki/*.md`（带 YAML frontmatter 的 markdown）
- 索引：`.trae/wiki/index.md`（自动维护的目录）
- 日志：`.trae/wiki/log.md`（仅追加的操作编年史）

### 交叉引用
使用 `[[page-name]]` wiki-link 语法创建页面间的交叉引用。

### 自动捕获
会话结束时，重要发现自动捕获为 session-log 页面。通过 `.trae/config.json` 中的 `wiki.autoCapture` 配置（默认：启用）。

### 硬约束
- 无向量嵌入——查询仅使用关键词 + 标签匹配
- Wiki 页面默认被 git 忽略（`.trae/wiki/` 是项目本地的）

## 输出

持久化的 wiki 页面，包含 YAML frontmatter、标签和分类。

## 依赖

无
