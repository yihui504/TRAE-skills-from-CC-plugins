---
name: gstack-skillify
description: 当需要将浏览器scrape流程编码为永久浏览器技能、将重复的浏览操作自动化为可复用技能时使用
---

## 描述

将最近的/scrape流程编码为永久浏览器技能，未来相同意图的scrape在约200ms内运行。合成TypeScript脚本、捕获fixture、编写测试，通过审批门后提交。

## 上下文

- 浏览器技能是TypeScript脚本，通过browse-client SDK控制浏览器
- 每个技能包含script.ts、script.test.ts和fixture数据
- 技能存储在`.trae/gstack/browser-skills/`目录下
- 技能通过`$B skill run <name>`执行

## 指令

### Step 1: 来源验证

1. 确认当前会话中确实执行过/scrape操作
2. 如果没有scrape历史，告知用户需要先运行/scrape
3. 提取scrape的目标URL和操作序列

### Step 2: 提议名称和触发器

1. 根据scrape目标生成技能名称（小写、连字符分隔）
2. 生成触发器短语列表
3. 使用AskUserQuestion确认名称和触发器

### Step 3: 合成script.ts

1. 将scrape操作序列转化为TypeScript代码
2. 使用browse-client SDK API
3. 包含错误处理和重试逻辑
4. 输出类型化的JSON结果

### Step 4: 捕获fixture

1. 运行script.ts捕获当前页面HTML作为fixture
2. 保存到`fixtures/`目录
3. fixture用于测试时避免真实网络请求

### Step 5: 编写script.test.ts

1. 编写使用fixture的测试
2. 验证输出结构和数据类型
3. 确保测试可在无网络环境下运行

### Step 6: 解析SDK路径

1. 定位browse-client SDK的安装路径
2. 确认import路径正确

### Step 7: 暂存技能

1. 将所有文件放入技能目录
2. 确认目录结构完整

### Step 8: 运行测试

1. 执行`script.test.ts`
2. 确认所有测试通过
3. 如果测试失败，修复并重试

### Step 9: 审批门

使用AskUserQuestion询问用户：

- A) 批准提交
- B) 需要修改
- C) 丢弃

### Step 10: 提交/丢弃

**批准：**

1. git add技能文件
2. 提交：`git commit -m "feat: add <skill-name> browser skill"`

**丢弃：**

1. 删除技能目录
2. 告知用户已丢弃

### Step 11: 确认验证

1. 运行`$B skill run <skill-name>`验证技能可用
2. 确认输出正确

## 使用场景

- 将一次性scrape操作转化为可复用技能
- 自动化重复的浏览器操作
- 创建网站特定的数据提取技能

## 不适用场景

- 只需要一次性scrape，不需要复用
- 目标网站结构不稳定，不适合固化
- 需要登录的复杂交互（应使用setup-browser-cookies）

## 输出

- 新的浏览器技能目录（含script.ts、script.test.ts、fixtures）
- 测试通过确认
- git提交记录

## 依赖

- gstack browse二进制文件
- browse-client SDK
- bun运行时
- TypeScript
- TRAE适配：`$B` → TRAE的agent-browser技能或浏览器MCP

## TRAE适配说明

- 路径适配：`~/.claude/skills/gstack/` → `.trae/gstack/`，`~/.gstack/` → `.trae/gstack/data/`
- 技能存储路径从`~/.claude/skills/gstack/browser-skills/`适配为`.trae/gstack/browser-skills/`
- `$B` browse守护进程 → TRAE的agent-browser技能或浏览器MCP
- browser-skill-write工具需适配TRAE环境
