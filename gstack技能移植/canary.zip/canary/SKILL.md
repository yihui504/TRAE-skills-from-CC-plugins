---
name: gstack-canary
description: |
  当需要在部署后监控生产环境、检测控制台错误、性能回归和页面故障时使用。使用浏览器定期截图，与部署前基线对比，异常时告警。适用于"部署后检查"、"金丝雀监控"、"生产监控"场景。
---

# gstack-canary

## 上下文
gstack-canary是发布可靠性工程师角色，在部署后监控生产环境。捕获CI通过但生产出问题的情况——缺失环境变量、CDN缓存、数据库迁移慢等。

**TRAE适配说明：** 浏览器操作使用agent-browser技能。路径 `.gstack/` 适配为 `.trae/gstack/`。

## 指令

### 参数
- `/canary <url>` — 监控URL 10分钟
- `/canary <url> --duration 5m` — 自定义监控时长（1m到30m）
- `/canary <url> --baseline` — 捕获基线截图（部署前运行）
- `/canary <url> --pages /,/dashboard,/settings` — 指定监控页面
- `/canary <url> --quick` — 单次健康检查

### 工作流

**Phase 1: 设置**
创建目录 `.trae/gstack/canary-reports/`、`baselines/`、`screenshots/`

**Phase 2: 基线捕获（--baseline模式）**
部署前运行，对每个页面：
1. 导航到页面
2. 拍摄标注截图
3. 检查控制台错误
4. 获取性能数据
5. 保存文本快照

保存基线清单到 `baseline.json`，然后告知用户部署后运行 `/canary <url>`。

**Phase 3: 页面发现**
无 `--pages` 参数时自动发现：获取首页链接，提取前5个内部导航链接，询问用户确认监控页面列表。

**Phase 4: 部署前快照（无基线时）**
对每个监控页面快速截图作为参考点。

**Phase 5: 持续监控循环**
指定时长内每60秒检查每个页面：
1. 导航到页面
2. 拍摄标注截图
3. 检查控制台错误
4. 获取性能数据

对比基线检测结果：
- **页面加载失败** → CRITICAL告警
- **新控制台错误** → HIGH告警
- **性能回归（2x基线）** → MEDIUM告警
- **新404** → LOW告警

**告警规则：** 只对连续2+次检查持续存在的模式告警，单次瞬态不告警。检测到CRITICAL/HIGH时立即通知用户，提供选项：调查/继续监控/回滚/忽略。

**Phase 6: 健康报告**
产出摘要：每页面状态（HEALTHY/DEGRADED/BROKEN）、告警数、平均加载时间。保存到 `.trae/gstack/canary-reports/{date}-canary.md`。

**Phase 7: 基线更新**
部署健康时，询问是否更新基线。

### 重要规则
- 速度重要：30秒内开始监控
- 对变化告警，不对绝对值告警
- 截图是证据：每个告警必须包含截图
- 瞬态容忍：仅连续2+次检查的模式才告警
- 只读：观察和报告，不修改代码

## 使用场景
- 部署后10分钟内验证
- 生产环境持续监控
- 部署前捕获基线
- 快速单次健康检查

## 不适用场景
- 部署前的代码审查（使用gstack-review）
- 需要修复问题时（使用gstack-investigate）
- 非Web应用的监控

## 输出
- 金丝雀报告（`.trae/gstack/canary-reports/{date}-canary.md`）
- 基线截图和数据（`baselines/`）
- 监控截图（`screenshots/`）
- 告警通知
- 健康状态判定

## 依赖
- agent-browser技能
- git（分支检测）
