---
name: gstack-hackernews-frontpage
description: 当需要抓取Hacker News首页内容、获取HN热门故事列表、获取科技新闻头条时使用
---

## 描述

抓取Hacker News（news.ycombinator.com）首页，返回前30个故事的结构化JSON数据，包含排名、标题、链接、点数和评论数。

## 上下文

- 这是gstack浏览器技能的参考实现：最小、无认证、HTML结构稳定
- 通过browse守护进程导航到HN并解析页面
- HN使用稳定的`tr.athing` HTML结构，适合自动化抓取
- 包含fixture测试，当HN HTML结构变化时测试会失败

## 指令

### 执行抓取

1. 通过浏览器导航到`https://news.ycombinator.com`
2. 读取页面HTML
3. 解析每个故事行（HN的`tr.athing`结构）为类型化的Story记录
4. 输出单个JSON文档

### 输出格式

```json
{
  "stories": [
    { "rank": 1, "title": "...", "url": "...", "points": 412, "comments": 87 }
  ],
  "count": 30
}
```

### 工作原理

1. 使用browse守护进程导航到HN
2. 读取页面HTML内容
3. 解析`tr.athing`结构提取每个故事
4. 输出JSON到stdout

## 使用场景

- 快速获取HN热门故事列表
- 作为浏览器技能开发的参考模板
- 测试browse守护进程是否正常工作

## 不适用场景

- 需要抓取HN的评论内容（只抓取首页列表）
- 需要登录HN的功能
- 需要实时流式数据

## 输出

- JSON格式的30个故事列表
- 每个故事包含：rank、title、url、points、comments

## 依赖

- gstack browse守护进程
- browse-client SDK
- TRAE适配：`$B` → TRAE的agent-browser技能或浏览器MCP

## TRAE适配说明

- 路径适配：`~/.claude/skills/gstack/` → `.trae/gstack/`
- `$B skill run`命令需适配为TRAE的技能调用方式
- browse守护进程 → TRAE的agent-browser技能或浏览器MCP
- 测试fixture路径适配
