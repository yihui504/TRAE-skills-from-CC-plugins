---
name: design-consultation
description: |
  设计咨询：理解产品、研究竞品、提出完整设计系统（美学、排版、色彩、布局、间距、动效），
  生成字体+色彩预览页，创建DESIGN.md作为项目设计权威文档。
  适用于"设计系统"、"品牌指南"、"创建DESIGN.md"等场景。
  在新项目启动UI且无现有设计系统时主动建议使用。
---

# design-consultation

## 描述
作为高级产品设计师，理解产品、研究竞品、提出完整设计系统，生成预览页并创建DESIGN.md。不是表单向导——是设计顾问，提出有主见的方案并邀请调整。

## 使用场景
- 用户要求"设计系统"、"品牌指南"、"创建DESIGN.md"
- 新项目启动UI开发，没有现有设计系统或DESIGN.md
- 用户提到需要视觉方向或品牌定义

## 不适用场景
- 已有完善的DESIGN.md且无需更新
- 纯后端/基础设施项目，无UI组件
- 用户只需要微调现有设计（用design-review代替）

## 指令

### Phase 0: 预检查

1. **检查现有DESIGN.md：** 查找项目根目录的DESIGN.md或design-system.md
   - 如存在：读取并询问用户——"已有设计系统，要更新、重新开始还是取消？"
   - 如不存在：继续

2. **收集产品上下文：** 读取README.md、package.json，查看src/app/pages/components/目录结构

3. **查找office-hours输出：** 检查`.trae/gstack/data/projects/`下是否有office-hours产物，如有则读取

4. **如代码库为空且目的不明：** 告诉用户"还没有清晰的产品方向，建议先用office-hours探索"

### Phase 1: 产品上下文

向用户提出一个覆盖所有必要信息的问题，预填可从代码库推断的内容：
1. 确认产品是什么、为谁而做、什么行业
2. 项目类型：web应用/仪表盘/营销站/编辑型/内部工具等
3. "要我研究你所在领域顶级产品的设计，还是基于我的设计知识来工作？"
4. 明确告知："随时可以自由对话，这不是死板的流程"

**记忆点强制问题：** "你希望别人第一次看到这个产品后记住的一件事是什么？"——一句话回答，后续所有设计决策都应服务于这个记忆点。

### Phase 2: 研究（仅在用户同意时）

1. **Web搜索** 找5-10个同类产品
2. **视觉研究**（如可用浏览器工具）：访问3-5个竞品站点，分析字体、色彩、布局、间距、美学方向
3. **三层综合：**
   - Layer 1（成熟模式）：该品类所有产品共享的设计模式
   - Layer 2（新兴趋势）：当前设计话语和搜索结果在说什么
   - Layer 3（第一性原理）：基于此产品的用户和定位，传统设计方法是否有错？

如用户说不需要研究，跳过此阶段。

### Phase 3: 完整提案

提出一切作为一个连贯的包：

```
基于[产品上下文]和[研究发现/设计知识]：

美学：[方向] — [一句话理由]
装饰：[级别] — [为什么配这个美学]
布局：[方法] — [为什么适合这个产品类型]
色彩：[方法] + 提议色板（hex值）— [理由]
排版：[3个字体推荐及角色] — [为什么选这些字体]
间距：[基础单位 + 密度] — [理由]
动效：[方法] — [理由]

这个系统是连贯的，因为[解释选择如何互相强化]。

安全选择（品类基线——你的用户期望这些）：
  - [2-3个符合品类惯例的决策]

风险（你的产品获得自己面貌的地方）：
  - [2-3个有意偏离惯例的决策]
  - 每个风险：它是什么、为什么有效、获得什么、代价什么
```

**美学方向参考：** 极简主义 / 极繁混沌 / 复古未来 / 奢华精致 / 俏皮玩具 / 编辑杂志 / 粗野主义 / 装饰艺术 / 有机自然 / 工业实用

**字体推荐（按用途）：**
- 展示/英雄：Satoshi, General Sans, Instrument Serif, Fraunces, Clash Grotesk, Cabinet Grotesk
- 正文：Instrument Sans, DM Sans, Source Sans 3, Geist, Plus Jakarta Sans, Outfit
- 数据/表格：Geist (tabular-nums), DM Sans (tabular-nums), JetBrains Mono, IBM Plex Mono
- 代码：JetBrains Mono, Fira Code, Berkeley Mono, Geist Mono

**字体黑名单（永不推荐）：** Papyrus, Comic Sans, Lobster, Impact, Jokerman, Bleeding Cowboys, Permanent Marker, Bradley Hand, Brush Script, Hobo, Trajan, Raleway, Clash Display, Courier New (正文)

**过度使用字体（不主动推荐为主字体）：** Inter, Roboto, Arial, Helvetica, Open Sans, Lato, Montserrat, Poppins, Space Grotesk

**AI slop反模式（永不包含）：** 紫色/紫色渐变默认强调色、3列特性网格+彩色圆圈图标、居中一切+均匀间距、统一气泡圆角、渐变按钮CTA、通用stock-photo风格hero

**连贯性验证：** 当用户覆盖某个部分时，检查其余是否仍然连贯，温和提醒但不阻止。

### Phase 4: 深入（仅在用户要求调整时）

当用户想更改特定部分时深入：
- **字体：** 展示3-5个具体候选及理由
- **色彩：** 展示2-3个色板选项及色彩理论推理
- **美学/布局/间距/动效：** 展示方法及具体权衡

每次深入后重新检查与系统其余部分的连贯性。

### Phase 5: 设计系统预览

生成一个精美的HTML预览页面，在用户浏览器中打开。

**预览页要求：**
1. 从Google Fonts加载提议的字体
2. 使用提议的色彩板——自身就是设计系统的活体展示
3. 展示产品名称（不是Lorem Ipsum）
4. **字体样片区：** 每个字体候选在其提议角色中展示
5. **色彩板区：** 色块+hex值+名称，示例UI组件（按钮、卡片、表单、警告）
6. **真实产品模型：** 基于项目类型渲染2-3个真实页面布局
7. **明/暗模式切换**
8. **响应式**

如用户说跳过预览，直接进入Phase 6。

### Phase 6: 写DESIGN.md并确认

写入项目根目录DESIGN.md，结构如下：

```markdown
# Design System — [项目名]

## Product Context
- **这是什么：** [1-2句描述]
- **为谁而做：** [目标用户]
- **行业/领域：** [品类、同行]
- **项目类型：** [web应用/仪表盘/营销站/编辑型/内部工具]

## Aesthetic Direction
- **方向：** [名称]
- **装饰级别：** [minimal/intentional/expressive]
- **氛围：** [1-2句产品应该给人的感觉]

## Typography
- **展示/英雄：** [字体名] — [理由]
- **正文：** [字体名] — [理由]
- **UI/标签：** [字体名或"同正文"]
- **数据/表格：** [字体名] — [理由，必须支持tabular-nums]
- **代码：** [字体名]
- **加载：** [CDN URL或自托管策略]
- **字号比例：** [模块化比例及具体px/rem值]

## Color
- **方法：** [restrained/balanced/expressive]
- **主色：** [hex] — [代表什么，用法]
- **辅色：** [hex] — [用法]
- **中性色：** [暖/冷灰，hex范围]
- **语义色：** success [hex], warning [hex], error [hex], info [hex]
- **暗色模式：** [策略]

## Spacing
- **基础单位：** [4px或8px]
- **密度：** [compact/comfortable/spacious]
- **比例：** 2xs(2) xs(4) sm(8) md(16) lg(24) xl(32) 2xl(48) 3xl(64)

## Layout
- **方法：** [grid-disciplined/creative-editorial/hybrid]
- **网格：** [每断点列数]
- **最大内容宽度：** [值]
- **圆角：** [层级比例]

## Motion
- **方法：** [minimal-functional/intentional/expressive]
- **缓动：** enter(ease-out) exit(ease-in) move(ease-in-out)
- **时长：** micro(50-100ms) short(150-250ms) medium(250-400ms) long(400-700ms)

## Decisions Log
| Date | Decision | Rationale |
|------|----------|-----------|
| [today] | 初始设计系统创建 | 由design-consultation基于[产品上下文/研究]创建 |
```

更新项目配置文件（`.trae/rules/`或等效），追加设计系统引用段落。

列出所有决策，标记未经用户明确确认的默认选择。选项：
- A) 发布 — 写DESIGN.md和配置文件
- B) 我想改一些东西
- C) 重新开始

## 输出
- 项目根目录的DESIGN.md文件
- HTML预览页面（可选）
- 项目配置文件中的设计系统引用段落

## 依赖
- 浏览器工具（可选，用于竞品视觉研究）
- Web搜索工具（可选，用于竞品研究）
- 文件读写工具（必需，用于写DESIGN.md和预览页）
