---
name: gstack-benchmark
description: |
  当需要检测Web应用性能回归时使用。9阶段工作流：设置→页面发现→性能数据收集→基线捕获→比较→最慢资源→性能预算→趋势分析→保存报告。回归阈值：时序>50%或>500ms=REGRESSION，包大小>25%=REGRESSION。适用于"页面速度"、"性能回归"、"benchmark"场景。
---

# gstack-benchmark

## 上下文
gstack-benchmark是Web性能回归检测技能，使用浏览器工具收集性能数据，与基线对比检测回归。

**TRAE适配说明：** 原Claude Code使用browse daemon（$B）进行浏览器操作。TRAE中使用agent-browser技能替代。路径 `.gstack/` 适配为 `.trae/gstack/`。

## 指令

### 9阶段工作流

**阶段1：设置**
- 创建输出目录 `.trae/gstack/benchmark-reports/`
- 解析参数（目标URL、页面列表、基线文件路径）

**阶段2：页面发现**
- 如未指定页面，自动发现应用的主要页面
- 从首页导航结构提取页面列表

**阶段3：性能数据收集**
对每个页面收集：
- 页面加载时间（Navigation Timing API）
- 首次内容绘制（FCP）
- 最大内容绘制（LCP）
- 累积布局偏移（CLS）
- 首次输入延迟（FID）
- 资源加载时间
- JavaScript包大小

**阶段4：基线捕获**
- 首次运行时保存当前性能数据作为基线
- 保存到 `.trae/gstack/benchmark-reports/baseline.json`

**阶段5：比较**
与基线对比，检测回归：
- 时序指标 >50% 或 >500ms → **REGRESSION**
- 包大小 >25% → **REGRESSION**
- 时序指标 >20% 但 <50% → **WARNING**
- 包大小 >10% 但 <25% → **WARNING**

**阶段6：最慢资源**
识别加载最慢的资源：
- 最慢的5个请求
- 最大的5个资源
- 阻塞渲染的资源

**阶段7：性能预算**
检查是否超出性能预算（如有配置）：
- 最大FCP: 1.8s
- 最大LCP: 2.5s
- 最大CLS: 0.1
- 最大JS包: 300KB（可配置）

**阶段8：趋势分析**
加载历史数据，显示性能趋势：
- 每个指标的变化趋势
- 与上次基准的对比
- 长期趋势（如有多条历史记录）

**阶段9：保存报告**
保存到 `.trae/gstack/benchmark-reports/{date}-benchmark.md` 和 `.json`

### 报告格式
```
PERFORMANCE BENCHMARK — [url]
═══════════════════════════════
Date:     2026-05-16
Pages:    5
Baseline: 2026-05-10

Per-Page Results:
─────────────────────────────────────────────────────
  Page          FCP    LCP    CLS    JS Size  Status
  /             1.2s   2.1s   0.05   245KB    OK
  /dashboard    1.8s   3.5s↑  0.12↑  380KB↑  REGRESSION
  /settings     0.9s   1.8s   0.03   180KB    OK

REGRESSIONS: 1
WARNINGS: 0
```

## 使用场景
- 部署后性能验证
- 定期性能监控
- 性能优化前后对比
- CI/CD中的性能门

## 不适用场景
- AI模型性能基准测试（使用gstack-benchmark-models）
- 不涉及Web页面的性能测试
- 功能测试（使用gstack-qa）

## 输出
- 性能基准报告
- 基线数据（baseline.json）
- 回归告警
- 趋势分析
- `.trae/gstack/benchmark-reports/`

## 依赖
- agent-browser技能（浏览器操作和性能数据收集）
- git（分支检测）
