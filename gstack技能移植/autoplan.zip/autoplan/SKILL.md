---
name: autoplan
description: |
  自动审查流水线 — 依次运行CEO、设计、工程、DX审查技能，使用6条决策原则自动决策。
  将品味决策（接近方案、边界范围、Codex分歧）提交最终审批门。
  一条命令，输出完整审查后的计划。
  当用户要求"自动审查"、"autoplan"、"运行所有审查"、"自动审查此计划"时使用。
---

# autoplan

## 描述

自动审查流水线。读取CEO、设计、工程、DX审查技能文件，按顺序以完整深度执行。中间决策由6条原则自动回答，品味决策在最终审批门呈现给用户。

## 使用场景

- 用户要求"自动审查"、"autoplan"、"运行所有审查"
- 用户有计划文件，想运行完整审查流程而不回答15-30个中间问题
- 用户说"帮我做决策"、"make the decisions for me"

## 不适用场景

- 用户想逐项交互审查（应使用单独的 plan-ceo-review 等技能）
- 没有计划文件可审查时

## 指令

### 初始化

1. 检测当前git分支和基础分支
2. 读取项目配置文件（`.trae/rules/`或项目根目录配置）、TODOS.md、git log -30、git diff --stat
3. 检测UI范围：在计划中搜索视图/渲染术语（component, screen, form, button, modal等），需2+匹配
4. 检测DX范围：搜索开发者面向术语（API, endpoint, CLI, SDK, library等），需2+匹配
5. 保存计划文件当前状态为恢复点（写入 `.trae/gstack/data/projects/{slug}/{branch}-autoplan-restore-{datetime}.md`）

### 6条决策原则

自动回答所有中间问题的规则：

1. **选择完整性** — 交付完整方案。选择覆盖更多边界情况的方案。
2. **煮沸湖泊** — 修复爆炸半径内的所有问题（本计划修改的文件+直接导入者）。自动批准在爆炸半径内且<1天CC工作量（<5文件，无新基础设施）的扩展。
3. **务实** — 如果两个方案修复同一问题，选更干净的。5秒选择，不是5分钟。
4. **DRY** — 重复已有功能？拒绝。复用已有的。
5. **显式优于巧妙** — 10行明显修复 > 200行抽象。选择新贡献者30秒能读懂的。
6. **偏向行动** — 合并 > 审查循环 > 陈旧讨论。标记关注但不阻塞。

**冲突解决（上下文相关的决胜规则）：**
- CEO阶段：P1（完整性）+ P2（煮沸湖泊）主导
- 工程阶段：P5（显式）+ P3（务实）主导
- 设计阶段：P5（显式）+ P1（完整性）主导

### 决策分类

- **机械决策** — 有明确正确答案。静默自动决策。
- **品味决策** — 合理的人可能不同意。自动决策但提交最终门。三种来源：接近方案、边界范围、Codex分歧。
- **用户挑战** — 两个模型都认为用户方向应改变。绝不自动决策。提交最终门时附带更丰富的上下文。

### 顺序执行（强制）

阶段必须严格按序执行：CEO → 设计 → 工程 → DX。每个阶段必须完全完成后才开始下一个。

### Phase 0: 接收 + 恢复点

1. 保存计划文件当前状态为恢复点
2. 读取上下文（配置文件、TODOS.md、git log、diff、设计文档）
3. 检测UI范围和DX范围
4. 从磁盘加载审查技能文件：
   - `plan-ceo-review/SKILL.md`（始终加载）
   - `plan-design-review/SKILL.md`（仅UI范围时）
   - `plan-eng-review/SKILL.md`（始终加载）
   - `plan-devex-review/SKILL.md`（仅DX范围时）

加载技能文件时跳过这些段落（已由autoplan处理）：Preamble、AskUserQuestion Format、Completeness Principle、Search Before Building、Completion Status Protocol、Telemetry、Step 0平台检测、Review Readiness Dashboard、Plan File Review Report、Prerequisite Skill Offer、Outside Voice。

### Phase 1: CEO审查（策略与范围）

遵循plan-ceo-review技能 — 所有段落，完整深度。覆盖：每个向用户提问 → 使用6条原则自动决策。

覆盖规则：
- 模式选择：SELECTIVE EXPANSION
- 前提：接受合理的（P6），仅挑战明显错误的
- **门：向用户呈现前提确认** — 这是唯一不由自动决策的提问
- 替代方案：选最高完整性（P1）。平局选最简单（P5）。前两名接近 → 标记品味决策
- 范围扩展：在爆炸半径内+<1d CC → 批准（P2）。范围外 → 延迟到TODOS.md（P3）。重复 → 拒绝（P4）。边界（3-5文件）→ 标记品味决策
- 所有10个审查段落：完整运行，自动决策每个问题，记录每个决策

必须产出：前提挑战、现有代码利用图、梦想状态图、实现替代方案表、模式分析、时间审问、模式确认、错误与救援注册表、失败模式注册表、梦想状态增量、完成摘要

### Phase 2: 设计审查（条件 — 无UI范围时跳过）

遵循plan-design-review技能 — 所有7个维度，完整深度。

覆盖规则：
- 关注领域：所有相关维度（P1）
- 结构问题（缺失状态、层级断裂）：自动修复（P5）
- 审美/品味问题：标记品味决策
- 设计系统对齐：如DESIGN.md存在且修复明显则自动修复

必须产出：7个维度评分、问题识别与自动决策、设计石蕊记分卡

### Phase 3: 工程审查 + 双声音

遵循plan-eng-review技能 — 所有段落，完整深度。

覆盖规则：
- 范围挑战：绝不缩减（P2）
- 架构选择：显式优于巧妙（P5）
- 评估：始终包含所有相关套件（P1）
- 测试计划：生成工件写入 `.trae/gstack/data/projects/{slug}/{user}-{branch}-test-plan-{datetime}.md`
- TODOS.md：收集所有阶段的延迟范围扩展，自动写入

必须产出：范围挑战、架构ASCII图、测试图、测试计划工件、失败模式注册表、完成摘要、TODOS.md更新

### Phase 3.5: DX审查（条件 — 无开发者面向范围时跳过）

遵循plan-devex-review技能 — 所有8个DX维度，完整深度。

覆盖规则：
- 模式选择：DX POLISH
- 人物画像：从README/文档推断
- 竞争基准：如可用WebSearch则运行搜索
- 魔法时刻：选最低工作量交付载体
- 入门摩擦：始终优化向更少步骤
- 错误消息质量：始终要求问题+原因+修复
- API/CLI命名：一致性胜过巧妙

必须产出：开发者旅程图、开发者共情叙述、DX记分卡（8维度评分）、DX实现清单、TTHW评估

### 决策审计追踪

每个自动决策后，追加一行到计划文件：

```markdown
## Decision Audit Trail
| # | Phase | Decision | Classification | Principle | Rationale | Rejected |
|---|-------|----------|-----------|-----------|----------|----------|
```

### Phase 4: 最终审批门

向用户呈现：

```
## /autoplan Review Complete

### Plan Summary
[1-3句摘要]

### Decisions Made: [N] total ([M] auto-decided, [K] taste choices, [J] user challenges)

### User Challenges (both models disagree with your stated direction)
[每个用户挑战：]
**Challenge [N]: [title]** (from [phase])
You said: [用户原始方向]
Both models recommend: [改变]
Why: [推理]
What we might be missing: [盲点]
If we're wrong, the cost is: [改变的下行风险]

### Your Choices (taste decisions)
[每个品味决策：]
**Choice [N]: [title]** (from [phase])
I recommend [X] — [原则]. But [Y] is also viable: [1句下游影响]

### Auto-Decided: [M] decisions [see Decision Audit Trail in plan file]

### Review Scores
- CEO: [摘要]
- Design: [摘要或"skipped, no UI scope"]
- Eng: [摘要]
- DX: [摘要或"skipped, no developer-facing scope"]

### Cross-Phase Themes
[2+阶段独立标记的关注]

### Deferred to TODOS.md
[自动延迟的项目及原因]
```

认知负载管理：
- 0个用户挑战：跳过该段
- 0个品味决策：跳过该段
- 8+品味决策：按阶段分组，添加警告

向用户提问选项：
- A) 按原样批准（接受所有推荐）
- B) 带覆盖批准（指定要更改的品味决策）
- C) 询问（询问任何特定决策）
- D) 修订（计划本身需要更改）
- E) 拒绝（重新开始）

### 完成后

1. 写入审查日志到 `.trae/gstack/data/`
2. 建议下一步：准备创建PR时使用 `/ship`

## 输出

- 完整审查后的计划文件（含决策审计追踪）
- 各阶段审查摘要
- 最终审批门呈现
- 审查日志工件

## 依赖

- 需要plan-ceo-review、plan-eng-review技能文件可用
- plan-design-review（UI范围时需要）
- plan-devex-review（DX范围时需要）
- git仓库上下文
- 如可用，Codex CLI（可选，用于双声音审查）
