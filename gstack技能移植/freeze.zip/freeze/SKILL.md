---
name: gstack-freeze
description: |
  当需要将文件编辑限制在特定目录时使用。阻止对允许路径之外的Edit和Write操作。适用于调试时防止意外"修复"无关代码，或希望将更改范围限定在一个模块内。
---

# gstack-freeze

## 上下文
gstack-freeze锁定文件编辑到指定目录。任何针对允许路径外文件的Edit或Write操作将被阻止。

**TRAE适配说明：** 原Claude Code使用PreToolUse hook（check-freeze.sh）自动拦截Edit/Write。TRAE不支持hooks，改为在执行Edit/Write操作前手动检查文件路径是否在冻结目录内，超出范围则拒绝执行。

## 指令

### 设置
1. 询问用户要限制编辑的目录路径
2. 解析为绝对路径
3. 确保路径以 `/` 结尾
4. 保存冻结状态到 `.trae/gstack/state/freeze-dir.txt`
5. 告知用户："编辑已限制到 `<path>/`。此目录外的Edit/Write将被阻止。更改边界运行 `/freeze`，移除运行 `/unfreeze`。"

### 编辑检查
每次执行Edit或Write操作前：
1. 读取 `.trae/gstack/state/freeze-dir.txt` 获取冻结目录
2. 检查目标文件路径是否以冻结目录开头
3. 如不在范围内，拒绝操作并告知用户
4. 如在范围内，正常执行

### 注意事项
- 路径末尾的 `/` 防止 `/src` 匹配 `/src-old`
- Freeze仅适用于Edit和Write工具——Read、Bash、Glob、Grep不受影响
- 这防止意外编辑，不是安全边界——Bash命令如 `sed` 仍可修改边界外文件
- 停用：运行 `/unfreeze` 或结束会话

## 使用场景
- 调试时防止修改无关代码
- 将更改范围限定到特定模块
- 代码审查时只允许修改特定目录
- 协作开发时保护他人负责的代码区域

## 不适用场景
- 需要跨目录编辑时
- 不需要编辑限制的简单任务
- 已结束会话（冻结自动失效）

## 输出
- 冻结边界设置确认
- 编辑操作被阻止时的警告

## 依赖
- `.trae/gstack/state/` 目录（存储冻结状态文件）
