---
name: gstack-context-save
description: |
  当需要保存当前工作上下文以便后续恢复时使用。收集当前会话状态（分支、修改文件、决策记录），生成结构化保存文件。适用于"保存进度"、"保存上下文"、"checkpoint"场景。
---

# gstack-context-save

## 上下文
gstack-context-save保存工作上下文，使得后续会话（或上下文压缩后）可以恢复到之前的工作状态。支持跨分支恢复。

**TRAE适配说明：** 路径 `.gstack/` 适配为 `.trae/gstack/`。原CLI工具（gstack-slug等）需gstack CLI或手动管理slug。

## 指令

### 两种模式

**Save模式（默认）：**
1. 收集状态：
   - 当前git分支
   - 修改的文件列表
   - 未提交的更改
   - 当前工作进度
2. 总结上下文：
   - 已完成的工作
   - 进行中的工作
   - 待办事项
   - 关键决策
   - 遇到的问题和解决方案
3. 计算会话时长
4. 写入保存文件

**List模式：**
列出所有可用的保存上下文。

### 保存文件格式
保存到 `.trae/gstack/context-saves/{branch}-{timestamp}.md`：

```markdown
---
status: in-progress
branch: feature/auth
timestamp: 2026-05-16T10:30:00Z
session_duration_s: 1800
files_modified:
  - src/auth.ts
  - src/middleware.ts
---

## 已完成
- 实现JWT认证中间件
- 添加登录/登出API

## 进行中
- 刷新token逻辑

## 待办
- 添加认证测试
- 更新API文档

## 关键决策
- 使用RS256而非HS256签名算法

## 遇到的问题
- cookie domain配置需与前端一致
```

### 硬门
**不实现代码变更。** 只保存上下文信息。

## 使用场景
- 长时间工作中需要暂停
- 上下文即将压缩前保存关键信息
- 切换分支前保存当前工作状态
- 每日工作结束前保存进度

## 不适用场景
- 需要恢复上下文时（使用gstack-context-restore）
- 需要提交代码时（使用git commit）
- 简单任务无需保存

## 输出
- 上下文保存文件（`.trae/gstack/context-saves/`）
- 保存确认信息

## 依赖
- git（分支检测、文件状态）
