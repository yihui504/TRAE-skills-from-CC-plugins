---
name: gstack-gstack-upgrade
description: 当需要升级gstack到最新版本、更新gstack工具链、查看新版功能时使用
---

## 描述

升级gstack到最新版本并展示更新内容。检测全局vs vendored安装，运行升级，显示更新日志。支持自动升级和手动确认模式。

## 上下文

- gstack支持全局git安装和本地vendored安装
- 升级前自动备份旧版本
- 支持版本迁移脚本自动执行
- 升级后清理缓存和snooze状态

## 指令

### 内联升级流程

此流程被所有技能的preamble引用，当检测到`UPGRADE_AVAILABLE`时触发。

#### Step 1: 询问用户（或自动升级）

1. 检查自动升级配置：读取`.trae/gstack/data/config.yaml`中的`auto_upgrade`设置
2. 如果`AUTO_UPGRADE=true`：跳过询问，直接升级
3. 否则使用AskUserQuestion询问：
   - "Yes, upgrade now"
   - "Always keep me up to date"（启用自动升级）
   - "Not now"（snooze，递增延迟24h→48h→1周）
   - "Never ask again"（禁用更新检查）

#### Step 2: 检测安装类型

检测gstack的安装方式：

1. 全局git安装：`.trae/gstack/.git`存在
2. 本地git安装：项目目录下`.trae/gstack/.git`存在
3. Vendored安装：目录存在但无`.git`
4. 输出安装类型和目录路径

#### Step 3: 保存旧版本

读取`$INSTALL_DIR/VERSION`文件获取当前版本号。

#### Step 4: 执行升级

**Git安装：**

1. `git stash`保存本地修改
2. `git fetch origin`
3. `git reset --hard origin/main`
4. `./setup`

**Vendored安装：**

1. 克隆最新版本到临时目录
2. 备份旧版本到`.bak`
3. 移动新版本到安装目录
4. 运行`./setup`
5. 清理临时文件和备份

#### Step 4.5: 处理本地vendored副本

1. 检查是否存在本地vendored副本
2. 如果team mode激活，删除vendored副本
3. 否则，从主安装复制更新到vendored副本

#### Step 4.75: 运行版本迁移

1. 查找`gstack-upgrade/migrations/`目录
2. 按版本号排序执行迁移脚本（`v*.sh`）
3. 只运行版本号大于旧版本的迁移

#### Step 5: 写入标记并清理缓存

1. 写入`just-upgraded-from`标记
2. 删除`last-update-check`和`update-snoozed`

#### Step 6: 显示更新内容

1. 读取`CHANGELOG.md`
2. 提取旧版本到新版本之间的所有条目
3. 按主题分组，总结5-7个要点
4. 聚焦用户可见变更

#### Step 7: 继续

升级完成后，继续执行用户原始调用的技能。

### 独立使用

当直接调用`/gstack-upgrade`时：

1. 强制执行更新检查：`gstack-update-check --force`
2. 如果有可用更新，执行Step 2-6
3. 如果已是最新版本，检查并清理过时的本地vendored副本

## 使用场景

- 升级gstack到最新版本
- 检查是否有新版本可用
- 清理过时的vendored安装
- 修复升级后的问题

## 不适用场景

- 需要保持当前版本不变
- 在CI环境中自动升级（应使用固定版本）

## 输出

- gstack升级到最新版本
- 更新日志摘要
- 迁移脚本执行结果
- 版本标记和缓存清理

## 依赖

- git
- gstack安装目录
- 网络连接（用于拉取更新）

## TRAE适配说明

- 路径适配：`~/.claude/skills/gstack/` → `.trae/gstack/`，`~/.gstack/` → `.trae/gstack/data/`
- 配置文件路径从`~/.gstack/config.yaml`适配为`.trae/gstack/data/config.yaml`
- Preamble脚本 → 文字指令
- 升级检查和snooze状态文件路径适配
