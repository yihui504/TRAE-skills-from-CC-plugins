---
name: gstack-landing-report
description: 当需要查看版本队列状态、了解哪些版本号被PR占用、查看Conductor工作区WIP状态、确定下一个可用的版本号时使用
---

## 描述

只读队列仪表板，显示当前哪些VERSION槽位被开放PR占用，哪些兄弟Conductor工作区有即将发布的WIP工作，以及/ship会选择哪个槽位。无任何修改操作，只是快照。

## 上下文

- 使用与/ship相同的`bin/gstack-next-version`工具
- 支持GitHub和GitLab平台
- 可检测兄弟worktree的WIP状态
- 完全只读，安全在plan mode中运行

## 指令

### Step 1: 检测平台和基础分支

1. 使用`gh`或`glab` CLI检测平台
2. 确定基础分支（PR目标分支或仓库默认分支）
3. 回退到git原生检测

### Step 2: 读取当前状态

1. 读取当前分支的VERSION文件
2. 获取基础分支的VERSION
3. 比较版本差异

### Step 3: 查询队列

对每个bump级别（micro/patch/minor/major）调用`gstack-next-version`：

```bash
for LEVEL in micro patch minor major; do
  bun run bin/gstack-next-version \
    --base "$BASE_BRANCH" \
    --bump "$LEVEL" \
    --current-version "$BASE_VERSION"
done
```

### Step 4: 渲染仪表板

构建表格输出，包含：

- 仓库信息（owner/repo、基础分支、平台、在线状态）
- 占用版本的开放PR列表
- 兄弟Conductor worktree状态（路径、分支、版本、最后提交、PR、活跃标记）
- 各bump级别的下一个可用版本号

格式示例：

```
╔══════════════════════════════════════════════════════════════════╗
║                     GSTACK LANDING REPORT                        ║
╠══════════════════════════════════════════════════════════════════╣
║ Repo:    <owner/repo>                                            ║
║ Base:    <base> @ v<base-version>                                ║
║ Status:  ONLINE                                                   ║
╚══════════════════════════════════════════════════════════════════╝

Open PRs claiming versions:
  #1152  alpha-branch  → v1.7.0.0
  ...

If you ran /ship right now, you'd claim:
  micro bump:  v1.6.3.1
  patch bump:  v1.7.1.0
  minor bump:  v1.8.0.0
  major bump:  v2.0.0.0
```

### Step 5: 建议下一步

根据队列状态给出建议：

1. **有版本冲突** → 提醒两个PR占用同一版本号
2. **有活跃兄弟分支** → 提醒可能需要rebump
3. **队列干净** → 确认可以无冲突发布

## 使用场景

- 在/ship之前查看版本队列状态
- 多个并行工作区需要协调版本号
- 了解哪些PR即将合并
- 确定下一个可用的版本号

## 不适用场景

- 单人单分支开发，不需要版本协调
- 不使用VERSION文件的项目
- 不使用Conductor多工作区的工作流

## 输出

- 版本队列仪表板（表格格式）
- 各bump级别的下一个可用版本
- 队列状态建议

## 依赖

- git仓库
- `gh`或`glab` CLI（可选，用于PR查询）
- `gstack-next-version`工具
- bun运行时

## TRAE适配说明

- 路径适配：`~/.claude/skills/gstack/` → `.trae/gstack/`，`~/.gstack/` → `.trae/gstack/data/`
- 此技能完全只读，TRAE适配改动最小
- Preamble脚本 → 文字指令
