---
name: gstack-pair-agent
description: 当需要将远程AI代理与浏览器配对、共享浏览器给其他代理、让另一个代理使用当前浏览器时使用
---

## 描述

将远程AI代理与当前浏览器配对。一条命令生成设置密钥并打印指令，另一个代理按照指令连接。支持OpenClaw、Hermes、Codex、Cursor或任何能发HTTP请求的代理。远程代理获得自己的标签页，具有范围化访问权限。

## 上下文

- gstack浏览器运行本地HTTP服务器
- 设置密钥5分钟过期且只能使用一次
- 会话令牌持续24小时
- 同机器可跳过复制粘贴，直接写入凭据
- 远程机器需要ngrok隧道

## 指令

### 前置检查：构建browse二进制

同open-gstack-browser技能的前置检查流程。

### Step 1: 检查前置条件

1. 运行`$B status`检查browse服务器状态
2. 如果服务器未运行，启动它：`$B goto about:blank`

### Step 2: 询问配对目标

使用AskUserQuestion询问要配对的代理类型：

- A) OpenClaw（本地或远程）
- B) Codex / OpenAI Agents（本地）
- C) Cursor（本地）
- D) 另一个Claude Code会话（本地或远程）
- E) 其他（通用HTTP指令，适用于Hermes等）

根据回答设置TARGET_HOST：A→openclaw, B→codex, C→cursor, D→claude, E→generic

### Step 3: 本地或远程

使用AskUserQuestion询问代理运行位置：

- A) 同机器（直接写入凭据，推荐）
- B) 不同机器（生成指令块供复制粘贴）

### Step 4: 执行配对

**同机器（选项A）：**

运行`$B pair-agent --local TARGET_HOST`

成功后告知用户目标代理现在可以使用浏览器了。

**不同机器（选项B）：**

1. 检测ngrok状态
2. 如果ngrok已安装且已认证：运行`$B pair-agent --client TARGET_HOST`
3. 如果需要admin权限：运行`$B pair-agent --admin --client TARGET_HOST`
4. **必须将完整指令块输出给用户**，包含在代码块中方便复制
5. 如果ngrok未安装/未认证：引导用户安装和认证ngrok

### Step 5: 验证连接

等待片刻后运行`$B status`，查找已连接的代理。

### 撤销访问

- 断开特定代理：`$B tunnel revoke AGENT_NAME`
- 断开所有代理并轮换根令牌：`$B tunnel rotate`

## 使用场景

- 需要让OpenClaw/Codex/Cursor等代理共享当前浏览器
- 多代理协作场景，需要浏览器共享
- 远程代理需要访问本地浏览器

## 不适用场景

- 只需要单个代理使用浏览器
- 不需要跨代理浏览器共享

## 输出

- 配对成功确认
- 远程代理连接到浏览器，拥有独立标签页
- 如远程模式，提供ngrok隧道URL和设置指令块

## 依赖

- gstack browse二进制文件（需先构建）
- ngrok（远程模式需要）
- TRAE适配：`$B` browse守护进程 → TRAE的agent-browser技能或浏览器MCP

## TRAE适配说明

- 路径适配：`~/.claude/skills/gstack/` → `.trae/gstack/`，`~/.gstack/` → `.trae/gstack/data/`
- 工具适配：`$B` → TRAE的agent-browser技能或浏览器MCP
- AskUserQuestion → TRAE的AskUserQuestion工具
- Preamble脚本 → 文字指令
- 各代理的凭据写入路径需适配TRAE环境
