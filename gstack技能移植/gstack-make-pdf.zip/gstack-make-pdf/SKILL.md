---
name: gstack-make-pdf
description: 当需要将Markdown文件转为PDF、生成出版物质量的文档、导出带封面和目录的PDF时使用
---

## 描述

将Markdown文件转为出版物质量的PDF。1英寸边距、智能分页、页码、封面页、页眉、弯引号和em dash、可点击目录、对角DRAFT水印。不是草稿级产物，是完成级产物。

## 上下文

- 使用Paged.js和Chromium渲染PDF
- 核心二进制：`.trae/gstack/make-pdf/dist/pdf`（需先构建）
- Linux需安装`fonts-liberation`以正确渲染Helvetica
- 输出约定：stdout只输出路径（一行），stderr输出进度

## 指令

### 前置检查：构建make-pdf二进制

1. 查找make-pdf二进制路径（环境变量`MAKE_PDF_BIN`→项目本地→全局）
2. 如果不可用，提示运行`./setup`构建
3. 构建成功后`$P`变量指向二进制路径

### 核心命令

- `$P generate <input.md> [output.pdf]` — 渲染Markdown为PDF（80%用例）
- `$P generate --cover --toc essay.md out.pdf` — 完整出版布局
- `$P generate --watermark DRAFT memo.md draft.pdf` — 对角DRAFT水印
- `$P preview <input.md>` — 渲染HTML并在浏览器中预览（快速迭代）
- `$P setup` — 验证browse+Chromium+pdftotext并运行冒烟测试

### 80%用例：备忘录/信件

```bash
$P generate letter.md                 # 写入 /tmp/letter.pdf
$P generate letter.md letter.pdf      # 显式输出路径
```

### 出版模式：封面+目录+章节分页

```bash
$P generate --cover --toc --author "Author" --title "Title" essay.md essay.pdf
```

每个顶级H1自动开始新页。用`--no-chapter-breaks`禁用。

### 草稿水印

```bash
$P generate --watermark DRAFT memo.md draft.pdf
```

### 快速迭代预览

```bash
$P preview essay.md
```

### 常用标志

```
页面布局:
  --margins <dim>            1in(默认)|72pt|2.54cm|25mm
  --page-size letter|a4|legal

结构:
  --cover                    封面页
  --toc                      可点击目录
  --no-chapter-breaks        不在H1处分页

品牌:
  --watermark <text>         对角水印
  --header-template <html>   自定义页眉
  --footer-template <html>   自定义页脚
  --no-confidential          抑制CONFIDENTIAL页脚

输出:
  --page-numbers             "N of M"页脚
  --quiet                    抑制进度输出
```

### 调试

- 输出空白 → 检查browse守护进程：`$B status`
- 复制粘贴文字碎片 → 移除代码块后重试
- Paged.js超时 → 可能无标题，去掉`--toc`
- 外部图片缺失 → 添加`--allow-network`

## 使用场景

- 将Markdown文档转为PDF
- 生成带封面和目录的正式文档
- 创建带DRAFT水印的草稿文档
- 快速预览Markdown的打印效果

## 不适用场景

- 需要编辑PDF（此技能只生成PDF）
- 需要复杂排版（如多栏、嵌入字体）
- 源文件不是Markdown格式

## 输出

- PDF文件路径（stdout一行）
- 渲染进度（stderr）
- 退出码：0成功/1参数错误/2渲染错误/3 Paged.js超时/4 browse不可用

## 依赖

- gstack make-pdf二进制（需先构建）
- gstack browse守护进程
- Chromium/Playwright
- Paged.js
- TRAE适配：`$B` → TRAE的agent-browser技能或浏览器MCP

## TRAE适配说明

- 路径适配：`~/.claude/skills/gstack/` → `.trae/gstack/`，`~/.gstack/` → `.trae/gstack/data/`
- make-pdf二进制路径适配
- `$B` browse守护进程 → TRAE的agent-browser技能或浏览器MCP
- Preamble脚本 → 文字指令
