---
name: gstack-sync-gbrain
description: 当需要将gbrain知识库与当前repo代码同步、刷新语义搜索索引和搜索指导时使用
---

## 描述

保持gbrain与当前repo代码同步，刷新项目规则文件中的GBrain Search Guidance块。运行三阶段编排器：code索引→memory更新→brain-sync同步。

## 上下文

- gbrain需要定期与代码库同步以保持索引新鲜
- 支持`--full`/`--code-only`/`--dry-run`/`--no-memory`/`--no-brain-sync`/`--quiet`参数
- 同步结果反映在规则文件的GBrain Search Guidance块中
- `.gbrain-source`文件标记当前worktree的索引状态

## 指令

### Step 1: 状态探测

1. 检查gbrain CLI是否可用
2. 检查`.gbrain-source`文件是否存在（标记worktree是否已索引）
3. 运行`gbrain doctor --fast --json`检查引擎健康
4. 读取当前配置

### Step 2: 本地引擎预检

1. 如果使用PGLite本地模式，确认数据库文件存在且可访问
2. 如果使用Supabase，确认连接正常
3. 如果使用Remote MCP，确认服务器可达

### Step 3: 运行编排器

三阶段同步：

**阶段1: Code索引**

1. 扫描代码文件变更（基于git diff）
2. 更新代码索引
3. 如果使用`--code-only`，到此结束

**阶段2: Memory更新**

1. 提取代码中的关键概念和关系
2. 更新memory存储
3. 如果使用`--no-memory`，跳过此阶段

**阶段3: Brain-sync同步**

1. 将变更推送到brain引擎
2. 如果使用`--no-brain-sync`，跳过此阶段
3. 如果使用Remote MCP模式，此阶段为no-op

### Step 4: 代码索引健康检查

1. 验证索引完整性
2. 检查索引覆盖率
3. 报告任何异常

### Step 5: 刷新GBrain Search Guidance块

1. 读取项目规则文件
2. 找到`## GBrain Search Guidance`节
3. 根据最新索引状态更新搜索指导
4. 写回规则文件

### Step 6: 判定

- **GREEN**: 同步完成，索引健康
- **YELLOW**: 同步完成但有问题（如索引覆盖率低）
- **RED**: 同步失败

## 使用场景

- 代码变更后需要更新gbrain索引
- 定期维护gbrain知识库
- 切换分支后需要重新索引
- 首次在worktree中设置gbrain

## 不适用场景

- 项目未配置gbrain
- 代码无变更不需要同步
- Remote MCP模式下本地同步无意义

## 输出

- gbrain索引更新完成
- 规则文件中的GBrain Search Guidance块已刷新
- 同步状态判定

## 依赖

- gbrain CLI
- gbrain引擎（PGLite/Supabase/Remote MCP）
- git仓库
- 项目规则文件

## TRAE适配说明

- 路径适配：`~/.claude/skills/gstack/` → `.trae/gstack/`，`~/.gstack/` → `.trae/gstack/data/`
- CLAUDE.md → `.trae/rules/`中的规则文件
- GBrain Search Guidance块写入位置从CLAUDE.md改为`.trae/rules/`
- Preamble脚本 → 文字指令
