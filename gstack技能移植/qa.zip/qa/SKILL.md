---
name: gstack-qa
description: |
  当需要系统化QA测试Web应用并修复发现的bug时使用。运行QA测试后迭代修复源码中的bug，每个修复原子提交并重新验证。支持三级测试深度：Quick（仅关键/高严重性）、Standard+中等）、Exhaustive（+低/外观）。产出前后健康评分、修复证据和发布就绪摘要。
---

# gstack-qa

## 上下文
gstack-qa是QA工程师+bug修复工程师的组合角色。像真实用户一样测试Web应用——点击所有元素、填写所有表单、检查所有状态。发现bug后在源码中修复，原子提交，重新验证。

**TRAE适配说明：** 浏览器操作使用agent-browser技能替代原$B browse二进制。路径 `.gstack/` 适配为 `.trae/gstack/`。AskUserQuestion适配为直接向用户提问。

## 指令

### 参数解析
| 参数 | 默认值 | 示例 |
|------|--------|------|
| 目标URL | 自动检测或必填 | `https://myapp.com` |
| 深度 | Standard | `--quick`, `--exhaustive` |
| 模式 | full | `--regression baseline.json` |
| 输出目录 | `.trae/gstack/qa-reports/` | |
| 范围 | 全应用或diff范围 | `Focus on the billing page` |
| 认证 | 无 | `Sign in to user@example.com` |

### 工作流

**Phase 1: 初始化**
1. 确认浏览器工具可用
2. 创建输出目录 `.trae/gstack/qa-reports/screenshots/`
3. 检查工作树是否干净（如有未提交更改，询问用户：提交/暂存/中止）

**Phase 2: 认证（如需）**
- 使用提供的凭据登录
- 或导入cookie文件
- 2FA/OTP/CAPTCHA需用户手动处理

**Phase 3: 定向**
- 导航到目标URL
- 获取交互元素快照和标注截图
- 获取链接列表（导航结构）
- 检查控制台错误
- 检测框架（Next.js/Rails/WordPress/SPA）

**Phase 4: 探索**
逐页系统化访问，每页执行：
1. 视觉扫描（标注截图中的布局问题）
2. 交互元素测试（点击按钮、链接、控件）
3. 表单测试（空值、无效值、边界值）
4. 导航路径检查
5. 状态测试（空状态、加载、错误、溢出）
6. 控制台错误检查
7. 响应式检查（移动端视口）

**Phase 5: 记录**
发现问题时立即记录：
- 交互bug：操作前截图→执行操作→结果截图→diff
- 静态bug：单张标注截图+描述

**Phase 6: 总结**
1. 计算健康评分（加权平均）
2. 写出"Top 3 Things to Fix"
3. 保存baseline.json

**Phase 7: 分诊**
按严重性排序，根据选择的深度决定修复范围。

**Phase 8: 修复循环**
对每个可修复问题：
1. 定位源码
2. 最小修复
3. 原子提交：`fix(qa): ISSUE-NNN — 描述`
4. 重新测试（前后截图对比）
5. 分类：verified/best-effort/reverted
6. 每5个修复计算WTF-likelihood，超过20%时停止询问

**Phase 9: 最终QA**
重新运行所有受影响页面的QA，计算最终健康评分。

**Phase 10: 报告**
写入 `.trae/gstack/qa-reports/qa-report-{domain}-{date}.md`

### 健康评分规则
| 类别 | 权重 |
|------|------|
| Console | 15% |
| Links | 10% |
| Visual | 10% |
| Functional | 20% |
| UX | 15% |
| Performance | 10% |
| Content | 5% |
| Accessibility | 15% |

### Diff-aware模式（默认）
在功能分支上无URL时自动进入：分析分支diff→识别受影响页面→检测运行中的应用→测试每个受影响页面。

## 使用场景
- 功能分支开发完成后验证
- 部署前全面QA
- 回归测试（与baseline对比）
- 快速冒烟测试

## 不适用场景
- 仅需报告bug不需要修复时（使用gstack-qa-only）
- 纯后端API测试
- 不涉及Web界面的测试

## 输出
- QA报告（`.trae/gstack/qa-reports/qa-report-{domain}-{date}.md`）
- 截图证据目录
- baseline.json（用于回归对比）
- 修复提交（每个bug一个原子提交）
- 健康评分（前后对比）

## 依赖
- agent-browser技能（浏览器操作）
- git（分支检测、提交管理）
- 项目测试框架（用于回归测试生成）
