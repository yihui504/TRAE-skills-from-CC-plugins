---
name: gstack-land-and-deploy
description: |
  当需要合并PR并部署验证时使用。接续gstack-ship的10步流程：预检→首次干跑验证→CI等待→VERSION漂移检测→预合并就绪门→合并PR→部署策略检测→等待部署→金丝雀验证→部署报告。适用于"合并并部署"、"land and deploy"场景。
---

# gstack-land-and-deploy

## 上下文
gstack-land-and-deploy是合并部署验证技能，接续 `/ship` 流程。首次运行为教师模式（详细解释），后续为高效模式。

**TRAE适配说明：** 路径 `.gstack/` 适配为 `.trae/gstack/`。原CLI工具需gstack CLI支持。

## 指令

### 10步流程

**Step 1: 预检**
- 确认PR存在且已通过审查
- 检查CI状态
- 确认当前分支状态

**Step 2: 首次干跑验证**
- 模拟合并过程，检查潜在冲突
- 验证合并后代码可构建

**Step 3: CI等待**
- 等待所有CI检查通过
- 超时处理

**Step 4: VERSION漂移检测**
- 检查合并目标分支的VERSION是否已变更
- 如有漂移，调整版本号

**Step 5: 预合并就绪门**
- 所有检查点确认：
  - CI通过
  - 审查完成
  - 无合并冲突
  - 版本号正确

**Step 6: 合并PR**
- 使用平台CLI合并PR
- GitHub: `gh pr merge`
- GitLab: `glab mr merge`

**Step 7: 部署策略检测**
- 检测项目部署方式：
  - Vercel/Netlify（自动部署）
  - Docker + K8s
  - Heroku
  - 自定义CI/CD
  - staging-first选项

**Step 8: 等待部署**
- 监控部署进度
- 等待部署完成

**Step 9: 金丝雀验证**
- 部署后验证生产环境：
  - 页面加载正常
  - 无新控制台错误
  - 关键功能可用
  - 性能无回退

**Step 10: 部署报告**
产出部署结果摘要：
- 合并的PR信息
- 部署目标和状态
- 金丝雀验证结果
- 回滚选项（始终可用）

### 重要规则
- 回滚始终是选项
- 首次运行=教师模式，后续=高效模式
- 支持staging-first选项
- 部署失败时立即通知并提供回滚方案

## 使用场景
- PR审查通过后合并部署
- 合并+部署+验证一体化流程
- 需要金丝雀验证的部署

## 不适用场景
- 仅需创建PR不需合并（使用gstack-ship）
- 仅需部署后监控（使用gstack-canary）
- 手动部署流程

## 输出
- 部署报告
- 金丝雀验证结果
- 回滚方案（如需要）

## 依赖
- git（合并操作）
- gh/glab CLI（PR合并）
- agent-browser技能（金丝雀验证）
- 部署工具（Vercel/Netlify/Docker等）
