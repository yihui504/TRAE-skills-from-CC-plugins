---
name: gstack-guard
description: |
  当需要完整安全模式（破坏性命令警告+目录编辑限制）时使用。结合gstack-careful（警告rm -rf、DROP TABLE、force-push等）和gstack-freeze（阻止指定目录外的编辑）。适用于操作生产环境或调试线上系统时的最大安全保护。
---

# gstack-guard

## 上下文
gstack-guard是gstack-careful和gstack-freeze的组合，在单个命令中激活两种保护。

**TRAE适配说明：** 原Claude Code使用两个PreToolUse hook分别拦截Bash和Edit/Write。TRAE中改为手动检查：执行Bash前检查破坏性模式，执行Edit/Write前检查冻结边界。

## 指令

### 设置
1. 询问用户要限制编辑的目录路径
2. 解析为绝对路径，确保以 `/` 结尾
3. 保存冻结状态到 `.trae/gstack/state/freeze-dir.txt`
4. 告知用户：
   - "**Guard模式已激活。** 两种保护正在运行："
   - "1. **破坏性命令警告** — rm -rf、DROP TABLE、force-push等执行前会警告（可覆盖）"
   - "2. **编辑边界** — 文件编辑限制到 `<path>/`。此目录外的编辑被阻止。"
   - "移除编辑边界运行 `/unfreeze`。停用所有保护结束会话。"

### 双重检查
每次操作前执行两项检查：

**Bash命令检查（careful）：**
- 检查破坏性模式列表（见gstack-careful）
- 匹配时警告用户请求确认

**Edit/Write检查（freeze）：**
- 检查目标路径是否在冻结目录内
- 超出范围则拒绝操作

### 保护的破坏性模式
详见gstack-careful技能的完整列表。

### 编辑边界工作方式
详见gstack-freeze技能的工作方式说明。

## 使用场景
- 操作生产环境
- 调试线上系统
- 需要最大安全保护的场景
- 同时需要命令警告和编辑限制

## 不适用场景
- 仅需命令警告（使用gstack-careful）
- 仅需编辑限制（使用gstack-freeze）
- 开发环境常规操作

## 输出
- Guard模式激活确认
- 破坏性命令警告
- 编辑边界阻止通知

## 依赖
- gstack-careful（破坏性命令检查逻辑）
- gstack-freeze（编辑边界检查逻辑）
- `.trae/gstack/state/freeze-dir.txt`
