---
name: gstack-context-restore
description: |
  当需要恢复之前保存的工作上下文时使用。默认加载所有分支中最近的保存上下文（支持跨分支恢复），提供下一步建议。适用于"恢复上下文"、"我之前在做什么"、"where was I"场景。
---

# gstack-context-restore

## 上下文
gstack-context-restore加载由gstack-context-save保存的工作上下文，帮助用户在新的会话或上下文压缩后快速恢复工作状态。

**TRAE适配说明：** 路径 `.gstack/` 适配为 `.trae/gstack/`。

## 指令

### 恢复流程

**1. 查找保存上下文**
在 `.trae/gstack/context-saves/` 中查找所有保存文件：
- 优先查找当前分支的保存
- 如无当前分支的保存，查找所有分支中最近的
- 支持跨分支恢复

**2. 加载正确文件**
- 读取最近的保存文件
- 解析frontmatter（status、branch、timestamp、files_modified）
- 读取markdown内容

**3. 提供下一步建议**
基于保存的上下文：
- 总结之前的工作状态
- 列出待办事项
- 建议下一步行动
- 如有进行中的工作，建议继续点

### 恢复后的行动
- 检查保存后是否有新的提交（`git log --since="<save-timestamp>"`）
- 检查保存的文件是否仍存在
- 对比当前分支与保存时的分支

### 硬门
**不实现代码变更。** 只恢复上下文信息。

## 使用场景
- 新会话开始时恢复之前的工作
- 上下文压缩后恢复关键信息
- 切换回之前工作的分支
- 忘记之前在做什么时

## 不适用场景
- 需要保存上下文时（使用gstack-context-save）
- 首次使用（无保存的上下文）
- 不需要历史信息的简单任务

## 输出
- 恢复的上下文摘要
- 待办事项列表
- 下一步建议
- 保存后的变更对比

## 依赖
- git（分支检测、提交历史）
- gstack-context-save（创建保存文件）
- `.trae/gstack/context-saves/` 目录
