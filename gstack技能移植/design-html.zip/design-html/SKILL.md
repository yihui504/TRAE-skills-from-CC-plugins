---
name: design-html
description: |
  设计定稿：生成生产级HTML/CSS，文本真实重排、高度计算、布局动态。
  与design-shotgun的已批准模型、CEO计划、设计评审上下文配合，或从用户描述从零开始。
  适用于"定稿设计"、"转成HTML"、"构建页面"、"实现设计"等场景。
  在用户已批准设计或有计划就绪时主动建议使用。
---

# design-html

## 描述
生成生产级HTML，文本正确重排，高度动态计算，布局响应式。使用Pretext文本布局引擎确保精确排版。30KB开销，零依赖。

## 使用场景
- 用户说"定稿设计"、"转成HTML"、"构建页面"、"实现设计"
- 在任何规划技能完成后
- 用户已批准设计模型并需要实现
- 需要将设计方向转为可工作的HTML

## 不适用场景
- 只需要设计方向而非实现（用design-consultation）
- 需要视觉评审而非构建（用design-review）
- 后端/基础设施项目，无UI组件

## 指令

### Step 0: 输入检测

检测项目存在的设计上下文：

1. **检查已批准模型：** 查找`.trae/gstack/data/projects/`下的approved.json
2. **检查CEO计划：** 查找ceo-plans目录
3. **检查设计变体：** 查找variant-*.png
4. **检查已定稿HTML：** 查找finalized.html
5. **检查DESIGN.md：** 查找项目根目录

**路由逻辑：**
- **Case A（approved.json存在）：** 读取已批准变体、用户反馈、屏幕名。如有已定稿HTML，询问用户是演进还是重新生成
- **Case B（有计划/变体但无approved.json）：** 读取现有上下文，询问用户是运行design-shotgun、跳过模型直接设计、还是提供PNG
- **Case C（无任何上下文）：** 询问用户是先运行规划技能还是直接描述需求

### Step 1: 设计分析

1. 如有已批准PNG：分析视觉布局、色彩、排版、组件结构
2. 如在计划驱动或自由模式：从上下文设计——读取计划提取UI需求，或向用户收集目的/受众/视觉感受/内容结构
3. 读取DESIGN.md中的设计令牌——这些覆盖系统级属性（品牌色、字体族、间距比例）
4. 输出"实现规格"摘要：色彩(hex)、字体(族+权重)、间距比例、组件列表、布局类型

### Step 2: Pretext API路由

分析设计并分类为Pretext层级：

| 设计类型 | Pretext API | 用例 |
|---------|-------------|------|
| 简单布局(落地页、营销) | prepare() + layout() | 感知尺寸的高度 |
| 卡片/网格(仪表盘、列表) | prepare() + layout() | 自适应卡片 |
| 聊天/消息UI | prepareWithSegments() + walkLineRanges() | 紧凑气泡 |
| 内容密集(编辑、博客) | prepareWithSegments() + layoutNextLine() | 绕障碍文本 |
| 复杂编辑 | 完整引擎 + layoutWithLines() | 手动行渲染 |

### Step 2.5: 框架检测

检查项目是否使用前端框架（React/Svelte/Vue等），询问用户输出格式（原生HTML vs 框架组件）。

### Step 3: 生成HTML

**写入单文件**，保存到`.trae/gstack/data/projects/`下的设计目录。

**原生HTML必须包含：**
- Pretext源（内联或CDN）
- DESIGN.md/Step 1提取的设计令牌CSS自定义属性
- Google Fonts + document.fonts.ready门控
- 语义HTML5
- Pretext重排的响应式行为
- 断点：375px, 768px, 1024px, 1440px
- ARIA属性、标题层级、focus-visible状态
- contenteditable + MutationObserver重准备+重布局
- ResizeObserver重布局
- prefers-color-scheme暗色模式
- prefers-reduced-motion
- 真实内容（永不lorem ipsum）

**永不包含（AI slop黑名单）：**
- 紫色/蓝色渐变默认
- 通用3列特性网格
- 居中一切无视觉层级
- 模型中不存在的装饰性blob/wave
- "Get Started"/"Learn More"通用CTA
- 圆角卡片+投影作为默认组件
- Emoji作为视觉元素

**Pretext接线模式（基础高度计算）：**
```js
await document.fonts.ready
const elements = document.querySelectorAll('[data-pretext]')
const prepared = new Map()
for (const el of elements) {
  prepared.set(el, prepare(el.textContent, getComputedStyle(el).font))
}
function relayout() {
  for (const [el, handle] of prepared) {
    const { height } = layout(handle, el.clientWidth, parseFloat(getComputedStyle(el).lineHeight))
    el.style.height = `${height}px`
  }
}
new ResizeObserver(() => relayout()).observe(document.body)
relayout()
```

### Step 4: 预览+精炼循环

1. 在浏览器中打开HTML
2. 如有已批准模型，展示用于视觉对比
3. 询问用户需要改什么
4. 用Edit工具做针对性修改（不重新生成整个文件）
5. 最多10轮迭代

### Step 5: 保存和下一步

1. 如无DESIGN.md，提供从HTML提取设计令牌创建DESIGN.md
2. 写finalized.json元数据
3. 询问用户：复制到项目/继续迭代/完成

## 输出
- finalized.html（或框架组件文件）
- finalized.json元数据
- 可选的DESIGN.md（如不存在）

## 依赖
- Pretext文本布局引擎（@chenglou/pretext，CDN或内联）
- 文件读写工具（必需）
- 浏览器工具（可选，用于预览验证）
