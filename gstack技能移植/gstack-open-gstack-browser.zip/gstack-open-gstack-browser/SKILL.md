---
name: gstack-open-gstack-browser
description: 当需要启动GStack浏览器、打开AI控制的Chromium、启动带侧边栏扩展的浏览器、或需要实时观察浏览器操作时使用
---

## 描述

启动GStack浏览器——AI控制的Chromium，内置侧边栏扩展和反检测隐身功能。打开可见的浏览器窗口，可以实时观看每个操作。侧边栏显示实时活动流和聊天。

## 上下文

- GStack浏览器基于Playwright的Chromium，带有自定义品牌和反bot隐身补丁
- 侧边栏扩展自动加载，端口固定为34567
- 浏览器配置文件位于`.trae/gstack/data/chromium-profile`
- 首次使用需要构建browse二进制文件（约10秒）

## 指令

### 前置检查：构建browse二进制

检查browse二进制是否可用：

1. 查找项目根目录下的`.trae/gstack/browse/dist/browse`或全局路径`.trae/gstack/browse/dist/browse`
2. 如果不可用，告知用户需要一次性构建，运行`cd <SKILL_DIR> && ./setup`
3. 如果bun未安装，先安装bun（版本1.3.10，需校验SHA256）

### Step 0: 预清理

在连接之前，清理可能残留的旧browse服务器和锁文件：

1. 终止任何现有的browse服务器进程
2. 清理Chromium配置文件锁文件（SingletonLock/SingletonSocket/SingletonCookie）
3. 删除旧的`.gstack/browse.json`状态文件

### Step 1: 连接浏览器

运行`$B connect`启动GStack浏览器：

- 以headed模式启动（可见窗口，不影响用户正常Chrome）
- 自动加载gstack侧边栏扩展
- 应用反bot隐身补丁
- 自定义User-Agent和GStack Browser品牌
- 启动侧边栏代理进程
- 端口固定34567

确认输出中显示`Mode: headed`。如果出错，运行`$B status`查看详情。

### Step 2: 验证连接

1. 运行`$B status`确认模式为headed
2. 从状态文件读取端口（应为34567）
3. 查找扩展路径以备手动加载需要

### Step 3: 引导用户使用侧边栏

使用AskUserQuestion询问用户侧边栏状态：

- A) 可以看到侧边栏——继续
- B) 可以看到Chrome但找不到扩展——引导手动加载扩展
- C) 出了问题——排查并重试

如果选B，引导用户通过`chrome://extensions`手动加载扩展。
如果选C，运行`$B status`检查服务器健康状态，必要时重试清理+连接。

### Step 4: 演示

1. 运行`$B goto https://news.ycombinator.com`
2. 等待2秒后运行`$B snapshot -i`
3. 告知用户检查侧边栏的活动流

### Step 5: 介绍侧边栏聊天

告知用户侧边栏有聊天标签页，可以输入自然语言指令，侧边栏代理会执行请求。

### Step 6: 后续操作

告知用户已就绪，可用的浏览器操作：
- 实时观看技能执行
- 侧边栏聊天控制浏览器
- Browse命令：`$B goto`/`$B click`/`$B fill`/`$B snapshot`
- 窗口管理：`$B focus`/`$B disconnect`

## 使用场景

- 需要实时观察AI在浏览器中的操作
- 需要使用带侧边栏扩展的浏览器进行交互
- 需要反bot隐身功能的浏览器会话
- 想通过侧边栏聊天控制浏览器

## 不适用场景

- 只需要无头浏览器操作（不需要可见窗口）
- 不需要gstack侧边栏扩展的简单浏览任务
- 在无GUI的服务器环境中运行

## 输出

- 可见的GStack浏览器窗口
- 侧边栏扩展加载并连接到端口34567
- 确认`Mode: headed`的状态输出

## 依赖

- gstack browse二进制文件（需先构建）
- bun运行时（版本1.3.10+）
- Playwright Chromium
- TRAE适配：`$B`/`$D`变量对应TRAE的agent-browser技能或浏览器MCP

## TRAE适配说明

- 路径适配：`~/.claude/skills/gstack/` → `.trae/gstack/`，`~/.gstack/` → `.trae/gstack/data/`
- 工具适配：`$B` browse守护进程 → TRAE的agent-browser技能或浏览器MCP
- AskUserQuestion → TRAE的AskUserQuestion工具
- Preamble脚本（更新检查、会话管理、遥测等）→ 转化为文字指令：运行前检查gstack更新、初始化会话目录、读取配置
- CLAUDE.md中的Skill routing → `.trae/rules/`中的规则文件
