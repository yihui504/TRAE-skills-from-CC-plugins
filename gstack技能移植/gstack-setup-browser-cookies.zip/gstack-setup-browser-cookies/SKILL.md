---
name: gstack-setup-browser-cookies
description: 当需要从真实Chromium浏览器导入cookies到headless浏览会话、解决headless浏览器的登录/认证问题时使用
---

## 描述

从用户真实的Chromium浏览器导入cookies到gstack的headless浏览会话，使headless浏览器可以访问需要登录的网站。

## 上下文

- gstack browse守护进程运行在CDP模式下
- cookie-import-browser命令提供图形化cookie选择界面
- 如果CDP模式不可用，可直接从Chromium cookie数据库导入
- cookie数据存储在`.trae/gstack/data/chromium-profile`中

## 指令

### Step 1: 检查CDP模式

1. 运行`$B status`检查browse守护进程状态
2. 确认是否运行在CDP模式下（支持cookie picker UI）
3. 如果不在CDP模式，使用替代方案

### Step 2: 查找browse二进制

查找browse二进制路径（项目本地或全局安装路径）。

### Step 3: 打开Cookie Picker UI

**CDP模式可用时：**

运行cookie-import-browser命令，打开图形化cookie选择界面：

1. 用户选择要导入cookies的域名
2. 确认导入
3. 验证导入成功

**CDP模式不可用时（替代方案）：**

直接从Chromium cookie数据库导入：

1. 定位Chromium cookie数据库文件
2. 使用sqlite3读取cookie数据
3. 将cookie写入headless浏览器的配置文件
4. 验证导入成功

### Step 4: 验证

1. 使用`$B goto`访问需要登录的网站
2. 运行`$B snapshot -i`检查页面内容
3. 确认登录状态生效

## 使用场景

- headless浏览器需要访问需要登录的网站
- 浏览器自动化测试需要认证状态
- 需要将真实浏览器的会话复制到自动化环境

## 不适用场景

- 目标网站不需要登录
- 已有其他方式获取认证（如API token）
- 不应导入敏感网站的cookies（安全考虑）

## 输出

- cookies成功导入确认
- headless浏览器可以访问需要登录的页面

## 依赖

- gstack browse守护进程（CDP模式）
- cookie-import-browser命令
- Chromium浏览器（作为cookie源）
- TRAE适配：`$B` → TRAE的agent-browser技能或浏览器MCP

## TRAE适配说明

- 路径适配：`~/.gstack/` → `.trae/gstack/data/`，`~/.claude/skills/gstack/` → `.trae/gstack/`
- 工具适配：`$B`/`$D` → TRAE的agent-browser技能或浏览器MCP
- Preamble脚本 → 文字指令
