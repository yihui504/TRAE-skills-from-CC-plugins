---
name: plan-tune
description: |
  问题敏感度调优 + 开发者心理画像（v1: 观察性）。
  审查gstack技能中哪些AskUserQuestion提示触发，设置每问题偏好（never-ask / always-ask / ask-only-for-one-way），
  检查双轨画像（你声明的 vs 你的行为暗示的），启用/禁用问题调优。对话式界面。
  当用户要求"tune questions"、"stop asking me that"、"too many questions"、"show my profile"时使用。
---

# plan-tune

## 描述

开发者教练检查画像 — 不是CLI。用户用自然语言调用，你解释意图。v1范围（观察性）：类型化问题注册表、每问题显式偏好、问题日志、双轨画像（声明+推断）、自然语言检查。

## 使用场景

- 用户说"tune questions"、"stop asking me that"、"too many questions"
- 用户说"show my profile"、"what questions have I been asked"、"show my vibe"
- 用户说"developer profile"、"turn off question tuning"
- 用户反复以相同方式回答同一gstack问题时

## 不适用场景

- 不是问题调优相关的请求
- 用户没有使用过gstack技能（无问题日志可审查）

## 指令

### Step 0: 检测用户意图

读取用户消息，基于自然语言意图路由：

1. **首次使用**（配置中question_tuning未设为true）→ 运行"启用+设置"
2. **"Show my profile" / "show my vibe"** → 运行"检查画像"
3. **"Review questions" / "what have I been asked"** → 运行"审查问题日志"
4. **"Stop asking me about X" / "tune: ..."** → 运行"设置偏好"
5. **"Update my profile"** → 运行"编辑声明画像"
6. **"Show the gap"** → 运行"显示差距"
7. **"Turn it off" / "disable"** → 禁用问题调优
8. **"Turn it on" / "enable"** → 启用问题调优
9. **不明确** → 直接问用户想要什么

快捷词：`profile`, `vibe`, `gap`, `stats`, `review`, `enable`, `disable`, `setup`

### 启用+设置（首次流程）

1. 检查当前question_tuning状态
2. 如果为false，向用户提问是否启用
3. 如果启用+完整设置，逐一问5个维度声明问题：
   - **Q1 — scope_appetite:** "规划功能时，你倾向于快速交付最小可用版本，还是构建完整、覆盖边界情况的版本？"
     选项：A) 小范围快速迭代(≈0.25) / B) 平衡 / C) 煮沸湖泊(≈0.85)
   - **Q2 — risk_tolerance:** "你宁愿快速行动稍后修复Bug，还是行动前仔细检查？"
     选项：A) 仔细检查(≈0.25) / B) 平衡 / C) 快速行动(≈0.85)
   - **Q3 — detail_preference:** "你想要简洁的'直接做'回答，还是带权衡和推理的详细解释？"
     选项：A) 简洁(≈0.25) / B) 平衡 / C) 详细带推理(≈0.85)
   - **Q4 — autonomy:** "你想被咨询每个重要决策，还是委托代理替你选择？"
     选项：A) 咨询我(≈0.25) / B) 平衡 / C) 委托代理(≈0.85)
   - **Q5 — architecture_care:** "当'现在交付'和'设计正确'之间有权衡时，你通常站在哪边？"
     选项：A) 现在交付(≈0.25) / B) 平衡 / C) 设计正确(≈0.85)
4. 将声明维度写入 `.trae/gstack/data/developer-profile.json`
5. 确认设置完成，显示画像摘要

### 检查画像

读取 `.trae/gstack/data/developer-profile.json`，以自然语言呈现：

- 对每个有声明值的维度，翻译为自然语言描述：
  - 0.0-0.3 → "低"（如scope_appetite低 = "小范围，快速交付"）
  - 0.3-0.7 → "平衡"
  - 0.7-1.0 → "高"（如scope_appetite高 = "煮沸湖泊"）

- 如有推断数据且通过校准门（样本量≥20 AND 覆盖技能≥3 AND 覆盖问题≥8 AND 跨度天数≥7），显示推断列：
  - 差距0.0-0.1 "接近"
  - 差距0.1-0.3 "漂移"
  - 差距0.3+ "不匹配"

- 显示氛围（原型）标签+一行描述

### 审查问题日志

读取 `.trae/gstack/data/projects/{slug}/question-log.jsonl`（如存在）。

以自然语言呈现，包含计数和遵循率。突出用户频繁覆盖的问题 — 这些是设置never-ask偏好的候选。

呈现后提供："想对其中任何一个设置偏好吗？说哪个问题和你想怎么处理。"

### 设置偏好

1. 从用户的话中识别question_id。如不明确，列出最近5个问题让用户选择。
2. 将意图规范化为：
   - `never-ask` — "别再问了"、"不必要"、"少问"
   - `always-ask` — "每次都问"、"我想决定"
   - `ask-only-for-one-way` — "只在破坏性操作时问"
3. 如用户措辞清晰，直接写入。如不明确，先确认。
4. 写入偏好到 `.trae/gstack/data/` 对应配置文件
5. 确认："已设置 `{id}` → `{preference}`。立即生效。单向门仍会覆盖never-ask以确保安全。"

### 编辑声明画像

用户想更新自我声明。始终确认后再写入。

1. 解析用户意图，翻译为(维度, 新值)
2. 确认："确认 — 将 `declared.{dimension}` 从 `{old}` 更新为 `{new}`？"
3. 确认后写入 `.trae/gstack/data/developer-profile.json`
4. 确认更新完成

### 显示差距

读取画像差距数据。对每个同时有声明和推断的维度：
- 差距 < 0.1 → "接近 — 你的行动匹配你说的"
- 差距 0.1-0.3 → "漂移 — 有些不匹配，不剧烈"
- 差距 > 0.3 → "不匹配 — 你的行为与自我描述不一致"

绝不基于差距自动更新声明。v1中差距仅报告 — 用户决定声明是否错误。

### 统计

呈现紧凑摘要：
- 总记录问题数
- 覆盖技能数、问题数、跨度天数
- 校准状态（"还需N个事件跨M个技能才能校准"或"已校准"）

### 重要规则

- **全程自然语言** — 永远不要求用户知道 `profile set autonomy 0.4`。技能解释自然语言。
- **变更前确认** — 代理解释的自由形式编辑是信任边界。始终显示预期变更并等待确认。
- **单向门覆盖never-ask** — 即使有never-ask偏好，破坏性/架构/安全问题仍会提问。
- **v1不做行为适配** — 此技能只检查和配置。没有技能当前读取画像来改变默认值。
- **完成状态：** DONE / DONE_WITH_CONCERNS / NEEDS_CONTEXT

## 输出

- 开发者画像（声明+推断维度）
- 问题偏好设置
- 问题日志审查
- 画像差距分析
- 统计摘要

## 依赖

- `.trae/gstack/data/developer-profile.json`（开发者画像数据）
- `.trae/gstack/data/projects/{slug}/question-log.jsonl`（问题日志）
- 如可用，gstack CLI工具（用于问题偏好、画像管理等）
