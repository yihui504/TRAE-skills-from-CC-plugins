---
name: gstack-ship
description: |
  当需要发布代码、创建PR、部署到主分支时使用。自动化发布工作流：检测平台→合并基线分支→运行测试→审查diff→版本号递增→更新CHANGELOG→提交→推送→创建PR。适用于"ship"、"deploy"、"push to main"、"create a PR"等场景。
---

# gstack-ship

## 上下文
gstack-ship是全自动发布工作流。用户说 `/ship` 意味着执行，不需要逐步确认。仅在特定硬停止点暂停（合并冲突、测试失败、版本号大升级需确认等）。

**TRAE适配说明：** 路径 `.gstack/` 适配为 `.trae/gstack/`。原CLI工具（gstack-review-read、gstack-diff-scope等）需gstack CLI支持。AskUserQuestion适配为直接向用户提问。

## 指令

### Step 0: 平台检测
检测git托管平台（GitHub/GitLab/unknown）和基线分支。

### Step 1: 预检
1. 检查当前分支（如在基线分支则中止）
2. 运行 `git status`（未提交更改始终包含）
3. 运行 `git diff <base>...HEAD --stat` 了解发布内容
4. 显示审查就绪仪表盘

### Step 2: 分发管道检查
如diff引入新的独立构件（CLI二进制、库包），验证是否有发布CI/CD管道。

### Step 3: 合并基线分支
```bash
git fetch origin <base> && git merge origin/<base> --no-edit
```
简单冲突自动解决，复杂冲突停止并展示。

### Step 4: 测试框架引导
检测并引导测试框架（如项目无测试基础设施）。

### Step 5: 运行测试
执行项目测试套件。

### Step 6: 测试覆盖率审计
检查测试覆盖率是否满足最低阈值。

### Step 7: 计划完成审计
检查计划项是否全部完成。

### Step 8: 预落地审查
运行diff范围的代码审查（架构、代码质量、测试、性能）。

### Step 9: 对抗性审查
使用不同视角挑战代码变更。

### Step 10: VERSION递增
根据变更类型递增版本号（MICRO/PATCH自动，MINOR/MAJOR需确认）。

### Step 11: CHANGELOG更新
从diff自动生成CHANGELOG条目。

### Step 12: 提交
自动提交，大变更集拆分为可二分查找的原子提交。

### Step 13: 推送
```bash
git push origin <current-branch>
```

### Step 14: 创建PR
使用平台CLI创建PR，PR body包含：变更摘要、测试结果、审查状态、版本变更。

### Step 15: TODOS.md更新
标记已完成的TODO项。

### Step 16: 文档发布
如需要，更新文档。

### 仅在以下情况停止
- 在基线分支上（中止）
- 无法自动解决的合并冲突
- 分支内测试失败
- 审查发现需用户判断的问题
- MINOR或MAJOR版本递增需确认
- AI评估覆盖率低于最低阈值

### 永不停止于
- 未提交更改（始终包含）
- 版本递增选择（自动选择MICRO/PATCH）
- CHANGELOG内容（自动生成）
- 提交消息审批（自动提交）

## 使用场景
- 功能分支开发完成，准备发布
- 代码已就绪，需要创建PR
- 需要自动化发布流程
- 部署前的全面检查

## 不适用场景
- 仅需代码审查不需发布（使用gstack-review）
- 仅需测试不需发布（使用gstack-qa）
- 合并+部署+验证一体化流程（使用gstack-land-and-deploy）

## 输出
- PR URL
- 版本号变更
- CHANGELOG更新
- 审查结果摘要
- 测试结果

## 依赖
- git（分支管理、提交、推送）
- gh/glab CLI（PR创建）
- 项目测试框架
- gstack CLI（可选，用于审查日志和diff范围分析）
