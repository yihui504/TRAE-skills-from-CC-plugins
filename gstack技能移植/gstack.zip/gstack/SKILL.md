---
name: gstack
description: |
  当需要gstack技能路由和全局配置管理时使用。gstack根级技能负责初始化会话环境、检测项目状态、管理技能路由规则，并在用户请求匹配时自动调度对应的子技能。
---

# gstack

## 上下文
gstack是一个AI辅助开发工具集，包含QA测试、代码审查、部署、调试、安全防护等多个技能。本技能是根级入口，负责：
- 检测当前分支和项目状态
- 读取gstack配置（proactive模式、explain_level、checkpoint_mode等）
- 管理技能路由规则（将用户请求匹配到对应技能）
- 处理首次使用的引导流程（遥测、proactive提示、路由注入等）
- 加载项目学习记录（learnings）

**路径适配说明：** 原Claude Code路径 `~/.claude/skills/gstack/` 在TRAE中对应 `.trae/gstack/`。原CLI工具（gstack-config、gstack-slug等）需用户自行安装gstack CLI或手动创建对应配置文件。

## 指令

### 1. 会话初始化
- 检测当前git分支：`git branch --show-current`
- 读取gstack配置（如 `.trae/gstack/config.json` 或环境变量）
- 确定以下状态：
  - PROACTIVE：是否主动建议技能（默认true）
  - EXPLAIN_LEVEL：解释详细程度（default/terse）
  - CHECKPOINT_MODE：提交模式（explicit/continuous）
  - REPO_MODE：仓库模式（solo/collaborative/unknown）

### 2. 技能路由
当用户请求匹配以下模式时，通过Skill工具调用对应技能：
- Bug/错误/调试 → gstack-investigate
- QA/测试网站 → gstack-qa 或 gstack-qa-only
- 代码审查/diff检查 → gstack-review
- 发布/部署/PR → gstack-ship 或 gstack-land-and-deploy
- 部署后监控 → gstack-canary
- 安全模式 → gstack-careful 或 gstack-guard
- 限制编辑范围 → gstack-freeze / gstack-unfreeze
- 保存进度 → gstack-context-save
- 恢复上下文 → gstack-context-restore
- 代码质量仪表盘 → gstack-health
- 性能回归检测 → gstack-benchmark
- 浏览器测试 → gstack-browse

**路由原则：** 有疑问时调用技能。误触（调用了不需要的技能）比漏调（直接回答而非使用结构化工作流）代价更低。

### 3. 完成状态协议
完成技能工作流时，使用以下状态之一报告：
- **DONE** — 有证据地完成
- **DONE_WITH_CONCERNS** — 完成，但列出关注点
- **BLOCKED** — 无法继续；说明阻碍和已尝试的方法
- **NEEDS_CONTEXT** — 缺少信息；明确说明需要什么

### 4. 自我改进
完成前，如果发现了可节省5+分钟的项目特性或命令修复，记录到学习文件 `.trae/gstack/projects/{slug}/learnings.jsonl`。

## 使用场景
- 启动新会话时需要初始化gstack环境
- 用户请求需要路由到特定技能
- 需要管理gstack全局配置
- 首次使用需要引导设置

## 不适用场景
- 已明确知道要使用哪个子技能时（直接调用子技能）
- 纯代码编写任务（无需gstack路由）
- 不需要任何gstack功能的简单问答

## 输出
- 会话状态信息（分支、配置、学习记录数量）
- 技能路由建议
- 首次使用引导结果
- 完成状态报告

## 依赖
- git（分支检测）
- gstack CLI工具（可选，用于配置管理和学习记录；若无则手动管理配置文件）
- `.trae/gstack/` 目录结构
