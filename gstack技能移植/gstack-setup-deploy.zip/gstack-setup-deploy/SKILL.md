---
name: gstack-setup-deploy
description: 当需要配置部署设置、检测部署平台、为land-and-deploy技能准备部署配置时使用
---

## 描述

配置部署设置供/land-and-deploy使用。自动检测部署平台（Fly.io/Render/Vercel/Netlify/Heroku/GitHub Actions/自定义），并生成相应的配置。

## 上下文

- 部署配置持久化到`.trae/rules/`中的Deploy Configuration节（原CLAUDE.md）
- 支持多种部署平台的自动检测
- 配置一旦写入，后续/ship和/land-and-deploy自动使用

## 指令

### Step 1: 检查现有配置

1. 读取项目规则文件，查找`## Deploy Configuration`节
2. 如果已存在配置，询问用户是否要更新
3. 如果不存在，继续检测

### Step 2: 检测部署平台

按优先级检测以下平台：

1. **Fly.io** — 检查`fly.toml`文件
2. **Render** — 检查`render.yaml`文件
3. **Vercel** — 检查`vercel.json`文件或`api/`目录
4. **Netlify** — 检查`netlify.toml`文件
5. **Heroku** — 检查`Procfile`或`app.json`
6. **GitHub Actions** — 检查`.github/workflows/`中的部署工作流
7. **自定义** — 以上都不匹配时

### Step 3: 平台特定设置

根据检测到的平台，收集必要的配置信息：

- **Fly.io**: app名称、区域、内存
- **Render**: 服务类型、环境变量
- **Vercel**: 框架预设、构建命令
- **Netlify**: 构建命令、发布目录
- **Heroku**: buildpack、addon
- **GitHub Actions**: 工作流名称、环境
- **自定义**: 部署命令、环境

### Step 4: 写入配置

将配置写入项目规则文件的`## Deploy Configuration`节，格式：

```
## Deploy Configuration
- Platform: <platform>
- <platform-specific-settings>
```

### Step 5: 验证

1. 重新读取规则文件确认配置已写入
2. 如果平台CLI可用，运行验证命令

### Step 6: 摘要

输出配置摘要，告知用户部署设置已就绪。

## 使用场景

- 首次为项目设置部署配置
- 切换部署平台
- 更新现有部署配置
- 在/ship之前确保部署配置正确

## 不适用场景

- 项目不需要部署（纯库/工具项目）
- 部署配置已在CI/CD系统中管理
- 已有完善的部署流程

## 输出

- 部署配置写入项目规则文件
- 配置摘要和验证结果

## 依赖

- 项目规则文件（`.trae/rules/`）
- 各平台CLI工具（可选，用于验证）
- git（用于检测项目信息）

## TRAE适配说明

- 路径适配：CLAUDE.md → `.trae/rules/`中的规则文件
- `~/.claude/skills/gstack/` → `.trae/gstack/`
- `~/.gstack/` → `.trae/gstack/data/`
- Preamble脚本 → 文字指令
- 配置持久化位置从CLAUDE.md改为`.trae/rules/`
