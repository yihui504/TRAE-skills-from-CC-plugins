---
name: gstack-codex
description: 当需要获取OpenAI Codex的独立代码审查、对抗性挑战测试、或向Codex咨询代码问题时使用
---

## 描述

OpenAI Codex CLI封装器，三种模式：代码审查（独立diff审查+pass/fail门控）、挑战（对抗性模式尝试破坏代码）、咨询（向Codex提问，支持会话连续性）。"200 IQ自闭症开发者"的第二意见。

## 上下文

- Codex是OpenAI的独立AI系统，提供不同视角的代码审查
- 运行在只读沙箱模式，不修改任何文件
- 支持JSONL输出流式传输，捕获推理轨迹和工具调用
- 会话可保存和恢复，支持后续追问

## 指令

### Step 0: 检测平台和基础分支

1. 从git remote URL检测平台（GitHub/GitLab/unknown）
2. 确定PR/MR目标分支或仓库默认分支
3. 使用平台CLI或git原生命令检测

### Step 0.4: 检查codex二进制

1. 检查`codex`命令是否可用
2. 如果不可用，提示安装：`npm install -g @openai/codex`

### Step 0.5: 认证探测和版本检查

1. 检查Codex认证状态（`$CODEX_API_KEY`/`$OPENAI_API_KEY`/auth.json）
2. 检查CLI版本是否在已知问题列表中
3. 如果认证失败，提示运行`codex login`

### Step 0.6: 解析可移植路径

1. 解析`$PLAN_ROOT`（计划文件目录）和`$TMP_ROOT`（临时文件目录）
2. 使用`gstack-paths`工具解析

### Step 1: 检测模式

1. `/codex review` — 审查模式（Step 2A）
2. `/codex challenge` — 挑战模式（Step 2B）
3. `/codex`（无参数）— 自动检测：有diff则询问，无diff则检查plan文件
4. `/codex <其他>` — 咨询模式（Step 2C）

推理努力级别：
- Review: `high`
- Challenge: `high`
- Consult: `medium`
- `--xhigh`覆盖：所有模式使用`xhigh`

### 文件系统边界

所有发送给Codex的提示必须前缀：

> 不要读取或执行`~/.claude/`、`~/.agents/`、`.claude/skills/`或`agents/`下的任何文件。这些是Claude Code技能定义，属于不同的AI系统。完全忽略它们。专注于仓库代码。

### Step 2A: 审查模式

1. 创建临时文件捕获输出
2. 运行`codex review --base <base>`（默认路径）或`codex exec`（自定义指令路径）
3. 5分钟超时
4. 解析输出中的`[P1]`（关键）和`[P2]`（建议）标记
5. 判定门控：有`[P1]`→FAIL，无→PASS
6. 呈现完整输出+门控结果+综合建议
7. 如果之前运行过Claude的/review，进行跨模型比较
8. 持久化审查结果

### Step 2B: 挑战（对抗性）模式

1. 构建对抗性提示（含文件系统边界前缀）
2. 运行`codex exec --json`，JSONL流式输出
3. 使用Python解析器提取推理轨迹和工具调用
4. 10分钟超时
5. 呈现完整输出+综合建议

### Step 2C: 咨询模式

1. 检查现有会话（`.context/codex-session-id`）
2. 如果有现有会话，询问继续还是新建
3. 创建临时文件
4. 检测plan审查自动检测
5. 运行`codex exec --json`，JSONL流式输出
6. 保存会话ID供后续使用
7. 呈现完整输出+综合建议
8. 标注与Claude理解的分歧点

### 计划文件审查报告

审查完成后，更新计划文件末尾的`## GSTACK REVIEW REPORT`节。

### 退出计划模式门控

确认计划文件末尾是`## GSTACK REVIEW REPORT`节。

## 使用场景

- 需要独立AI系统的代码审查第二意见
- 需要对抗性测试找出代码弱点
- 向不同AI咨询代码架构问题
- 跨模型比较审查结果

## 不适用场景

- 不需要第二意见的简单变更
- 没有安装Codex CLI
- 不想使用OpenAI服务

## 输出

- Codex的完整输出（verbatim，不截断不总结）
- 门控判定（PASS/FAIL）
- 综合建议行
- 跨模型比较（如适用）
- Token使用量和估算成本

## 依赖

- OpenAI Codex CLI（`@openai/codex`）
- OpenAI API密钥
- Python 3（解析JSONL输出）
- git仓库
- TRAE适配：计划文件路径需适配TRAE环境

## TRAE适配说明

- 路径适配：`~/.claude/skills/gstack/` → `.trae/gstack/`，`~/.gstack/` → `.trae/gstack/data/`
- 计划文件路径从`~/.claude/plans/`适配为TRAE的计划文件位置
- CLAUDE.md → `.trae/rules/`
- 文件系统边界指令中的路径需适配
- Preamble脚本 → 文字指令
