---
name: gstack-benchmark-models
description: |
  当需要跨AI模型基准测试时使用。与gstack-benchmark不同，本技能测试AI模型性能而非网页性能。6步工作流：定位二进制→选择提示→选择提供商→决定judge→运行基准→解读结果→保存。支持Claude、GPT(via Codex CLI)、Gemini。适用于"模型基准测试"、"AI性能对比"场景。
---

# gstack-benchmark-models

## 上下文
gstack-benchmark-models是跨模型基准测试技能，用于比较不同AI模型在特定任务上的表现。

**TRAE适配说明：** 原Claude Code依赖gstack-model-benchmark二进制。TRAE中可使用ask技能路由到不同AI模型进行对比测试。路径 `.gstack/` 适配为 `.trae/gstack/`。

## 指令

### 6步工作流

**Step 1: 定位二进制/工具**
- 检查gstack-model-benchmark是否可用
- 如不可用，使用ask技能作为替代方案路由到不同AI模型

**Step 2: 选择提示**
- 使用内置提示集或自定义提示
- 提示应覆盖：代码生成、调试、解释、重构等场景
- 确保提示对每个模型公平一致

**Step 3: 选择提供商**
- Claude（通过当前会话）
- GPT（通过ask技能路由到OpenAI模型）
- Gemini（通过ask技能路由到Google模型）
- 用户可指定要测试的模型组合

**Step 4: 决定judge**
- 选择评判模型（通常使用与被测模型不同的模型）
- 评判标准：正确性、代码质量、响应时间、遵循指令程度
- 也可由用户手动评判

**Step 5: 运行基准**
对每个模型：
1. 发送相同的提示
2. 收集响应
3. 记录响应时间
4. 由judge评估响应质量
5. 评分（1-10分）

**Step 6: 解读结果+保存**
产出对比报告：
```
MODEL BENCHMARK RESULTS
═══════════════════════
Prompt: "Implement a binary search tree with insert and search"
Date: 2026-05-16

Results:
─────────────────────────────────────────────────────
  Model       Correctness  Quality  Speed    Overall
  Claude      9/10         8/10     2.3s     8.5
  GPT-4       8/10         7/10     3.1s     7.5
  Gemini      7/10         7/10     1.8s     7.0
```

保存到 `.trae/gstack/benchmark-reports/{date}-model-benchmark.md`

### 评判维度
- **正确性：** 代码是否正确实现功能
- **代码质量：** 可读性、命名、结构
- **响应速度：** 生成时间
- **遵循指令：** 是否完全满足提示要求
- **边界处理：** 是否处理了边界情况

## 使用场景
- 比较不同AI模型的编码能力
- 为项目选择最佳AI模型
- 评估模型升级的效果
- 特定任务类型的模型对比

## 不适用场景
- 网页性能测试（使用gstack-benchmark）
- 单一模型使用（无需对比）
- 非AI性能相关的测试

## 输出
- 模型对比报告
- 评分矩阵
- 响应样本
- `.trae/gstack/benchmark-reports/{date}-model-benchmark.md`

## 依赖
- ask技能（路由到不同AI模型）
- 或gstack-model-benchmark二进制（可选）
