---
name: gstack-health
description: |
  当需要代码质量仪表盘时使用。6维度加权评分：Type check(22%)、Lint(18%)、Tests(28%)、Dead code(13%)、Shell lint(9%)、GBrain(10%)。不修复问题，只产出仪表盘和建议。适用于"健康检查"、"代码质量报告"场景。
---

# gstack-health

## 上下文
gstack-health是代码质量仪表盘技能。运行各种检查工具，计算加权评分，展示可视化仪表盘，持久化历史数据用于趋势分析。

**TRAE适配说明：** 路径 `.gstack/` 适配为 `.trae/gstack/`。原gstack CLI工具（gstack-config等）需自行安装。

## 指令

### 6步工作流

**Step 1: 检测健康栈**
自动检测项目中可用的检查工具：
- TypeScript: `tsc --noEmit`
- ESLint: `eslint .`
- 测试框架: jest/vitest/pytest等
- 死代码检测: ts-prune/find-unused等
- Shell检查: shellcheck
- GBrain: 语义搜索索引

**Step 2: 运行工具**
对每个检测到的工具运行检查，收集结果。

**Step 3: 评分**
按6维度加权计算评分：

| 维度 | 权重 | 评分方法 |
|------|------|----------|
| Type check | 22% | 0错误=100, 1-5=70, 5-20=40, 20+=10 |
| Lint | 18% | 0问题=100, 1-10=70, 10-50=40, 50+=10 |
| Tests | 28% | 通过率×100 |
| Dead code | 13% | 0未使用=100, 1-5=70, 5-20=40, 20+=10 |
| Shell lint | 9% | 0问题=100, 1-5=70, 5+=40 |
| GBrain | 10% | 索引完整性评分 |

最终评分 = Σ(维度评分 × 权重)

**Step 4: 展示仪表盘**
```
╔══════════════════════════════════════╗
║       CODE HEALTH DASHBOARD          ║
╠══════════════════════════════════════╣
║ Type check  ████████████░░  85/100  ║
║ Lint        ██████████░░░░  72/100  ║
║ Tests       ████████████████ 100/100 ║
║ Dead code   ██████████████░  90/100  ║
║ Shell lint  ████████████████ 100/100 ║
║ GBrain      ████████░░░░░░░  55/100  ║
╠══════════════════════════════════════╣
║ OVERALL     ████████████░░  84/100  ║
╚══════════════════════════════════════╝
```

**Step 5: 持久化历史**
保存评分到 `.trae/gstack/health-history.jsonl`：
```json
{"date":"2026-05-16","overall":84,"type_check":85,"lint":72,"tests":100,"dead_code":90,"shell_lint":100,"gbrain":55}
```

**Step 6: 趋势分析+建议**
- 对比历史评分，显示趋势（↑↓→）
- 针对低分维度给出改进建议
- 列出Top 3改进项

### 硬门
**不修复问题，只产出仪表盘和建议。**

## 使用场景
- 定期代码质量检查
- CI/CD中的质量门
- 技术债务可视化
- 团队代码质量趋势追踪

## 不适用场景
- 需要自动修复问题时（使用gstack-qa或gstack-investigate）
- 不需要评分的快速lint（直接运行lint工具）
- 非代码项目

## 输出
- 代码健康仪表盘
- 6维度评分
- 历史趋势
- 改进建议
- `.trae/gstack/health-history.jsonl`

## 依赖
- TypeScript/tsc（类型检查，如项目使用TS）
- ESLint/其他linter（代码检查）
- 测试框架（测试评分）
- shellcheck（Shell检查，可选）
