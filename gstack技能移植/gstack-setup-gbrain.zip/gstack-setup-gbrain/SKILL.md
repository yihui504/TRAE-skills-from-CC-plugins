---
name: gstack-setup-gbrain
description: 当需要设置gbrain知识库、安装gbrain CLI、初始化本地或云端brain、配置代码索引和语义搜索时使用
---

## 描述

设置gbrain知识库系统。安装CLI、初始化brain引擎（本地PGLite或Supabase云端或Remote MCP）、注册MCP服务器、配置信任策略和artifacts同步。这是最复杂的辅助类技能，包含10个步骤。

## 上下文

- gbrain是gstack的代码索引和语义搜索系统
- 支持三种模式：PGLite本地、Supabase云端、Remote MCP
- 配置持久化到`.trae/rules/`和`.trae/gstack/data/`
- 支持`--repo`/`--switch`/`--resume-provision`/`--cleanup-orphans`快捷模式

## 指令

### Step 1: 检测当前状态

1. 检查gbrain CLI是否已安装：`which gbrain`
2. 检查gbrain配置文件：`.trae/gstack/data/gbrain/config.json`
3. 检查MCP服务器注册状态
4. 运行`gbrain doctor --fast --json`获取健康状态

### Step 2: 修复损坏的引擎

如果doctor检测到损坏：

1. 尝试`gbrain repair`
2. 如果修复失败，备份并删除损坏的数据
3. 重新初始化

### Step 3: 选择路径

使用AskUserQuestion让用户选择brain模式：

**A) Supabase云端（现有项目）** — 已有Supabase项目，直接连接
**B) Supabase云端（自动创建）** — 自动创建新的Supabase项目
**C) Supabase云端（手动创建）** — 手动创建后提供凭据
**D) PGLite本地** — 纯本地，无需外部服务
**E) Remote MCP** — 连接远程brain服务器

### Step 4: 安装CLI

如果gbrain CLI未安装：

1. 运行gstack安装脚本
2. 验证安装：`gbrain --version`

### Step 5: 初始化brain

根据选择的路径初始化：

- **Supabase**: 配置连接字符串，运行`gbrain init --supabase`
- **PGLite**: 运行`gbrain init --local`
- **Remote MCP**: 配置MCP服务器URL

### Step 6: 验证doctor

运行`gbrain doctor`确认所有组件健康。

### Step 7: 注册MCP

将gbrain MCP服务器注册到TRAE配置中。

### Step 8: 配置repo策略

1. 检测当前git仓库
2. 配置信任策略（自动索引/手动确认）
3. 写入`.gbrain-source`文件

### Step 9: 配置artifacts同步

1. 询问同步模式（full/artifacts-only/off）
2. 如果启用同步，配置私有git仓库
3. 运行`gstack-artifacts-init`初始化

### Step 10: 持久化配置

将所有配置写入`.trae/rules/`和`.trae/gstack/data/`。

### Step 11: 冒烟测试

1. 运行`gbrain search "test query"`
2. 确认返回结果
3. 判定状态：GREEN（全部正常）/ YELLOW（部分功能受限）/ RED（需要修复）

## 使用场景

- 首次设置gbrain知识库
- 切换brain引擎模式
- 修复损坏的gbrain安装
- 配置跨机器artifacts同步

## 不适用场景

- 项目不需要语义搜索功能
- 已有其他代码索引方案
- 不需要跨机器同步

## 输出

- gbrain CLI安装并配置完成
- brain引擎初始化成功
- MCP服务器注册到TRAE
- 配置持久化到规则文件和数据目录
- 状态判定：GREEN/YELLOW/RED

## 依赖

- gbrain CLI
- Supabase账户（云端模式）
- Node.js/bun运行时
- git仓库
- TRAE适配：MCP注册方式需适配TRAE环境

## TRAE适配说明

- 路径适配：`~/.claude/skills/gstack/` → `.trae/gstack/`，`~/.gstack/` → `.trae/gstack/data/`
- CLAUDE.md → `.trae/rules/`中的规则文件
- MCP注册从`.claude.json`适配为TRAE的MCP配置方式
- Preamble脚本 → 文字指令
- gbrain配置路径从`~/.gbrain/`适配为`.trae/gstack/data/gbrain/`
