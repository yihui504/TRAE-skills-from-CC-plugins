---
name: gstack-unfreeze
description: |
  当需要清除由gstack-freeze设置的编辑限制、恢复所有目录的编辑权限时使用。适用于想要扩大编辑范围而不结束会话的场景。
---

# gstack-unfreeze

## 上下文
gstack-unfreeze移除由 `/freeze` 设置的编辑限制，恢复对所有目录的编辑权限。

**TRAE适配说明：** 路径适配为 `.trae/gstack/state/freeze-dir.txt`。

## 指令

### 清除边界
1. 读取 `.trae/gstack/state/freeze-dir.txt`
2. 如文件存在：删除文件，告知用户"冻结边界已清除（原为：`<path>`）。编辑现在允许在任何位置。"
3. 如文件不存在：告知用户"未设置冻结边界。"

### 后续
- `/freeze` 的检查逻辑仍会运行，但因为状态文件不存在所以允许所有操作
- 要重新冻结，运行 `/freeze`

## 使用场景
- 完成限定范围的调试后恢复全目录编辑
- 需要编辑冻结目录外的文件
- 误设置冻结边界后需要清除

## 不适用场景
- 未设置冻结边界时（无需操作）
- 希望设置新的冻结边界时（使用gstack-freeze）

## 输出
- 冻结边界清除确认
- 或"未设置冻结边界"提示

## 依赖
- `.trae/gstack/state/freeze-dir.txt`（由gstack-freeze创建）
