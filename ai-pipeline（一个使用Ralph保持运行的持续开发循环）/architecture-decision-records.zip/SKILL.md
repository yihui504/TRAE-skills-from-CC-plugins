---
name: architecture-decision-records
description: "当用户说'记录这个决策'或'ADR this'，或在AI工程流水线中做出重要架构选择时使用。"
---

# Architecture Decision Records

在编码会话中捕获架构决策。决策不再只存在于 Slack 线程、PR 评论或某人的记忆中，本skill产生与代码共存的结构化 ADR 文档。

## 适用场景

- 用户明确说"记录这个决策"或"ADR this"
- 用户在重要备选方案间做选择（框架、库、模式、数据库、API设计）
- 用户说"我们决定..."或"做X而不是Y的原因是..."
- 用户问"为什么我们选择了X？"（读取现有ADR）
- 规划阶段讨论架构权衡时
- 作为AI工程流水线 Phase 2（在 blueprint → eval-harness → self-improve → ai-slop-cleaner 期间作为后台服务运行）

## 不适用场景

- 变量命名或格式化选择等琐碎决策
- 没有明确架构影响的纯实现细节
- 用户只是讨论想法但未做决策
- 代码审查中的风格偏好

注意：本skill作为流水线的持续后台服务运行，在SOLO Coder中可随时调用以记录架构决策。

## ADR 格式

使用 Michael Nygard 提出的轻量级 ADR 格式，适配AI辅助开发：

```markdown
# ADR-NNNN: [Decision Title]

**Date**: YYYY-MM-DD
**Status**: proposed | accepted | deprecated | superseded by ADR-NNNN
**Deciders**: [who was involved]

## Context

What is the issue that we're seeing that is motivating this decision or change?

[2-5 sentences describing the situation, constraints, and forces at play]

## Decision

What is the change that we're proposing and/or doing?

[1-3 sentences stating the decision clearly]

## Alternatives Considered

### Alternative 1: [Name]
- **Pros**: [benefits]
- **Cons**: [drawbacks]
- **Why not**: [specific reason this was rejected]

### Alternative 2: [Name]
- **Pros**: [benefits]
- **Cons**: [drawbacks]
- **Why not**: [specific reason this was rejected]

## Consequences

What becomes easier or more difficult to do because of this change?

### Positive
- [benefit 1]
- [benefit 2]

### Negative
- [trade-off 1]
- [trade-off 2]

### Risks
- [risk and mitigation]
```

## 指令

### 捕获新 ADR

当检测到决策时刻：

1. **初始化（仅首次）** — 如 `.trae/adr/` 不存在，在创建目录前询问用户确认，创建包含索引表头的 `README.md`（见下方ADR索引格式）和空白的 `template.md` 供手动使用。不要在未经明确同意的情况下创建文件。
2. **识别决策** — 提取正在做出的核心架构选择
3. **收集上下文** — 什么问题促成了这个决策？存在什么约束？
4. **记录备选方案** — 考虑了哪些其他选项？为什么被拒绝？
5. **陈述后果** — 权衡是什么？什么变得更容易/更难？
6. **分配编号** — 扫描 `.trae/adr/` 中的现有ADR并递增
7. **确认并写入** — 将ADR草稿呈现给用户审阅。只有在明确批准后才写入 `.trae/adr/NNNN-decision-title.md`。如果用户拒绝，丢弃草稿，不写入任何文件。
8. **更新索引** — 追加到 `.trae/adr/README.md`

### 读取现有 ADR

当用户问"为什么我们选择了X？"：

1. 检查 `.trae/adr/` 是否存在——如不存在，回复："此项目中未找到ADR。是否要开始记录架构决策？"
2. 如存在，扫描 `.trae/adr/README.md` 索引查找相关条目
3. 读取匹配的ADR文件并呈现 Context 和 Decision 部分
4. 如未找到匹配，回复："未找到该决策的ADR。是否要现在记录一个？"

### ADR 目录结构

```
.trae/
└── adr/
    ├── README.md              ← 所有ADR的索引
    ├── 0001-use-nextjs.md
    ├── 0002-postgres-over-mongo.md
    ├── 0003-rest-over-graphql.md
    └── template.md            ← 手动使用的空白模板
```

### ADR 索引格式

```markdown
# Architecture Decision Records

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| [0001](0001-use-nextjs.md) | Use Next.js as frontend framework | accepted | 2026-01-15 |
| [0002](0002-postgres-over-mongo.md) | PostgreSQL over MongoDB for primary datastore | accepted | 2026-01-20 |
| [0003](0003-rest-over-graphql.md) | REST API over GraphQL | accepted | 2026-02-01 |
```

## 决策检测信号

在对话中观察以下指示架构决策的模式：

**显式信号**
- "我们用X吧"
- "我们应该用X而不是Y"
- "这个权衡是值得的，因为..."
- "把这个记录为ADR"

**隐式信号**（建议记录ADR——不要在未经用户确认的情况下自动创建）
- 比较两个框架或库并得出结论
- 做出数据库模式设计选择并陈述理由
- 在架构模式间选择（单体 vs 微服务、REST vs GraphQL）
- 决定认证/授权策略
- 评估备选方案后选择部署基础设施

## 优秀 ADR 的要素

### 应该做
- **要具体** — "使用 Prisma ORM" 而非 "使用ORM"
- **记录原因** — 理由比结论更重要
- **包含被拒的备选方案** — 未来开发者需要知道考虑了什么
- **诚实陈述后果** — 每个决策都有权衡
- **保持简短** — ADR 应该2分钟内可读完
- **使用现在时** — "我们使用X" 而非 "我们将使用X"

### 不应该做
- 记录琐碎决策 — 变量命名或格式化选择不需要ADR
- 写成长文 — 如果上下文部分超过10行，就太长了
- 省略备选方案 — "我们就是选了它" 不是有效理由
- 不标注地回填 — 如果记录过去的决策，注明原始日期
- 让ADR过时 — 被取代的决策应引用其替代

## ADR 生命周期

```
proposed → accepted → [deprecated | superseded by ADR-NNNN]
```

- **proposed**: 决策正在讨论中，尚未确定
- **accepted**: 决策生效并被遵循
- **deprecated**: 决策不再相关（如功能已移除）
- **superseded**: 新的ADR取代此决策（始终链接替代ADR）

## 值得记录的决策类别

| 类别 | 示例 |
|----------|---------|
| **技术选择** | 框架、语言、数据库、云提供商 |
| **架构模式** | 单体 vs 微服务、事件驱动、CQRS |
| **API设计** | REST vs GraphQL、版本策略、认证机制 |
| **数据建模** | 模式设计、规范化决策、缓存策略 |
| **基础设施** | 部署模型、CI/CD流水线、监控栈 |
| **安全** | 认证策略、加密方案、密钥管理 |
| **测试** | 测试框架、覆盖率目标、E2E vs 集成测试的平衡 |
| **流程** | 分支策略、审阅流程、发布节奏 |

## 流水线集成

本skill是AI工程流水线的 Phase 2。它在整个流水线中作为**持续后台服务**运行：

- **blueprint**（Phase 1）期间：建议为计划中的架构选择记录ADR
- **eval-harness**（Phase 3）期间：记录关于评估方法论的决策
- **self-improve**（Phase 4）期间：捕获为什么选择某些优化方案而非其他——对于理解数十次迭代中的代码进化至关重要
- **ai-slop-cleaner**（Phase 5）期间：记录清理了什么以及为什么

其特殊价值：在 self-improve 的数十轮进化中，如果不记录"为什么选择方案A而非B"，几轮之后没人（包括AI本身）能理解代码为什么长成这样。

## 依赖

- blueprint（Phase 1，提供计划文件中的架构选择作为输入）

## 输出

- ADR文档：`.trae/adr/NNNN-decision-title.md`
- ADR索引：`.trae/adr/README.md`
- ADR模板：`.trae/adr/template.md`（首次初始化时创建）
