---
name: external-research
description: "当AI流水线检测到分数停滞（5+轮无改进），或用户说'外部研究'、'突破瓶颈'、'寻找新方案'时使用。不适用于流水线稳步进展或仅需快速网络搜索的场景。"
---

# External Research — 用外部知识突破瓶颈

当内部代码库分析和迭代改进已穷尽潜力时，本skill搜索更广阔的世界寻找新想法。它是流水线在说："我们卡住了——看看别人发现了什么。"

## 适用场景

- AI流水线已停滞（分数5+轮未提升）
- 用户明确请求外部研究（"外部研究"、"突破瓶颈"、"寻找新方案"）
- 用户要求搜索特定问题的参考实现或文献
- self-improve 的内部研究员已在代码库内穷尽新想法

## 不适用场景

- 流水线正在稳步进展——内部迭代已足够
- 用户只想快速网络搜索（直接使用 WebSearch）
- 任务足够简单，外部研究是杀鸡用牛刀

注意：本skill作为流水线的条件阶段运行，在SOLO Coder中也可独立调用以针对特定问题进行外部研究。

## 输入

| 字段 | 必需 | 描述 |
|---|---|---|
| `objective` | 是 | 原始改进目标 |
| `current_score` | 是 | 当前基准分数 |
| `target_score` | 是 | 目标分数（验收标准） |
| `score_gap` | 是 | 当前与目标之间的差距 |
| `approaches_tried` | 是 | 已尝试的方案族和具体假设列表，含结果 |
| `adrs` | 是 | 记录先前架构决策的ADR文件列表 |
| `codebase_summary` | 是 | 代码库、技术栈和架构的简要描述 |
| `idea_output_path` | 是 | 写入输出想法文件的路径（通常为 `<self-improve-root>/config/idea.md`） |
| `iteration_history_path` | 否 | 完整迭代历史路径，用于更深入分析 |

## 输出

写入 `idea_output_path` 的结构化可操作想法列表，每条包含：

```markdown
## External Research Ideas

### Research Context
- Objective: {objective}
- Current score: {current_score} / Target: {target_score} (gap: {score_gap})
- Approaches exhausted: {list of approach families tried}
- Research date: {date}

---

### Idea 1: {Short Title}

**Source**: {URL or paper citation}
**Approach family**: {architecture|optimization|data|infrastructure|training_config|testing|other}
**Specific technique**: {concrete description of what to do}
**Why it might work**: {reasoning based on the source evidence}
**Estimated impact**: {quantified estimate, e.g., "5-10% improvement"}
**How it differs from prior attempts**: {explicitly state what's new vs what was already tried}
**Trade-offs**: {what we gain vs what we lose}
**ADR conflicts**: {any prior ADR decisions this conflicts with, or "none"}

### Idea 2: {Short Title}
...
```

## 指令

### Step 1: 分析瓶颈

在外部搜索之前，深入理解流水线为什么卡住：

1. 读取迭代历史：尝试了哪些方案族？结果如何？
2. 读取ADR：做了什么决策？为什么？是否有决策现在值得怀疑？
3. 识别具体瓶颈：是算法的？架构的？数据相关的？基础设施的？
4. 构建核心问题："在{具体约束}下，什么技术可以实现{具体改进}？"

此分析直接指导搜索查询——模糊的查询产生模糊的结果。

### Step 2: 搜索 GitHub

搜索参考实现和替代架构：

1. **仓库搜索**: 找到解决相同或类似问题的仓库
   - 搜索查询：将问题领域与"optimization"、"high-performance"、"alternative"、"benchmark"等关键词组合
   - 对每个有前景的仓库：阅读README、检查星标数和近期活动、检查架构
2. **代码搜索**: 找到具体的实现模式
   - 搜索可能突破瓶颈的特定算法、数据结构或模式
3. **Issue/讨论搜索**: 找到特定问题的已知解决方案
   - 搜索与瓶颈相关的关键词

**对每个发现**，提取：
- 他们使用的方法
- 为什么有效（来自他们的文档/基准）
- 关键代码模式或架构决策
- 对我们代码库的适用性

### Step 3: 搜索 arXiv

搜索最新学术研究：

1. **论文搜索**: 找到关于特定优化问题的论文
   - 重点关注：优化算法、架构模式、评估方法论
   - 优先近2年的论文以获取最先进技术
2. **提取实用见解**: 学术论文通常包含可转化为实际改进的理论见解
   - 寻找：算法改进、可证明更优的方法、新评估指标
3. **评估实用性**: 过滤掉在项目约束内无法实现的纯理论工作

**对每个发现**，提取：
- 核心技术及为什么理论上更优
- 实际实现考虑
- 预期改进幅度
- 对当前架构所需的变更

### Step 4: 搜索技术博客和文档

搜索工程经验和最佳实践：

1. **工程博客**: 公司工程博客经常分享真实世界的优化案例
   - 搜索：性能优化案例研究、架构迁移故事
2. **官方文档**: 框架/工具文档可能揭示尚未利用的功能
   - 检查：配置选项、性能调优指南、鲜为人知的功能
3. **性能调优指南**: 平台特定的优化建议
   - 寻找：语言特定优化、运行时调优、编译器标志

### Step 5: 搜索论坛和社区

搜索实践者解决方案：

1. **Stack Overflow**: 特定技术问答
2. **Reddit/Discord 社区**: 更广泛的讨论和经验分享
3. **GitHub Discussions**: 项目特定的优化建议

### Step 6: 深度分析与过滤

将所有发现综合为可操作的想法：

1. **与先前尝试交叉引用**: 每个想法必须明确说明与已尝试方案的区别。仅重复失败方案的想法必须解释为什么这次结果可能不同。

2. **与ADR交叉引用**: 将每个想法与现有架构决策对照检查：
   - 如果想法与ADR冲突：记录冲突，解释为什么重新审视该决策可能是合理的
   - 如果想法与ADR一致：记录强化

3. **可行性评估**: 对每个想法，评估：
   - 能否在当前代码库结构中实现？
   - 是否需要新依赖？（优先选择不需要的）
   - 预估实现复杂度如何？
   - 回归风险有多大？

4. **影响估算**: 按预估影响排列想法（高/中/低置信度）

5. **多样性检查**: 确保想法跨越至少3个不同的方案族。如果所有想法都在同一族中，扩大搜索范围。

### Step 7: 写入输出

按照上述输出格式将结构化想法写入 `idea_output_path`。

**质量要求**：
- 最少3个想法，最多10个
- 每个想法必须有具体的、可引用的来源
- 每个想法必须解释与先前尝试的区别
- 想法按置信度 x 预估影响排序（最高优先）
- 至少代表2个不同的方案族

### Step 8: 报告

向用户展示摘要：

```
=== External Research Complete ===

Bottleneck analysis: {why we're stuck}
Sources searched: GitHub ({N} repos), arXiv ({N} papers), Blogs ({N} posts), Forums ({N} threads)

Ideas generated: {count}
- High confidence: {count}
- Medium confidence: {count}
- Low confidence: {count}

Approach families covered: {list}

Top 3 ideas:
1. {title} ({approach_family}, {estimated_impact})
2. {title} ({approach_family}, {estimated_impact})
3. {title} ({approach_family}, {estimated_impact})

Ideas written to: {idea_output_path}
```

## 硬约束

这些约束是**绝对的**，无论外部研究发现了什么都不能放松：

1. **原始目标** — 不要降低标准或重新定义"完成"
2. **验收标准（目标分数）** — 不要下调目标
3. **评估基准** — 不要削弱测试套件或改变评分标准
4. **回归阈值** — 不要允许更多回归

新想法必须以**不同手段**达到**相同目标**，而非不同（更简单的）目标。如果外部研究表明目标不现实，向用户报告但**绝不**单方面降低目标。

## 失败策略

| 情况 | 操作 |
|---|---|
| GitHub 上无相关发现 | 扩大搜索词，尝试相邻领域，继续到 arXiv |
| arXiv 上无相关论文 | 尝试不同的关键词组合，搜索引用图 |
| 所有发现都不实际 | 如实报告——有时瓶颈是根本性的。建议用户是否应重新考虑目标。 |
| 发现与硬约束冲突 | 丢弃该发现。不要建议放松约束。 |
| 搜索返回太多结果 | 用更具体的术语缩小查询，按时效和相关性过滤 |
| 无法访问某个来源 | 记录来源，尝试替代访问方式（缓存、镜像），不要未尝试就跳过 |

## 流水线集成

本skill是AI流水线循环中的**条件阶段**。它作为 Phase 6（条件触发）位于循环之间：

```
Phase 5 (ai-slop-cleaner)
     │
     ▼
验收检查 ─── 目标达成? ──→ 交付 & 退出
     │
     │ NO
     ▼
瓶颈检查 ─── 分数停滞5+轮? ──→ Phase 6: external-research
     │                                                    │
     │ NO                                                 ▼
     │                                              重新进入循环
     ▼                                             (Phase 4 或 Phase 1)
重新进入循环 (Phase 4)
```

external-research 完成后，流水线重新进入：
- **Phase 4 (self-improve)** 如果新想法是当前架构内的增量改进
- **Phase 1 (blueprint)** 如果发现表明需要根本不同的方法，需要重新规划

本skill也可在流水线外**独立使用**，当用户需要对特定问题进行针对性外部研究时。

## 依赖

- self-improve（Phase 4，需要瓶颈分析结果作为输入）

## 输出

- 可操作想法列表：写入 `<self-improve-root>/config/idea.md`
- 研究报告：包含来源统计、想法置信度、方案族覆盖
