---
name: ai-pipeline
description: "当用户说'运行流水线'、'ai-pipeline'、'完整流水线'，或需要从想法到生产级代码的自动化工程流程时使用。不适用于单skill即可完成的简单任务。"
---

# AI Pipeline — 从想法到生产级代码

编排完整的AI工程流水线，以目标驱动循环运行。流水线不会只运行一次就停止——它会循环直到 eval-harness 中定义的验收标准被满足，并根据需要重新规划和进化。

## 适用场景

- 用户说"运行流水线"、"ai-pipeline"、"完整流水线"
- 用户描述了需要完整工作流的复杂改进目标
- 用户希望从模糊的想法到交付干净的代码
- 用户暗示需要完整的"思考 → 记录 → 度量 → 进化 → 清理"循环

## 不适用场景

- 任务足够简单，单个skill即可完成
- 用户明确调用特定流水线阶段（如"只运行blueprint"）
- 用户对小型任务说"直接做"

注意：本skill编排完整的AI工程流水线，在SOLO Coder中建议配合自定义智能体使用。

## 流水线概览

流水线是一个**目标驱动循环**，而非一次性序列：

```
[用户目标]
     │
     ▼
 ┌─────────────────────────────────────────────────────────────────┐
 │  Phase 1: blueprint                                              │
 │  将一行目标转化为逐步构建计划                                      │
 │  输出: 依赖图 + 并行步骤 + 上下文简报                              │
 └──────────────────────────┬──────────────────────────────────────┘
                            │
                            ▼
 ┌─────────────────────────────────────────────────────────────────┐
 │  Phase 2: architecture-decision-records                          │
 │  将架构决策捕获为结构化ADR                                         │
 │  输出: ADR文档（上下文、备选方案、理由）                             │
 └──────────────────────────┬──────────────────────────────────────┘
                            │
                            ▼
 ┌─────────────────────────────────────────────────────────────────┐
 │  Phase 3: eval-harness                                           │
 │  定义可量化的评估标准和基准                                         │
 │  输出: 评估套件 + 基线分数 + 验收标准                               │
 └──────────────────────────┬──────────────────────────────────────┘
                            │
                            ▼
 ┌─────────────────────────────────────────────────────────────────┐
 │  Phase 4: self-improve                                           │
 │  锦标赛式自动进化 — 并行方案竞争                                    │
 │  输出: 持续改进的代码 + 进度图 + 历史                                │
 └──────────────────────────┬──────────────────────────────────────┘
                            │
                            ▼
 ┌─────────────────────────────────────────────────────────────────┐
 │  Phase 5: ai-slop-cleaner                                        │
 │  回归安全的代码清理 — 删除死代码、合并重复                            │
 │  输出: 精炼的生产级代码                                             │
 └──────────────────────────┬──────────────────────────────────────┘
                            │
                            ▼
                 ┌─────────────────────┐
                 │  验收检查             │
                 │  目标达成?            │
                 └──────┬──────┬───────┘
                        │      │
                   YES  │      │  NO
                        │      │
                        ▼      ▼
               [交付 &     ┌──────────────────────────────────────┐
                退出]      │  瓶颈检查                              │
                           │  分数停滞5+轮?                          │
                           └──────┬──────────────┬────────────────┘
                                  │              │
                             YES  │              │  NO
                                  │              │
                                  ▼              ▼
                      ┌──────────────────┐   重新进入循环
                      │  Phase 6:         │   (Phase 4)
                      │  external-research│
                      │  (条件触发)        │
                      └────────┬─────────┘
                               │
                               ▼
                        重新进入循环
                        (Phase 4 或 Phase 1)
```

### 循环行为

每次完整通过后（或 self-improve + slop-cleaner 之后），评估验收标准是否满足：

- **目标达成** → 交付结果，退出流水线
- **目标未达成，但有进展** → 从 Phase 4 (self-improve) 重新进入，通过 `idea.md` 注入新策略
- **目标未达成，且卡住（停滞或所有方案已穷尽）** → 从 Phase 1 (blueprint) 重新进入，用根本不同的策略重新规划
- **目标未达成，且验收标准需要调整** → 咨询用户：细化目标、调整目标值或扩大范围

循环**没有上限**，直到满足以下退出条件之一：
1. **验收标准达成** — 基准分数达到目标
2. **用户明确停止**流水线

### 瓶颈检测与外部研究（Phase 6）

当流水线检测到**瓶颈**——分数在过去5轮没有提升——触发**Phase 6: external-research**作为条件流水线阶段。

**触发条件**: `cycle_count >= 10` 且 `分数在过去5轮没有提升`（将当前分数与5轮前的最佳分数比较）。

**执行内容**: 调用 `external-research` skill（Skill tool: `external-research`），传入：
- 原始目标和验收标准
- 当前分数 vs 目标分数
- 所有已尝试的方案（来自迭代历史）
- ADR记录
- 代码库摘要
- 输出路径: `<self-improve-root>/config/idea.md`

external-research skill 将：
1. 搜索 GitHub、arXiv、技术博客和论坛，寻找参考实现和灵感
2. 深入分析发现，映射到当前代码库
3. 将具体可操作的想法写入 `idea.md`——每个想法包含来源、技术、预估影响以及与先前尝试的区别
4. **绝不放松硬约束**：原始目标、验收标准、评估基准和回归阈值保持绝对

**external-research 完成后**，重新进入循环：
- 如果新想法是增量改进 → 从 Phase 4 (self-improve) 重新进入
- 如果发现表明需要根本不同的方法 → 从 Phase 1 (blueprint) 重新进入

**再次触发**: 如果分数又停滞5轮且总轮数达到下一个10轮倍数，外部研究再次触发。

## 指令

### Step 0: 收集目标（深度交互引导）

以任何形式接受用户目标——从一行描述到详细规格。**在开始前充分理解目标。** 根据需要提出尽可能多的澄清问题。不要在目标不明确时急于执行。

**必需信息**（启动前必须获取）：
1. **目标**: 具体要改进什么？要明确。（例如，不是"让它更好"而是"将推荐延迟降到100ms以下"）
2. **目标仓库**: 哪个仓库？（默认：当前项目目录）

**强烈建议信息**（如未提供则询问——这些显著影响流水线效果）：
3. **目标指标和值**: 如何衡量成功？什么数字算"完成"？（例如，"p99延迟 < 100ms"、"测试覆盖率 > 90%"）
4. **范围**: 哪些文件/模块在范围内？哪些不可触碰？
5. **约束**: 有哪些硬约束？（例如，"不能改变公共API"、"计算预算限制为$X"）

**额外上下文**（相关时询问）：
6. **当前基线**: 是否知道当前性能？有现有基准吗？
7. **先前尝试**: 之前尝试过吗？结果如何？
8. **业务背景**: 为什么这很重要？紧迫性如何？
9. **验收标准**: 除主要指标外，还有其他"完成"条件吗？（例如，"还必须通过安全审计"）
10. **风险容忍度**: 优化可以多激进？稳定性比峰值性能更重要吗？

**引导原则**：
- 一次只问一个问题，按对流水线效果的影响优先排序
- 问题数量没有上限——持续询问直到目标完全清晰
- 利用目标仓库来指导提问（阅读 README、检查现有测试、理解代码库）
- 当用户提供部分信息时，确认并询问下一个最重要的问题
- 只有在确信理解了"改进什么"、"如何衡量"和"'完成'是什么样的"时才启动流水线
- 如果用户明确说"现在开始"或"够了"，用已有信息继续

### Step 1: 启动 Phase 1 — Blueprint

使用用户目标调用 `blueprint` skill。

**执行内容**：
1. 加载 blueprint skill（Skill tool: `blueprint`）
2. 执行 blueprint 流水线：Research → Design → Draft → Review → Register
3. blueprint 将在 `.trae/plans/` 中生成计划文件

**输出检查点**: 计划文件存在于 `.trae/plans/{slug}.md`

**失败时**: 如果 blueprint 无法生成计划（如目标太模糊），回到 Step 0 提出更多澄清问题。不要用弱计划继续。

**重新进入（循环）时**: 当因策略卡住而从循环重新进入时，明确告知 blueprint 先前方案失败，需要根本不同的分解。将差距分析（当前分数 vs 目标、已尝试内容）作为上下文传入。

### Step 2: 启动 Phase 2 — Architecture Decision Records

调用 `architecture-decision-records` skill 捕获 blueprint 中的决策。

**执行内容**：
1. 加载 architecture-decision-records skill（Skill tool: `architecture-decision-records`）
2. 审查 blueprint 计划中的架构选择
3. 为计划中的每个重要决策创建 ADR
4. 如 `.trae/adr/` 不存在则初始化

**输出检查点**: ADR 文件存在于 `.trae/adr/`

**失败时**: 记录警告，继续。ADR 捕获重要但不阻塞。

### Step 3: 启动 Phase 3 — Eval Harness

调用 `eval-harness` skill 定义成功指标和**验收标准**。

**执行内容**：
1. 加载 eval-harness skill（Skill tool: `eval-harness`）
2. 基于 blueprint 的退出标准定义能力评估
3. 为现有功能定义回归评估
4. 创建或识别基准脚本
5. 验证基准（3次运行，方差 < 5%）
6. 记录基线分数
7. **定义验收标准**: 什么基准分数算"目标达成"？这成为流水线的退出条件。

**输出检查点**：
- 评估定义在 `.trae/evals/`
- 输出分数的基准脚本
- 已记录的基线分数
- 已定义的验收标准（目标分数 + 方向）

**失败时**: 如果无法创建基准，请用户提供基准命令。如果用户也无法提供，报告并退出——流水线需要可量化的验收标准才能作为循环运行。

### Step 4: 启动 Phase 4 — Self-Improve

调用 `self-improve` skill 运行进化循环。

**执行内容**：
1. 加载 self-improve skill（Skill tool: `self-improve`）
2. self-improve skill 将：
   - 使用 Phase 3 的基准设置状态目录
   - 自主运行改进循环
   - 使用 eval-harness 基准作为评估标准
   - 使用 Phase 2 的 ADR 避免重复失败方案
   - 在满足停止条件时停止（目标达成、停滞、最大迭代数等）
3. 不要中断 self-improve 循环——它自主运行

**输出检查点**：
- 改进后的代码在 `improve/{goal_slug}` 分支上
- 进度图在 `.trae/self-improve/topics/{slug}/tracking/progress.png`
- 已记录的迭代历史

**失败时**: 如果 self-improve 无法启动（如无基准），报告并跳到 Phase 5 使用当前代码。

**重新进入（循环）时**: 从外循环重新进入 self-improve 时，将新策略想法注入 `<self-improve-root>/config/idea.md`。重置断路器计数。如果上次 self-improve 运行停滞，考虑调整设置中的 `number_of_agents` 或 `target_value`。

### Step 5: 启动 Phase 5 — AI Slop Cleaner

调用 `ai-slop-cleaner` skill 清理进化残留。

**执行内容**：
1. 加载 ai-slop-cleaner skill（Skill tool: `ai-slop-cleaner`）
2. 运行删除优先的清理工作流：
   - Pass 1: 死代码删除
   - Pass 2: 重复代码移除
   - Pass 3: 命名和错误处理清理
   - Pass 4: 测试加固
3. 清理过程中使用 eval-harness 基准作为回归保护
4. 移除抽象前检查 ADR，确认非刻意引入

**输出检查点**: 干净的生产级代码，所有回归测试通过

**失败时**: 如果清理引入无法修复的回归，回退清理步骤并报告。self-improve 输出仍然有效。

### Step 6: 验收检查 — 目标达成？

Phase 5 之后，运行 Phase 3 的基准并与验收标准比较。

**评估**：
1. 在当前代码上运行基准命令
2. 将分数与 Phase 3 定义的验收标准比较
3. 判断结果：

| 结果 | 条件 | 操作 |
|---|---|---|
| **目标达成** | 分数达到或超过验收标准 | → Step 7: 交付结果 |
| **有进展** | 分数提升但未达目标 | → 从 Phase 4 重新进入，注入新想法 |
| **卡住/停滞** | 分数在多轮中停止提升 | → 触发 Phase 6 (external-research)，然后重新进入循环 |
| **回归** | 清理后分数下降 | → 回退清理，从 Phase 4 重新进入 |

**重新进入 Phase 4（有进展）时**：
- 将新策略想法写入 `<self-improve-root>/config/idea.md`
- 更新流水线状态：递增 `cycle_count`
- 继续循环

**检测到瓶颈（卡住/停滞）时**：
- 检查触发条件：`cycle_count >= 10` 且过去5轮无改进
- 如触发：调用 `external-research` skill（Phase 6）——见上方"瓶颈检测与外部研究"
- external-research 完成后：从 Phase 4（增量想法）或 Phase 1（根本不同方案）重新进入
- 如未触发（停滞但未达10轮）：从 Phase 1 重新进入，用内部知识重新规划
- 更新流水线状态：递增 `cycle_count`，设置 `bottleneck_detected`

**循环安全**：
- 无轮数限制——流水线按需运行
- 瓶颈检测：如果分数5轮未提升且 cycle_count >= 10，触发 Phase 6 (external-research)
- 用户可随时停止流水线

### Step 7: 交付结果

向用户展示最终摘要：

```
=== AI Pipeline Complete ===

Goal: {原始目标}
Repository: {仓库路径}
Pipeline cycles: {cycle_count}

Phase 1 (Blueprint): ✅ {N} steps planned
Phase 2 (ADR): ✅ {N} decisions recorded
Phase 3 (Eval Harness): ✅ Baseline {score}, benchmark ready
Phase 4 (Self-Improve): ✅ {total_iterations} iterations across {cycle_count} cycles
Phase 5 (Slop Cleaner): ✅ {N} files cleaned

Final Results:
- Baseline score: {baseline}
- Final score: {final_score}
- Improvement: {delta} ({delta_pct}%)
- Acceptance criteria: {criteria} — MET ✅

Artifacts:
- Improvement branch: improve/{goal_slug}
- ADRs: .trae/adr/
- Evals: .trae/evals/
- Progress chart: .trae/self-improve/topics/{slug}/tracking/progress.png
- Pipeline state: .trae/pipeline-state.json

Next steps:
- Review the improvement branch: git checkout improve/{goal_slug}
- Create a PR: gh pr create --head improve/{goal_slug} --base {target_branch}
- Or merge directly: git checkout {target_branch} && git merge improve/{goal_slug}
```

## 失败策略

| 情况 | 操作 |
|---|---|
| Blueprint 失败 | 回到 Step 0，提出更多澄清问题。不要用弱计划继续。 |
| ADR 失败 | 记录警告，继续。非阻塞。 |
| Eval-harness 失败（无基准） | 请用户提供基准命令。如不可用则退出——循环需要可量化标准。 |
| Self-improve 无法启动 | 跳到 slop-cleaner 使用当前代码，然后做验收检查。 |
| Self-improve 循环中崩溃 | 重新调用时从上次检查点恢复。 |
| Slop-cleaner 引入回归 | 回退清理步骤。Self-improve 输出保留。 |
| 验收检查显示回归 | 回退清理，重新进入 Phase 4。 |
| 检测到瓶颈（5轮无改进） | 触发 Phase 6 (external-research skill)，注入新想法，继续循环。 |
| 用户停止流水线 | 记录状态，优雅退出。可稍后恢复。 |

## 流水线状态跟踪

在 `.trae/pipeline-state.json` 中跟踪流水线进度：

```json
{
  "objective": "用户的原始目标",
  "repo_path": "/path/to/repo",
  "topic_slug": "derived-slug",
  "started_at": "ISO 8601",
  "current_phase": 4,
  "cycle_count": 2,
  "replan_count": 0,
  "last_external_research_cycle": 0,
  "bottleneck_detected": false,
  "acceptance_criteria": {
    "metric": "primary",
    "target_value": 95.0,
    "direction": "higher_is_better"
  },
  "current_score": 88.5,
  "baseline_score": 72.0,
  "phases": {
    "blueprint": { "status": "completed", "output_path": ".trae/plans/...", "completed_at": "..." },
    "adr": { "status": "completed", "output_path": ".trae/adr/", "completed_at": "..." },
    "eval_harness": { "status": "completed", "baseline_score": 72.0, "completed_at": "..." },
    "self_improve": { "status": "completed", "best_score": 88.5, "iterations": 12, "completed_at": "..." },
    "slop_cleaner": { "status": "completed", "completed_at": "..." },
    "external_research": { "status": "not_triggered", "last_triggered_cycle": null, "ideas_generated": 0, "completed_at": null }
  },
  "loop_history": [
    { "cycle": 1, "entry_phase": 1, "score_before": 72.0, "score_after": 85.0, "outcome": "making_progress" },
    { "cycle": 2, "entry_phase": 4, "score_before": 85.0, "score_after": 88.5, "outcome": "making_progress" }
  ],
  "completed_at": null
}
```

重新调用时，检查此文件以从上次完成的阶段和循环恢复。

## 可恢复性

如果流水线被中断：
1. 读取 `.trae/pipeline-state.json`
2. 找到上次完成的阶段和循环
3. 从当前循环的下一阶段恢复
4. 每个单独的 skill（尤其是 self-improve）有自己的可恢复性机制
5. 如果流水线在循环中，在适当的入口点恢复循环

## 依赖

- blueprint（Phase 1 起点）
- architecture-decision-records（Phase 2）
- eval-harness（Phase 3）
- self-improve（Phase 4）
- ai-slop-cleaner（Phase 5）
- external-research（Phase 6，条件触发）

## 输出

- 计划文件：`.trae/plans/{slug}.md`
- ADR文档：`.trae/adr/`
- 评估定义：`.trae/evals/`
- 改进分支：`improve/{goal_slug}`
- 进度图：`.trae/self-improve/topics/{slug}/tracking/progress.png`
- 流水线状态：`.trae/pipeline-state.json`
