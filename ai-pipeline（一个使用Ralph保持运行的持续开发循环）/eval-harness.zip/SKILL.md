---
name: eval-harness
description: "当需要为代码定义成功标准、设置评估基准时使用，也作为AI工程流水线Phase 3（blueprint和ADR之后，self-improve之前）。"
---

# Eval Harness Skill

实现评估驱动开发（EDD）原则的正式评估框架。

## 适用场景

- 为AI辅助工作流设置评估驱动开发（EDD）
- 定义任务完成的通过/失败标准
- 使用 pass@k 指标衡量代理可靠性
- 为提示或代理变更创建回归测试套件
- 跨模型版本基准测试性能
- 作为AI工程流水线 Phase 3（blueprint 和 ADR 之后，self-improve 之前）

## 不适用场景

- 不需要量化评估的简单任务
- 已有完善测试套件且无需额外评估的项目
- 纯探索性工作，没有明确的成功标准

注意：本skill是self-improve的前提条件，在SOLO Coder中建议在运行self-improve前先完成eval-harness设置。

## 理念

评估驱动开发将评估视为"AI开发的单元测试"：
- 在实现之前定义预期行为
- 在开发过程中持续运行评估
- 跟踪每次变更的回归
- 使用 pass@k 指标进行可靠性度量

## 指令

### Step 1: 定义评估（编码前）

在 `.trae/evals/{feature-name}.md` 创建评估定义文件：

```markdown
## EVAL DEFINITION: feature-xyz

### Capability Evals
1. Can create new user account
2. Can validate email format
3. Can hash password securely

### Regression Evals
1. Existing login still works
2. Session management unchanged
3. Logout flow intact

### Success Metrics
- pass@3 > 90% for capability evals
- pass^3 = 100% for regression evals
```

### Step 2: 选择评分器类型

#### 基于代码的评分器（首选）
使用代码进行确定性检查：
```bash
grep -q "export function handleAuth" src/auth.ts && echo "PASS" || echo "FAIL"
npm test -- --testPathPattern="auth" && echo "PASS" || echo "FAIL"
npm run build && echo "PASS" || echo "FAIL"
```

#### 基于模型的评分器
使用LLM评估开放式输出：
```markdown
[MODEL GRADER PROMPT]
Evaluate the following code change:
1. Does it solve the stated problem?
2. Is it well-structured?
3. Are edge cases handled?
4. Is error handling appropriate?

Score: 1-5 (1=poor, 5=excellent)
Reasoning: [explanation]
```

#### 人工评分器
标记为人工审阅：
```markdown
[HUMAN REVIEW REQUIRED]
Change: Description of what changed
Reason: Why human review is needed
Risk Level: LOW/MEDIUM/HIGH
```

### Step 3: 实现基准脚本

创建输出分数的基准脚本：

**要求：**
- **首选JSON输出**: stdout最后一行为 `{"primary": 85.2, "sub_scores": {"dim_a": 0.92}}`
- **确定性**: 相同代码 → 相同分数（固定种子）
- **快速**: 理想情况下5分钟内
- **自包含**: 无外部服务
- **诚实**: 衡量实际质量

将基准脚本放在目标仓库中（如 `scripts/benchmark.py` 或 `benchmark.py`）。
成功时必须退出0，错误时非零。将分数打印为stdout最后一行。

### Step 4: 验证基准

运行基准3次：
```
Run 1: {x}
Run 2: {y}
Run 3: {z}
Variance: {(max-min)/mean * 100}%
```
3次都必须完成。方差必须 < 5%。

### Step 5: 记录基线

将基线保存到 `.trae/evals/baseline.json`：
```json
{ "baseline_score": 80.0, "recorded_at": "2026-05-02T12:00:00Z" }
```

### Step 6: 生成报告

```markdown
EVAL REPORT: feature-xyz
========================

Capability Evals:
  create-user:     PASS (pass@1)
  validate-email:  PASS (pass@2)
  hash-password:   PASS (pass@1)
  Overall:         3/3 passed

Regression Evals:
  login-flow:      PASS
  session-mgmt:    PASS
  logout-flow:     PASS
  Overall:         3/3 passed

Metrics:
  pass@1: 67% (2/3)
  pass@3: 100% (3/3)

Status: READY FOR REVIEW
```

## 评估类型

### 能力评估
测试系统是否能做之前做不到的事：
```markdown
[CAPABILITY EVAL: feature-name]
Task: Description of what should be accomplished
Success Criteria:
  - [ ] Criterion 1
  - [ ] Criterion 2
  - [ ] Criterion 3
Expected Output: Description of expected result
```

### 回归评估
确保变更不会破坏现有功能：
```markdown
[REGRESSION EVAL: feature-name]
Baseline: SHA or checkpoint name
Tests:
  - existing-test-1: PASS/FAIL
  - existing-test-2: PASS/FAIL
  - existing-test-3: PASS/FAIL
Result: X/Y passed (previously Y/Y)
```

## 指标

### pass@k
"k次尝试中至少一次成功"
- pass@1: 首次尝试成功率
- pass@3: 3次尝试内的成功率
- 典型目标: pass@3 > 90%

### pass^k
"所有k次试验都成功"
- 更高的可靠性标准
- pass^3: 连续3次成功
- 用于关键路径

推荐阈值：
- 能力评估: pass@3 >= 0.90
- 回归评估: 发布关键路径 pass^3 = 1.00

## 评估存储

在项目中存储评估：
```
.trae/
  evals/
    feature-xyz.md      # 评估定义
    feature-xyz.log     # 评估运行历史
    baseline.json       # 回归基线
```

## 评估反模式

- 将提示过拟合到已知评估示例
- 只衡量快乐路径输出
- 追求通过率时忽略成本和延迟漂移
- 在发布门中允许不稳定的评分器

## 流水线集成

本skill是AI工程流水线的 Phase 3。它是 self-improve 的**前提**——没有可量化的评估，锦标赛选择机制无法判断哪个方案更好。

**与 self-improve 的关系**：eval-harness 是"裁判"，self-improve 是"竞赛"。如果裁判不公平或不清晰，竞赛就毫无意义。

完成 eval-harness 后：
- **Phase 4**: 调用 `self-improve` skill——它将使用你的评估定义和基准命令
- 你在此定义的基准命令和格式直接传入 self-improve 的 `settings.json`

## 最佳实践

1. **编码前定义评估** - 强制对成功标准进行清晰思考
2. **频繁运行评估** - 尽早捕获回归
3. **跟踪 pass@k 趋势** - 监控可靠性趋势
4. **尽可能使用代码评分器** - 确定性 > 概率性
5. **安全检查需人工审阅** - 永远不要完全自动化安全检查
6. **保持评估快速** - 慢评估不会被运行
7. **评估与代码一起版本化** - 评估是一等工件

## 依赖

- blueprint（Phase 1，需要退出标准作为评估基准）

## 输出

- 评估定义：`.trae/evals/{feature-name}.md`
- 评估运行历史：`.trae/evals/{feature-name}.log`
- 回归基线：`.trae/evals/baseline.json`
- 基准脚本：目标仓库中的 `scripts/benchmark.py` 或等效文件
- 评估报告：包含通过/失败状态和 pass@k 指标
