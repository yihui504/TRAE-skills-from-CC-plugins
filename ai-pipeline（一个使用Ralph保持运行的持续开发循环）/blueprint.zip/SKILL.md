---
name: blueprint
description: "当规划需要多个会话或多个代理的复杂多PR任务时使用。不适用于单PR可完成或用户说'直接做'的简单任务。"
---

# Blueprint — 构建计划生成器

将一行目标转化为任何编码代理都能冷启动执行的逐步构建计划。

## 适用场景

- 将大型功能拆分为多个PR，有清晰的依赖顺序
- 规划跨多个会话的重构或迁移
- 协调跨子代理的并行工作流
- 会话间上下文丢失会导致返工的任何任务
- 作为AI工程流水线 Phase 1（blueprint → ADR → eval-harness → self-improve → ai-slop-cleaner）

## 不适用场景

- 单个PR可完成的任务
- 少于3次工具调用的任务
- 用户说"直接做"的简单任务

注意：SOLO Coder 内置 Plan 模式（/Plan），本skill提供更详细的依赖图和并行步骤检测，可作为Plan模式的增强替代。输出计划到 `.trae/plans/` 目录。

## 工作原理

Blueprint 运行5阶段流水线：

1. **Research** — 预检（git、gh auth、remote、默认分支），然后读取项目结构、现有计划和记忆文件以收集上下文。
2. **Design** — 将目标拆分为单PR大小的步骤（通常3-12个）。分配依赖边、并行/串行排序和每步回滚策略。
3. **Draft** — 将自包含的Markdown计划文件写入 `.trae/plans/`。每个步骤包含上下文简报、任务列表、验证命令和退出标准——使新代理无需阅读先前步骤即可执行任何步骤。
4. **Review** — 委托对抗性审阅给子代理，对照检查清单和反模式目录。在最终确定前修复所有关键发现。
5. **Register** — 保存计划、更新记忆索引，向用户展示步骤数和并行度摘要。

Blueprint 自动检测 git/gh 可用性。有 git + GitHub CLI 时，生成完整的分支/PR/CI工作流计划。没有时，切换到直接模式（就地编辑、无分支）。

## 指令

### Phase 1: Research

1. 检查 git 是否可用：`git --version`
2. 检查 GitHub CLI 是否可用：`gh --version`
3. 如 git 可用，检查：`git remote -v`、`git branch --show-current`
4. 读取项目结构：列出顶层文件和目录
5. 检查 `.trae/plans/` 目录中的现有计划
6. 检查 `.trae/adr/` 中的现有ADR记录
7. 检查 `.trae/evals/` 中的现有评估定义
8. 从 README、package.json 或等效项目元数据收集上下文

### Phase 2: Design

1. 将目标拆分为离散步骤（3-12步）
2. 对每个步骤，确定：
   - **依赖**: 哪些步骤必须先完成
   - **并行潜力**: 此步骤能否与其他步骤并发运行？
   - **范围**: 影响的文件和模块
   - **回滚策略**: 出问题时如何撤销
3. 构建依赖图，识别并行 vs 串行步骤

### Phase 3: Draft

将计划写为Markdown文件到 `.trae/plans/{project-slug}-{objective-slug}.md`，结构如下：

```markdown
# Plan: {Objective}

## Overview
{1-2 sentence summary}

## Dependency Graph
{ASCII or Mermaid diagram showing step dependencies}

## Parallelism Summary
- Serial steps: {count}
- Parallel groups: {count}
- Total steps: {count}

---

## Step 1: {Title}

### Context Brief
{Self-contained context so a fresh agent can execute this step without reading prior steps}

### Tasks
- [ ] {task 1}
- [ ] {task 2}

### Verification
{Commands to verify step completion}

### Exit Criteria
{Measurable conditions for step completion}

### Rollback
{How to undo changes if needed}

---

## Step 2: {Title}
...
```

### Phase 4: Review

1. 使用 Skill 工具执行计划的对抗性审阅
2. 审阅检查清单：
   - 完整性：是否包含所有必要步骤？
   - 依赖正确性：依赖是否准确且最小？
   - 反模式检测：计划是否避免了已知反模式？
   - 冷启动可行性：每个步骤能否独立执行？
   - 验证充分性：退出标准是否可衡量？
3. 在最终确定前修复所有关键发现

### Phase 5: Register

1. 保存最终确定的计划文件
2. 向用户展示摘要：
   ```
   Blueprint complete: {N} steps, {P} parallel groups
   Plan saved to: .trae/plans/{filename}
   Next: Run architecture-decision-records to capture key decisions, then eval-harness to define success metrics.
   ```

## 反模式目录

注意并避免以下常见规划反模式：

| 反模式 | 描述 | 修复 |
|---|---|---|
| **上帝步骤** | 单个步骤做了太多事 | 拆分为更小、聚焦的步骤 |
| **隐藏依赖** | 步骤依赖另一个但未声明 | 显式声明依赖 |
| **模糊退出标准** | "它能工作"而非可衡量条件 | 添加具体测试命令或断言 |
| **缺失回滚** | 步骤失败时无法撤销 | 添加 git 分支或备份策略 |
| **上下文假设** | 步骤假设了先前步骤的知识 | 添加上下文简报 |
| **串行偏见** | 步骤标记为串行但可以并行 | 检查是否有独立的文件集 |

## 计划变更协议

创建后计划需要变更时：

| 操作 | 协议 |
|---|---|
| **拆分** | 用 N.1、N.2 替换步骤N；更新依赖 |
| **插入** | 在现有步骤间添加步骤；重新编号并更新依赖 |
| **跳过** | 标记步骤为已跳过并注明原因；更新依赖步骤 |
| **重排** | 移动步骤并更新所有依赖边 |
| **废弃** | 标记整个计划为已废弃并注明原因 |

所有变更必须在计划文件中记录时间戳和原因。

## 流水线集成

本skill是AI工程流水线的 Phase 1。完成 blueprint 后：

1. **Phase 2**: 调用 `architecture-decision-records` skill 捕获规划期间做出的架构决策
2. **Phase 3**: 调用 `eval-harness` skill 为计划定义成功指标
3. **Phase 4**: 调用 `self-improve` skill 自动优化实现
4. **Phase 5**: 调用 `ai-slop-cleaner` skill 清理进化残留

## 示例

### 基本用法

用户说："将数据库迁移到PostgreSQL"

产出 `.trae/plans/myapp-migrate-database-to-postgresql.md`，步骤如：
- Step 1: 添加 PostgreSQL 驱动和连接配置
- Step 2: 为每张表创建迁移脚本
- Step 3: 更新仓库层使用新驱动
- Step 4: 添加针对 PostgreSQL 的集成测试
- Step 5: 移除旧数据库代码和配置

### 多代理项目

用户说："将LLM提供者提取为插件系统"

产出包含并行步骤的计划（例如，"实现 Anthropic 插件"和"实现 OpenAI 插件"在插件接口步骤完成后并行运行），每步后验证不变量（例如，"所有现有测试通过"、"核心中无提供者导入"）。

## 依赖

无（流水线起点）

## 输出

- 计划文件：`.trae/plans/{project-slug}-{objective-slug}.md`
