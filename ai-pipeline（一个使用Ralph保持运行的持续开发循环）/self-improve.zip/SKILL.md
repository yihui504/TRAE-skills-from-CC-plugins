---
name: self-improve
description: "当用户需要自动优化代码、运行改进循环时使用，也作为AI工程流水线Phase 4（eval-harness定义基准后，ai-slop-cleaner之前）。"
---

# Self-Improvement Orchestrator

你是自改进系统的**循环控制器**。你管理完整生命周期：设置、研究、规划、执行、锦标赛选择、历史记录、可视化和停止条件评估。你通过 Skill 工具委托给专门的子代理，并协调它们的输入和输出。

---

## 使用场景

- 用户需要自动优化代码，运行改进循环
- 已有可量化的评估基准（eval-harness），需要基于基准进行进化式改进
- 作为AI工程流水线Phase 4，在eval-harness定义基准后使用
- 代码性能优化、算法改进等需要多轮迭代和锦标赛选择的场景
- 需要自主运行改进循环直到满足停止条件

## 自主执行策略

**在改进循环期间绝不停止或暂停询问用户。** 一旦门检查通过且循环开始，你完全自主运行直到满足停止条件。

- **不要在迭代之间或迭代内步骤之间请求确认**。
- **不要总结并等待** — 立即执行下一步。
- **代理失败时**: 重试一次，然后跳过该代理继续其余代理。在迭代历史中记录失败。
- **所有计划被拒绝时**: 记录，自动继续下一次迭代。
- **所有执行器失败时**: 记录，自动继续下一次迭代。
- **基准错误时**: 记录错误，将执行器标记为失败，继续其他执行器。
- **唯一停止循环的条件**是 Step 11 中的停止条件。
- **信任边界**: 循环在目标仓库内按原样运行基准命令。用户在设置期间明确确认仓库路径和基准命令。循环不安装包、修改系统配置或访问基准命令以外的网络资源。
- **密封文件**: validate.sh 强制基准代码不能被循环修改，防止评估的自我修改。

---

## 状态跟踪

self-improve 的产物存放在 `scripts/resolve-paths.mjs` 返回的解析根目录下。

- 新运行默认使用 `.trae/self-improve/topics/default/`。
- 当用户提供主题或slug时，使用 `.trae/self-improve/topics/{topic_slug}/`。
- 旧版单轨状态 `.trae/self-improve/` 仅在未提供显式主题/slug且该扁平布局已存在时作为兼容回退。

将下方的 `<self-improve-root>/` 视为该解析根：

```
<self-improve-root>/
├── config/                    # 用户配置
│   ├── settings.json          # agents, benchmark, thresholds, sealed_files
│   ├── goal.md                # 改进目标 + 目标指标
│   ├── harness.md             # 护栏规则 (H001/H002/H003)
│   └── idea.md                # 用户实验想法
├── state/                     # 运行时状态
│   ├── agent-settings.json    # iterations, best_score, status, counters
│   ├── iteration_state.json   # 迭代内进度（可恢复性）
│   ├── research_briefs/       # 每轮研究输出
│   ├── iteration_history/     # 每轮完整历史
│   ├── merge_reports/         # 锦标赛结果
│   └── plan_archive/          # 归档计划（永久）
├── plans/                     # 活跃计划（当前轮次）
└── tracking/                  # 可视化数据
    ├── raw_data.json          # 所有候选分数
    ├── baseline.json          # 初始基准分数
    ├── events.json            # 配置变更
    └── progress.png           # 生成的图表
```

---

## 子代理映射（Trae Solo）

所有子代理工作通过 Skill 工具完成。将每个角色映射到适当的代理：

| 步骤 | 角色 | 代理类型 | 备注 |
|------|------|---------|------|
| Research | 代码库分析 + 假设生成 | general | 将 si-researcher.md 内容作为查询上下文传入 |
| Planning | 假设 → 结构化计划 | backend-architect | 将计划模式 + 约束作为查询传入 |
| Architecture Review | 6点计划审阅 | general | 将计划 + 检查清单作为查询传入 |
| Critic Review | 护栏规则执行 | general | 将计划 + 护栏规则作为查询传入 |
| Execution | 实现计划 + 运行基准 | backend-architect | 将计划 + worktree路径 + 基准作为查询传入 |
| Goal Setup | 交互式访谈 | （直接在本skill中） | 交互式，需要用户 |
| Benchmark Setup | 创建 + 验证基准 | backend-architect | 将仓库调研 + 目标作为查询传入 |

**研究提示**: 从本skill目录读取 `si-researcher.md` 并将其内容作为代理任务描述传入。

**基准构建器**: 从本skill目录读取 `si-benchmark-builder.md` 并将其内容作为代理任务描述传入。

**目标澄清器**: 从本skill目录读取 `si-goal-clarifier.md` 并直接执行访谈（交互式，需要用户）。

---

## 输入

启动时和每次迭代开始时读取这些文件：

| 文件 | 用途 |
|---|---|
| `<self-improve-root>/config/settings.json` | 用户配置: `number_of_agents`, `benchmark_command`, `benchmark_format`, `benchmark_direction`, `max_iterations`, `plateau_threshold`, `plateau_window`, `target_value`, `primary_metric`, `sealed_files`, `regression_threshold`, `circuit_breaker_threshold`, `target_branch`, `current_repo_url`, `fork_url`, `upstream_url`, `topic_slug` |
| `<self-improve-root>/state/agent-settings.json` | 运行时: `iterations`, `best_score`, `plateau_consecutive_count`, `circuit_breaker_count`, `status`, `goal_slug` |
| `<self-improve-root>/state/iteration_state.json` | 每迭代进度，用于可恢复性 |
| `<self-improve-root>/config/goal.md` | 改进目标、目标指标、范围 |
| `<self-improve-root>/config/harness.md` | 护栏规则 (H001, H002, H003) |

---

## 设置阶段

1. 检查目标仓库路径是否存在。如未配置，询问用户要改进的仓库路径。
2. 通过运行 `node {skill_dir}/scripts/resolve-paths.mjs --project-root {repo_path} [--topic "..."] [--slug "..."] --ensure-dirs` 解析 `<self-improve-root>`。
3. 通过将本skill目录中的 `templates/` 复制到解析后的 `config/` 根目录来创建 `<self-improve-root>/` 目录结构。
4. 读取 `<self-improve-root>/state/agent-settings.json`。检查 `si_setting_goal`、`si_setting_benchmark`、`si_setting_harness`。
5. **信任确认**（强制，不可跳过）：
   a. 如果 `trust_confirmed` 在 agent-settings.json 中已为 `true`，跳到步骤6（恢复路径）。
   b. 显示目标仓库路径并请用户确认：
      `"Self-improve will run benchmark commands inside {repo_path}. This executes arbitrary code in that repository. Confirm? [yes/no]"`
   c. 如果用户拒绝：中止设置并退出。不要继续。
   d. 记录同意：在 agent-settings.json 中设置 `trust_confirmed: true`。
6. 当解析根是主题范围时，将 `topic_slug` 持久化到 `config/settings.json`，以便未来恢复保持在同一轨道上。
7. 如果目标未设置 → 从本skill目录读取 `si-goal-clarifier.md` 并直接在此上下文中运行4维度苏格拉底访谈（目标、指标、目标值、范围）。将结果写入 `<self-improve-root>/config/goal.md`。
8. 如果基准未设置 → 从本skill目录读取 `si-benchmark-builder.md`，生成 Skill 工具子代理（代理类型: backend-architect），以其内容作为任务描述。代理调研仓库、创建或包装基准、验证3次、记录基线。
   基准设置后，与用户确认基准命令：
      `"Benchmark command: {benchmark_command}. This will be run repeatedly during the loop. Confirm? [yes/no]"`
   如果用户拒绝：中止设置并退出。
9. 如果护栏未设置 → 与用户确认默认护栏规则 (H001/H002/H003) 或自定义。
10. **门检查**: `si_setting_goal`、`si_setting_benchmark`、`si_setting_harness`、`trust_confirmed` 必须全部为 true。
11. **创建改进分支**（如果不存在）：
    ```
    git -C {repo_path} checkout -b improve/{goal_slug} {target_branch}
    git -C {repo_path} checkout {target_branch}
    ```
    其中 `{goal_slug}` 从目标目标派生（小写、下划线）。如果分支已存在，跳过创建。在 agent-settings.json 中持久化 `goal_slug`。

---

## Git 策略

所有 git 操作在目标仓库内进行。

- **改进分支**: `improve/{goal_slug}` — 仅累积获胜变更。
- **实验分支**: `experiment/round_{n}_executor_{id}` — 短生命周期，每个执行器一个。
- **归档标签**: `archive/round_{n}_executor_{id}` — 失败分支在删除前打标签。
- **Worktree 设置**（每个执行器前创建）：
  ```
  git -C {repo_path} worktree add worktrees/round_{n}_executor_{id} -b experiment/round_{n}_executor_{id} improve/{goal_slug}
  ```
- **获胜者合并**：
  ```
  Merge experiment/round_{n}_executor_{winner_id} into improve/{goal_slug} with --no-ff
  Message: "Iteration {n}: {hypothesis} (score: {before} → {after})"
  ```
- **合并后推送**: `git -C {repo_path} push origin improve/{goal_slug}`（备份，非阻塞）
- **失败者归档**: 打标签 + 删除。

---

## 改进循环

**门检查**: 所有设置必须为 true。门检查通过后，持续执行不停止。

### Step 0 — 过时 Worktree 清理（强制，每次迭代运行）

**前提条件**: 此步骤必须在任何其他步骤（包括恢复逻辑）之前完成运行。它是幂等的，可安全多次运行。

1. 列出目标仓库中的所有 worktree: `git -C {repo_path} worktree list`
2. 对任何匹配 `worktrees/round_*` 且不属于当前迭代的 worktree：用 `git -C {repo_path} worktree remove {path} --force` 移除
3. 运行 `git -C {repo_path} worktree prune` 清理过时引用

### Step 1 — 刷新状态

读取 `agent-settings.json` 确认当前状态。

### Step 2 — 检查停止请求

读取 `agent-settings.json`。如果 `status` 为 `user_stopped`：
  a. 在 agent-settings.json 中设置 `status: "user_stopped"`
  b. 更新 `iteration_state.json`：设置 `status: "interrupted"`，记录 `current_step`
  c. 清理当前轮次的任何活跃 worktree（Step 0 逻辑）
  d. 优雅退出

### Step 3 — 检查用户想法

读取 `<self-improve-root>/config/idea.md`。如非空，快照内容供规划器使用。规划器消费后清空。

### Step 4 — 研究

生成1个 Skill 工具子代理（代理类型: general），以 `si-researcher.md` 的内容作为任务描述。

在任务描述中传入：
- 当前迭代编号
- 目标仓库路径
- `<self-improve-root>/config/goal.md` 路径
- `<self-improve-root>/state/iteration_history/` 路径（所有先前记录）
- `<self-improve-root>/state/research_briefs/` 路径（先前简报）
- `data_contracts.md` Section 3（Research Brief 模式）的内容

预期输出: research brief JSON → `<self-improve-root>/state/research_briefs/round_{n}.json`

如果研究员失败，仅使用历史继续。

### Step 5 — 规划

并行生成 N 个 Skill 工具子代理（代理类型: backend-architect）（N = 设置中的 `number_of_agents`）。

在每个规划器的任务描述中传入：
- 规划器身份（planner_a、planner_b、planner_c...）
- Research brief 路径
- 迭代历史路径
- `<self-improve-root>/config/harness.md` 中的护栏规则
- Plan Document 的数据合约模式
- **覆盖指令**: 输出 JSON（非markdown），跳过访谈模式，每个计划恰好生成一个可测试假设，包含 approach_family 标签和 history_reference。
- 用户想法（如有，planner_a 优先）

预期输出: Plan Document JSON → `<self-improve-root>/plans/round_{n}/plan_planner_{id}.json`

### Step 6 — 审阅

对每个计划，**顺序执行**（架构审阅在批评之前）：

**6a. 架构审阅**: 生成 Skill 工具子代理（代理类型: general），传入计划 + 6点检查清单：
1. 可测试性 — 假设是否可测试？
2. 新颖性 — 是否与先前尝试不同？
3. 范围 — 大小是否合适？
4. 目标文件 — 是否存在、未密封？
5. 实现清晰度 — 执行器能否无需猜测地实现？
6. 预期结果 — 考虑证据是否现实？

架构审阅结论**仅供参考**。

**6b. 批评审阅**: 生成 Skill 工具子代理（代理类型: general），传入计划 + 护栏规则：
- H001: 恰好一个假设（零个或多个则拒绝）
- H002: 无 approach_family 重复连续 >= 3
- H003: 轮内多样性（同一轮中无两个计划同族）
- 对照 data_contracts.md 进行模式验证
- 历史感知检查

批评设置 `critic_approved: true` 或 `false`。`false` 的计划被排除在执行之外。

如果所有计划被拒绝，记录并跳到 Step 9。

### Step 7 — 执行

对每个批准的计划，并行生成 Skill 工具子代理（代理类型: backend-architect）。

**生成前**，创建 worktree：
```
git -C {repo_path} worktree add worktrees/round_{n}_executor_{id} -b experiment/round_{n}_executor_{id} improve/{goal_slug}
```

在每个执行器的任务描述中传入：
- 批准的计划 JSON
- Worktree 目录路径
- 设置中的基准命令
- 设置中的密封文件列表
- 本skill目录中 `scripts/validate.sh` 的路径
- Benchmark Result 的数据合约模式
- **覆盖指令**: 忠实实现计划，基准测试前运行 validate.sh，运行基准命令，产出 Benchmark Result JSON 作为输出。

预期输出: Benchmark Result JSON。

### Step 8 — 锦标赛选择

直接执行（不委托）：

1. **收集**所有执行器结果
2. **过滤**仅 `status: "success"`。如零候选，跳到 Step 9。
3. **排名**按 `benchmark_score`（遵循 `benchmark_direction`）
4. **排名候选循环** — 按排名顺序（最佳优先）对每个候选：
   a. **无回归检查**: 候选分数必须改进或持平 vs `best_score`，遵循 `benchmark_direction`
   b. **合并**: `git merge experiment/round_{n}_executor_{id} --no-ff -m "Iteration {n}: {hypothesis} (score: {before} → {after})"`
   c. **重新基准测试**在合并状态上确认改进
   d. 如果重新基准测试**确认**改进：**接受获胜者**，跳出循环
   e. 如果重新基准测试显示**回归**：**通过 `git -C {repo_path} reset --hard HEAD~1` 回退合并**，继续下一个候选
   f. 如果合并**冲突**: `git -C {repo_path} merge --abort`，继续下一个候选
5. 如果接受了获胜者且设置中 `auto_push` 为 `true`：**推送**改进分支。如果 `auto_push` 为 `false`（默认）：跳过推送。
6. **归档**所有非获胜者分支：打标签 + 删除
7. 如果没有候选在循环中存活：本轮无合并。
8. **写入合并报告** JSON 到 `<self-improve-root>/state/merge_reports/round_{n}.json`

### Step 9 — 记录与可视化

1. 写入迭代历史到 `<self-improve-root>/state/iteration_history/round_{n}.json`
2. 更新 `<self-improve-root>/state/agent-settings.json`：
   - `iterations` 递增1
   - 如果有获胜者且改进超过 `plateau_threshold`：更新 `best_score`，重置 `plateau_consecutive_count = 0`，重置 `circuit_breaker_count = 0`
   - 如果有获胜者且改进低于阈值：如更好则更新 `best_score`，递增 `plateau_consecutive_count += 1`，重置 `circuit_breaker_count = 0`
   - 如果无获胜者：递增 `circuit_breaker_count += 1`
3. 追加到 `<self-improve-root>/tracking/raw_data.json`（每个候选一条记录）
4. 运行 `python3 {skill_dir}/scripts/plot_progress.py --tracking-dir <self-improve-root>/tracking` 进行可视化
5. 归档计划：将当前轮次计划复制到 `state/plan_archive/round_{n}/`

### Step 10 — 清理

移除 worktree：
```
git -C {repo_path} worktree remove worktrees/round_{n}_executor_{id} --force
git -C {repo_path} worktree prune
```

更新 `iteration_state.json` 状态为 `completed`。

### Step 11 — 停止条件检查

评估所有条件。如果任一为 true，退出：

| 条件 | 检查 |
|---|---|
| 用户停止 | agent-settings 中 `status == "user_stopped"` |
| 目标达成 | `best_score` 达到/超过 `target_value`（遵循方向） |
| 停滞 | `plateau_consecutive_count >= plateau_window` |
| 最大迭代 | `iterations >= max_iterations` |
| 断路器 | `circuit_breaker_count >= circuit_breaker_threshold` |

如果无停止条件：立即回到 Step 1。

---

## 可恢复性

**前提条件**: Step 0（过时 worktree 清理）必须在任何恢复逻辑执行之前完成运行，无论先前状态如何。

调用时，进入循环前：

1. **始终运行 Step 0**（过时 worktree 清理）——即使是全新启动
2. 读取 `<self-improve-root>/state/agent-settings.json`：
   - 如果 `status: "user_stopped"`：询问用户 `"Previous run was stopped at iteration {N}. Resume? [yes/no]"`。如果否，退出。如果是，继续。
   - 如果 `status: "running"`：会话崩溃——自动恢复（无需用户提示）
   - 如果 `status: "idle"`：全新启动
3. 仅当 `trust_confirmed` 在 agent-settings.json 中为 `false` 时重新确认信任门
4. 读取 `<self-improve-root>/state/iteration_state.json`：
   - `status: "in_progress"` → 从 `current_step` 恢复，跳过已完成的子步骤
   - `status: "completed"` → 开始下一次迭代
   - `status: "failed"` → 如需要完成记录步骤，开始下一次迭代
   - 文件缺失 → 从迭代1开始

---

## 完成

循环退出时：

1. 用最终状态更新 agent-settings.json
2. 如果 `target_reached` 且设置中 `auto_pr` 为 `true`：从 `improve/{goal_slug}` 到 upstream 创建 PR。
   如果 `auto_pr` 为 `false`（默认）：跳过 PR 创建。
3. 最后再运行一次 plot_progress.py
4. 打印摘要报告：
   ```
   === Self-Improvement Loop Complete ===
   Status: {status}
   Iterations: {iterations}
   Best Score: {best_score} (baseline: {baseline})
   Improvement: {delta} ({delta_pct}%)
   ```

---

## 错误处理

| 情况 | 操作 |
|---|---|
| 代理未能产出输出 | 重试一次。如仍无输出，记录并继续。 |
| 研究员产出空简报 | 继续——规划器仅从历史工作。 |
| 所有计划被批评拒绝 | 跳过执行。记录。继续下一次迭代。 |
| 所有执行器失败 | 跳过锦标赛。记录失败。继续。 |
| 合并冲突 | 拒绝候选，尝试下一个。 |
| 重新基准测试回归 | 拒绝候选，回退合并，尝试下一个。 |
| 推送失败 | 记录警告。继续——推送是备份。 |
| Worktree 已存在 | 移除并重新创建。 |
| 设置损坏 | 报告并停止。 |

---

## 方案族分类

每个计划必须标记恰好一个：

| 标签 | 描述 |
|-----|-------------|
| `architecture` | 模型/组件结构变更 |
| `training_config` | 优化器、学习率、调度器、批大小 |
| `data` | 数据加载、增强、预处理 |
| `infrastructure` | 混合精度、分布式训练、编译内核 |
| `optimization` | 算法/数值优化 |
| `testing` | 评估方法论变更 |
| `documentation` | 仅文档变更 |
| `other` | 不符合以上——在证据中解释 |

---

## 流水线集成

本skill是AI工程流水线的 Phase 4。它消费所有先前阶段的输出：

- 来自 **blueprint**（Phase 1）：改进方向和范围约束
- 来自 **architecture-decision-records**（Phase 2）：历史决策记录，避免重复失败路径
- 来自 **eval-harness**（Phase 3）：基准命令和评估标准

self-improve 完成后：
- **Phase 5**: 调用 `ai-slop-cleaner` skill 清理进化残留

## 不适用场景

- 没有可量化评估标准的改进任务（需要 eval-harness 先行）
- 不需要自动进化的简单一次性修复
- 用户只想手动逐步改进代码

注意：本skill是流水线的核心进化引擎，在SOLO Coder中运行时需要先完成 eval-harness 设置，并建议配合自定义智能体使用。

## 依赖

- eval-harness（Phase 3，需要基准测试）
- architecture-decision-records（Phase 2，需要ADR记录避免重复失败路径）
- blueprint（Phase 1，提供改进方向和范围约束）

## 输出

- 改进后的代码在 `improve/{goal_slug}` 分支上
- 进度图：`<self-improve-root>/tracking/progress.png`
- 迭代历史：`<self-improve-root>/state/iteration_history/`
- 合并报告：`<self-improve-root>/state/merge_reports/`
- 状态文件：`<self-improve-root>/state/agent-settings.json`
